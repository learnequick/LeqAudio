/**
 * LEQ Dark Mode Theme Colors
 * Matching the web app's premium purple theme
 */

const primaryColor = '#8B5CF6';
const primaryDark = '#7C3AED';
const secondaryColor = '#A78BFA';

export const Colors = {
  light: {
    text: '#FFFFFF',
    textSecondary: '#B0B0B0',
    textMuted: '#707070',
    background: '#0F0F0F',
    backgroundSecondary: '#1A1A1A',
    card: '#1E1E1E',
    cardHover: '#252525',
    border: '#2A2A2A',
    primary: primaryColor,
    primaryDark: primaryDark,
    secondary: secondaryColor,
    accent: '#EC4899',
    success: '#10B981',
    danger: '#EF4444',
    warning: '#F59E0B',
    tint: primaryColor,
    icon: '#B0B0B0',
    tabIconDefault: '#707070',
    tabIconSelected: primaryColor,
  },
  dark: {
    text: '#FFFFFF',
    textSecondary: '#B0B0B0',
    textMuted: '#707070',
    background: '#0F0F0F',
    backgroundSecondary: '#1A1A1A',
    card: '#1E1E1E',
    cardHover: '#252525',
    border: '#2A2A2A',
    primary: primaryColor,
    primaryDark: primaryDark,
    secondary: secondaryColor,
    accent: '#EC4899',
    success: '#10B981',
    danger: '#EF4444',
    error: '#EF4444', // Alias for danger
    warning: '#F59E0B',
    tint: primaryColor,
    icon: '#B0B0B0',
    tabIconDefault: '#707070',
    tabIconSelected: primaryColor,
  },
};

export default Colors;
