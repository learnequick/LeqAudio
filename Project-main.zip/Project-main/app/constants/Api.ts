/**
 * API Configuration for LEQ Mobile App
 * All endpoints from leq/mobileapi/urls.py
 */

import { Platform } from 'react-native';

// Platform-specific API URL
// For web: use localhost since it's running on the same machine
// For native: use your local network IP address
const getApiBaseUrl = () => {
    // For production (APK/Release build), use the live server
    if (!__DEV__) {
        return 'https://www.leqaudio.com/api/mobile';
    }

    if (Platform.OS === 'web') {
        // When running on web via Expo, use localhost to connect to Django backend
        return 'http://localhost:8000/api/mobile';
    }
    // For mobile devices on the same network, use your computer's local IP
    // Update this IP address to match your computer's IP on the local network
    return 'http://192.168.29.44:8000/api/mobile';
};

export const API_BASE_URL = getApiBaseUrl();

console.log('API Base URL:', API_BASE_URL);

export const API_ENDPOINTS = {

    AUTH: {
        LOGIN: '/auth/login/',
        REGISTER: '/auth/register/',
        VERIFY_SIGNUP_OTP: '/auth/verify-signup-otp/',
        RESEND_SIGNUP_OTP: '/auth/resend-signup-otp/',
        LOGOUT: '/auth/logout/',
        CHANGE_PASSWORD: '/auth/change-password/',
        FORGOT_PASSWORD: '/auth/forgot-password/',
        VERIFY_RESET_OTP: '/auth/verify-reset-otp/',
        RESET_PASSWORD: '/auth/reset-password/',
    },

    // User Profile
    USER: {
        PROFILE: '/profile/',
        SETTINGS: '/settings/',
        STATS: '/stats/',
    },

    // Categories
    CATEGORIES: '/categories/',

    // Courses
    COURSES: {
        LIST: '/courses/',
        DETAIL: (id: number | string) => `/courses/${id}/`,
        FEATURED: '/courses/featured/',
        TRENDING: '/courses/trending/',
        TOP_RATED: '/courses/top-rated/',
        REVIEWS: (id: number | string) => `/courses/${id}/reviews/`,
        ENROLL: (id: number | string) => `/courses/${id}/enroll/`,
    },

    // Lessons
    LESSONS: {
        LIST: '/lessons/',
        DETAIL: (id: number | string) => `/lessons/${id}/`,
        UPDATE_PROGRESS: (id: number | string) => `/lessons/${id}/update_progress/`,
    },

    // Enrollments
    ENROLLMENTS: {
        LIST: '/enrollments/',
        DETAIL: (id: number | string) => `/enrollments/${id}/`,
        ACTIVE: '/enrollments/active/',
        COMPLETED: '/enrollments/completed/',
    },

    // Reviews
    REVIEWS: '/reviews/',

    // Notifications
    NOTIFICATIONS: {
        LIST: '/notifications/',
        UNREAD: '/notifications/unread/',
        MARK_READ: (id: number | string) => `/notifications/${id}/mark-read/`,
        MARK_ALL_READ: '/notifications/mark-all-read/',
    },

    // Payments
    PAYMENTS: {
        LIST: '/payments/',
        CREATE_ORDER: '/payments/create_order/',
        VERIFY: '/payments/verify_payment/',
        VALIDATE_COUPON: '/payments/validate-coupon/',
    },

    // Banners
    BANNERS: {
        LIST: '/banners/',
        HOME: '/banners/home/',
    },

    // Search & Dashboard
    SEARCH: '/search/',
    DASHBOARD: '/dashboard/',
};

export default API_ENDPOINTS;
