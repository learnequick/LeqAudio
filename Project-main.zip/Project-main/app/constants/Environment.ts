/**
 * Environment Configuration
 * Add your environment-specific variables here
 */

export const ENV = {
    // API Configuration
    API_BASE_URL: process.env.EXPO_PUBLIC_API_URL || (__DEV__ ? 'http://localhost:8000/api/mobile' : 'https://www.leqaudio.com/api/mobile'),


    // Razorpay Configuration (optional - key comes from backend)
    // RAZORPAY_KEY_ID is fetched from backend during order creation for security

    // App Configuration
    APP_NAME: 'LeQ',
    APP_VERSION: '1.0.0',

    // Feature Flags
    ENABLE_PAYMENTS: true,
    ENABLE_OFFLINE_MODE: false,
};

export default ENV;
