/**
 * Auth Store - Zustand store for authentication state
 */

import { create } from 'zustand';
import { User } from '@/types';
import { authService } from '@/services';
import { getAuthToken, removeAuthToken } from '@/services/api';
import { secureStorage } from '@/utils/storage';

interface AuthState {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    isInitialized: boolean;
    hasSeenOnboarding: boolean;

    // Actions
    initialize: () => Promise<void>;
    login: (email: string, password: string) => Promise<void>;
    register: (data: {
        email: string;
        first_name: string;
        last_name: string;
        phone: string;
        password: string;
        password_confirm: string;
    }) => Promise<{ message: string; user_id: number; email: string; requires_verification: boolean }>;
    verifySignupOTP: (user_id: number, otp: string) => Promise<void>;
    resendSignupOTP: (user_id: number, email: string) => Promise<void>;
    logout: () => Promise<void>;
    setHasSeenOnboarding: (value: boolean) => Promise<void>;
    refreshUser: () => Promise<void>;
    updateProfile: (data: Partial<User>, imageUri?: string) => Promise<void>;
}

const ONBOARDING_KEY = 'leq_has_seen_onboarding';

export const useAuthStore = create<AuthState>((set, get) => ({
    user: null,
    isAuthenticated: false,
    isLoading: false,
    isInitialized: false,
    hasSeenOnboarding: false,

    initialize: async () => {
        try {
            set({ isLoading: true });

            // Check if user has seen onboarding
            const hasSeenOnboarding = await secureStorage.getItem(ONBOARDING_KEY);

            // Check for existing token
            const token = await getAuthToken();

            if (token) {
                try {
                    // Validate token by fetching user profile
                    const user = await authService.getProfile();
                    set({
                        user,
                        isAuthenticated: true,
                        hasSeenOnboarding: hasSeenOnboarding === 'true',
                        isInitialized: true,
                        isLoading: false
                    });
                } catch (error) {
                    // Token invalid, clear it
                    await removeAuthToken();
                    set({
                        user: null,
                        isAuthenticated: false,
                        hasSeenOnboarding: hasSeenOnboarding === 'true',
                        isInitialized: true,
                        isLoading: false
                    });
                }
            } else {
                set({
                    user: null,
                    isAuthenticated: false,
                    hasSeenOnboarding: hasSeenOnboarding === 'true',
                    isInitialized: true,
                    isLoading: false
                });
            }
        } catch (error) {
            console.error('Auth initialization error:', error);
            set({ isInitialized: true, isLoading: false });
        }
    },

    login: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
            const response = await authService.login({ email, password });
            set({
                user: response.user,
                isAuthenticated: true,
                isLoading: false
            });
        } catch (error) {
            set({ isLoading: false });
            throw error;
        }
    },

    register: async (data) => {
        set({ isLoading: true });
        try {
            const response = await authService.register(data);
            set({ isLoading: false });
            // Don't set user state - OTP verification required
            return response;
        } catch (error) {
            set({ isLoading: false });
            throw error;
        }
    },

    verifySignupOTP: async (user_id: number, otp: string) => {
        set({ isLoading: true });
        try {
            const response = await authService.verifySignupOTP(user_id, otp);
            set({
                user: response.user,
                isAuthenticated: true,
                isLoading: false
            });
        } catch (error) {
            set({ isLoading: false });
            throw error;
        }
    },

    resendSignupOTP: async (user_id: number, email: string) => {
        set({ isLoading: true });
        try {
            await authService.resendSignupOTP(user_id, email);
            set({ isLoading: false });
        } catch (error) {
            set({ isLoading: false });
            throw error;
        }
    },

    logout: async () => {
        set({ isLoading: true });
        try {
            await authService.logout();
        } catch (error) {
            // Ignore logout errors
        }
        set({
            user: null,
            isAuthenticated: false,
            isLoading: false
        });
    },

    setHasSeenOnboarding: async (value: boolean) => {
        await secureStorage.setItem(ONBOARDING_KEY, String(value));
        set({ hasSeenOnboarding: value });
    },

    refreshUser: async () => {
        try {
            const user = await authService.getProfile();
            set({ user });
        } catch (error) {
            console.error('Error refreshing user:', error);
        }
    },

    updateProfile: async (data: Partial<User>, imageUri?: string) => {
        set({ isLoading: true });
        try {
            const user = await authService.updateProfile(data, imageUri);
            set({ user, isLoading: false });
        } catch (error) {
            set({ isLoading: false });
            throw error;
        }
    },
}));

export default useAuthStore;
