/**
 * Hooks Index - Export all custom hooks
 */

export {
    useResponsive,
    BREAKPOINTS,
    default as useResponsiveDefault,
} from './useResponsive';

export type {
    Breakpoint,
    ResponsiveValue,
    UseResponsiveReturn,
    SpacingScale,
    TypographyScale,
    IconScale,
    GridConfig,
    AccessibilityConfig,
    LayoutInfo,
} from './useResponsive';
