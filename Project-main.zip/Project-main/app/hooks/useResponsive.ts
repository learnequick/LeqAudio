/**
 * useResponsive Hook
 * A comprehensive responsive hook with breakpoint system (xs, sm, md, lg, xl)
 * Powered by useWindowDimensions() for dynamic updates on rotation/resize
 * 
 * Breakpoints:
 * - xs: < 360px (small phones like iPhone SE)
 * - sm: 360-600px (standard phones)
 * - md: 600-900px (large phones landscape, small tablets)
 * - lg: 900-1200px (tablets portrait, large tablets landscape)
 * - xl: > 1200px (Chromebooks, desktop, very large tablets)
 */

import { useWindowDimensions, Platform, PixelRatio, AccessibilityInfo as RNAccessibilityInfo, useColorScheme } from 'react-native';
import { useMemo, useCallback, useState, useEffect } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// ==================== BREAKPOINT DEFINITIONS ====================
export type Breakpoint = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export const BREAKPOINTS = {
    xs: 0,
    sm: 360,
    md: 600,
    lg: 900,
    xl: 1200,
} as const;

// Device reference dimensions (iPhone 14 Pro as base)
const BASE_WIDTH = 393;
const BASE_HEIGHT = 852;

// ==================== TYPE DEFINITIONS ====================
export interface ResponsiveValue<T> {
    xs?: T;
    sm?: T;
    md?: T;
    lg?: T;
    xl?: T;
    default: T;
}

export interface LayoutInfo {
    width: number;
    height: number;
    breakpoint: Breakpoint;
    isPortrait: boolean;
    isLandscape: boolean;
    isSmallPhone: boolean;
    isPhone: boolean;
    isTablet: boolean;
    isDesktop: boolean;
    isFoldable: boolean;
    aspectRatio: number;
    pixelRatio: number;
    fontScale: number;
}

export interface SpacingScale {
    none: number;
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
    xxxl: number;
}

export interface TypographyScale {
    display: number;
    h1: number;
    h2: number;
    h3: number;
    h4: number;
    h5: number;
    h6: number;
    body: number;
    bodySmall: number;
    caption: number;
    overline: number;
    tiny: number;
}

export interface IconScale {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
}

export interface GridConfig {
    columns: number;
    gutter: number;
    margin: number;
}

export interface AccessibilityConfig {
    minTouchTarget: number;
    reduceMotion: boolean;
    screenReaderEnabled: boolean;
    isHighContrast: boolean;
}

// ==================== MAIN HOOK ====================
export function useResponsive() {
    const { width, height, fontScale } = useWindowDimensions();
    const insets = useSafeAreaInsets();
    const colorScheme = useColorScheme();

    // Accessibility states
    const [reduceMotion, setReduceMotion] = useState(false);
    const [screenReaderEnabled, setScreenReaderEnabled] = useState(false);
    const [isHighContrast, setIsHighContrast] = useState(false);

    useEffect(() => {
        // Check for reduce motion preference
        if (Platform.OS === 'ios' || Platform.OS === 'android') {
            RNAccessibilityInfo.isReduceMotionEnabled().then(setReduceMotion);
            RNAccessibilityInfo.isScreenReaderEnabled().then(setScreenReaderEnabled);

            // Subscribe to changes
            const reduceMotionListener = RNAccessibilityInfo.addEventListener(
                'reduceMotionChanged',
                setReduceMotion
            );
            const screenReaderListener = RNAccessibilityInfo.addEventListener(
                'screenReaderChanged',
                setScreenReaderEnabled
            );

            return () => {
                reduceMotionListener.remove();
                screenReaderListener.remove();
            };
        }
    }, []);

    // ==================== BREAKPOINT DETECTION ====================
    const breakpoint = useMemo((): Breakpoint => {
        if (width >= BREAKPOINTS.xl) return 'xl';
        if (width >= BREAKPOINTS.lg) return 'lg';
        if (width >= BREAKPOINTS.md) return 'md';
        if (width >= BREAKPOINTS.sm) return 'sm';
        return 'xs';
    }, [width]);

    // ==================== LAYOUT INFO ====================
    const layout = useMemo((): LayoutInfo => {
        const isPortrait = height > width;
        const aspectRatio = Math.max(width, height) / Math.min(width, height);
        const pixelRatio = PixelRatio.get();

        // Device type detection
        const isSmallPhone = width < BREAKPOINTS.sm;
        const isPhone = width >= BREAKPOINTS.sm && width < BREAKPOINTS.md;
        const isTablet = width >= BREAKPOINTS.md && width < BREAKPOINTS.xl;
        const isDesktop = width >= BREAKPOINTS.xl;

        // Foldable detection (unusual aspect ratios or rapid dimension changes)
        const isFoldable = aspectRatio < 1.3 && width >= BREAKPOINTS.md;

        return {
            width,
            height,
            breakpoint,
            isPortrait,
            isLandscape: !isPortrait,
            isSmallPhone,
            isPhone,
            isTablet,
            isDesktop,
            isFoldable,
            aspectRatio,
            pixelRatio,
            fontScale,
        };
    }, [width, height, breakpoint, fontScale]);

    // ==================== SAFE AREAS ====================
    const safeAreas = useMemo(() => ({
        top: insets.top,
        bottom: insets.bottom,
        left: insets.left,
        right: insets.right,
        // Usable dimensions after safe areas
        usableWidth: width - insets.left - insets.right,
        usableHeight: height - insets.top - insets.bottom,
    }), [width, height, insets]);

    // ==================== RESPONSIVE VALUE RESOLVER ====================
    const resolve = useCallback(<T,>(values: ResponsiveValue<T> | T): T => {
        // If it's not a responsive object, return as-is
        if (typeof values !== 'object' || values === null || !('default' in values)) {
            return values as T;
        }

        const responsiveValues = values as ResponsiveValue<T>;

        // Check breakpoints from largest to smallest
        switch (breakpoint) {
            case 'xl':
                if (responsiveValues.xl !== undefined) return responsiveValues.xl;
            // fallthrough
            case 'lg':
                if (responsiveValues.lg !== undefined) return responsiveValues.lg;
            // fallthrough
            case 'md':
                if (responsiveValues.md !== undefined) return responsiveValues.md;
            // fallthrough
            case 'sm':
                if (responsiveValues.sm !== undefined) return responsiveValues.sm;
            // fallthrough
            case 'xs':
                if (responsiveValues.xs !== undefined) return responsiveValues.xs;
            // fallthrough
            default:
                return responsiveValues.default;
        }
    }, [breakpoint]);

    // ==================== SCALING FUNCTIONS ====================
    const scale = useCallback((size: number, factor: number = 1): number => {
        const scaleFactor = width / BASE_WIDTH;
        return Math.round(size * scaleFactor * factor);
    }, [width]);

    const scaleVertical = useCallback((size: number, factor: number = 1): number => {
        const scaleFactor = height / BASE_HEIGHT;
        return Math.round(size * scaleFactor * factor);
    }, [height]);

    // Moderate scale - for fonts and elements that shouldn't scale linearly
    const moderateScale = useCallback((size: number, factor: number = 0.5): number => {
        const scaleFactor = width / BASE_WIDTH;
        return Math.round(size + ((size * scaleFactor) - size) * factor);
    }, [width]);

    // Font scale that respects system font size settings
    const scaleFont = useCallback((size: number): number => {
        const baseScaled = moderateScale(size, 0.4);

        // Clamp font scale to prevent extreme sizes
        const clampedFontScale = Math.min(Math.max(fontScale, 0.85), 1.5);

        // Apply system font scaling
        return Math.round(baseScaled * clampedFontScale);
    }, [moderateScale, fontScale]);

    // ==================== TYPOGRAPHY SCALE ====================
    const typography = useMemo((): TypographyScale => {
        const baseScale: TypographyScale = {
            display: 40,
            h1: 32,
            h2: 28,
            h3: 24,
            h4: 20,
            h5: 18,
            h6: 16,
            body: 15,
            bodySmall: 13,
            caption: 12,
            overline: 11,
            tiny: 10,
        };

        // Apply breakpoint-specific adjustments
        const scaleFactor = resolve({
            xs: 0.9,
            sm: 1,
            md: 1.05,
            lg: 1.1,
            xl: 1.15,
            default: 1,
        });

        return {
            display: scaleFont(Math.round(baseScale.display * scaleFactor)),
            h1: scaleFont(Math.round(baseScale.h1 * scaleFactor)),
            h2: scaleFont(Math.round(baseScale.h2 * scaleFactor)),
            h3: scaleFont(Math.round(baseScale.h3 * scaleFactor)),
            h4: scaleFont(Math.round(baseScale.h4 * scaleFactor)),
            h5: scaleFont(Math.round(baseScale.h5 * scaleFactor)),
            h6: scaleFont(Math.round(baseScale.h6 * scaleFactor)),
            body: scaleFont(Math.round(baseScale.body * scaleFactor)),
            bodySmall: scaleFont(Math.round(baseScale.bodySmall * scaleFactor)),
            caption: scaleFont(Math.round(baseScale.caption * scaleFactor)),
            overline: scaleFont(Math.round(baseScale.overline * scaleFactor)),
            tiny: scaleFont(Math.round(baseScale.tiny * scaleFactor)),
        };
    }, [scaleFont, resolve]);

    // ==================== SPACING SCALE ====================
    const spacing = useMemo((): SpacingScale => {
        const baseSpacing: SpacingScale = {
            none: 0,
            xs: 4,
            sm: 8,
            md: 12,
            lg: 16,
            xl: 24,
            xxl: 32,
            xxxl: 48,
        };

        // Spacing scales up more on larger devices
        const scaleFactor = resolve({
            xs: 0.85,
            sm: 1,
            md: 1.15,
            lg: 1.3,
            xl: 1.5,
            default: 1,
        });

        return {
            none: Math.round(baseSpacing.none * scaleFactor),
            xs: Math.round(baseSpacing.xs * scaleFactor),
            sm: Math.round(baseSpacing.sm * scaleFactor),
            md: Math.round(baseSpacing.md * scaleFactor),
            lg: Math.round(baseSpacing.lg * scaleFactor),
            xl: Math.round(baseSpacing.xl * scaleFactor),
            xxl: Math.round(baseSpacing.xxl * scaleFactor),
            xxxl: Math.round(baseSpacing.xxxl * scaleFactor),
        };
    }, [resolve]);

    // ==================== ICON SCALE ====================
    const icons = useMemo((): IconScale => {
        const baseIcons: IconScale = {
            xs: 12,
            sm: 16,
            md: 20,
            lg: 24,
            xl: 32,
            xxl: 48,
        };

        const scaleFactor = resolve({
            xs: 0.9,
            sm: 1,
            md: 1.1,
            lg: 1.2,
            xl: 1.3,
            default: 1,
        });

        return {
            xs: Math.round(baseIcons.xs * scaleFactor),
            sm: Math.round(baseIcons.sm * scaleFactor),
            md: Math.round(baseIcons.md * scaleFactor),
            lg: Math.round(baseIcons.lg * scaleFactor),
            xl: Math.round(baseIcons.xl * scaleFactor),
            xxl: Math.round(baseIcons.xxl * scaleFactor),
        };
    }, [resolve]);

    // ==================== GRID CONFIGURATION ====================
    const grid = useMemo((): GridConfig => {
        const config = resolve({
            xs: { columns: 1, gutter: 12, margin: 16 },
            sm: { columns: 2, gutter: 16, margin: 16 },
            md: { columns: 2, gutter: 20, margin: 24 },
            lg: { columns: 3, gutter: 24, margin: 32 },
            xl: { columns: 4, gutter: 32, margin: 48 },
            default: { columns: 2, gutter: 16, margin: 16 },
        });

        // Adjust for landscape
        if (layout.isLandscape && !layout.isDesktop) {
            return {
                ...config,
                columns: config.columns + 1,
            };
        }

        return config;
    }, [resolve, layout.isLandscape, layout.isDesktop]);

    // ==================== ACCESSIBILITY ====================
    const accessibility = useMemo((): AccessibilityConfig => ({
        // Minimum touch target (48dp for Android, 44pt for iOS)
        minTouchTarget: Platform.OS === 'ios' ? 44 : 48,
        reduceMotion,
        screenReaderEnabled,
        isHighContrast,
    }), [reduceMotion, screenReaderEnabled, isHighContrast]);

    // ==================== LAYOUT HELPERS ====================

    // Calculate item width for grid layouts
    const getGridItemWidth = useCallback((
        numColumns?: number,
        gutter?: number,
        containerPadding?: number
    ): number => {
        const cols = numColumns ?? grid.columns;
        const gap = gutter ?? grid.gutter;
        const padding = containerPadding ?? grid.margin;

        const availableWidth = safeAreas.usableWidth - (padding * 2);
        const totalGutters = gap * (cols - 1);

        return Math.floor((availableWidth - totalGutters) / cols);
    }, [grid, safeAreas.usableWidth]);

    // Get optimal container max width
    const getMaxContentWidth = useCallback((): number | string => {
        if (breakpoint === 'xs' || breakpoint === 'sm') {
            return '100%';
        }
        if (breakpoint === 'md') {
            return Math.min(width * 0.9, 700);
        }
        if (breakpoint === 'lg') {
            return Math.min(width * 0.85, 900);
        }
        return Math.min(width * 0.8, 1200);
    }, [breakpoint, width]);

    // Get column count for adaptive layouts
    const getColumns = useCallback((options?: {
        phone?: number;
        phoneLandscape?: number;
        tablet?: number;
        tabletLandscape?: number;
        desktop?: number;
    }): number => {
        const defaults = {
            phone: 1,
            phoneLandscape: 2,
            tablet: 2,
            tabletLandscape: 3,
            desktop: 4,
        };

        const config = { ...defaults, ...options };

        if (layout.isDesktop) return config.desktop;
        if (layout.isTablet) return layout.isLandscape ? config.tabletLandscape : config.tablet;
        return layout.isLandscape ? config.phoneLandscape : config.phone;
    }, [layout]);

    // ==================== BORDER RADIUS SCALE ====================
    const borderRadius = useMemo(() => ({
        none: 0,
        xs: moderateScale(4, 0.3),
        sm: moderateScale(8, 0.3),
        md: moderateScale(12, 0.3),
        lg: moderateScale(16, 0.3),
        xl: moderateScale(24, 0.3),
        full: 9999,
    }), [moderateScale]);

    // ==================== SHADOW SCALE ====================
    const shadows = useMemo(() => ({
        none: {
            shadowColor: 'transparent',
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: 0,
            shadowRadius: 0,
            elevation: 0,
        },
        sm: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.1,
            shadowRadius: 2,
            elevation: 2,
        },
        md: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.15,
            shadowRadius: 4,
            elevation: 4,
        },
        lg: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.2,
            shadowRadius: 8,
            elevation: 8,
        },
        xl: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.25,
            shadowRadius: 16,
            elevation: 16,
        },
    }), []);

    return {
        // Core layout info
        ...layout,
        safeAreas,

        // Breakpoint helpers
        breakpoint,
        is: (bp: Breakpoint) => breakpoint === bp,
        isAbove: (bp: Breakpoint) => width >= BREAKPOINTS[bp],
        isBelow: (bp: Breakpoint) => width < BREAKPOINTS[bp],

        // Value resolver
        resolve,

        // Scaling functions
        scale,
        scaleVertical,
        moderateScale,
        scaleFont,

        // Design tokens
        typography,
        spacing,
        icons,
        borderRadius,
        shadows,

        // Grid & layout
        grid,
        getGridItemWidth,
        getMaxContentWidth,
        getColumns,

        // Accessibility
        accessibility,

        // Color scheme
        colorScheme,
        isDarkMode: colorScheme === 'dark',
    };
}

// ==================== EXPORTS ====================
export type UseResponsiveReturn = ReturnType<typeof useResponsive>;

export default useResponsive;
