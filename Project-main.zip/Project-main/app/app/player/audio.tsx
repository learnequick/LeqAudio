import React from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import AudioPlayer from '@/components/AudioPlayer';

export default function AudioPlayerScreen() {
    const router = useRouter();
    const params = useLocalSearchParams();

    const { url, title, subtitle, thumbnail } = params;

    const handleBack = () => {
        router.back();
    };

    if (!url) {
        return null; // Or show error
    }

    return (
        <AudioPlayer
            audioUrl={url as string}
            title={title as string || 'Unknown Title'}
            subtitle={subtitle as string}
            thumbnailUrl={thumbnail as string}
            lessonId={params.lessonId ? Number(params.lessonId) : undefined}
            onBack={handleBack}
        />
    );
}
