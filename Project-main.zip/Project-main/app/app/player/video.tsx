import React from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import VideoPlayer from '@/components/VideoPlayer';

export default function VideoPlayerScreen() {
    const router = useRouter();
    const params = useLocalSearchParams();

    const { url, title, subtitle } = params;

    const handleBack = () => {
        router.back();
    };

    if (!url) {
        return null; // Or show error
    }

    return (
        <VideoPlayer
            videoUrl={url as string}
            title={title as string || 'Unknown Title'}
            subtitle={subtitle as string}
            lessonId={params.lessonId ? Number(params.lessonId) : undefined}
            onBack={handleBack}
        />
    );
}
