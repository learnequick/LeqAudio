/**
 * Terms & Conditions Screen
 */

import React from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/ui';

export default function TermsScreen() {
    const router = useRouter();

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <LinearGradient
                colors={[Colors.dark.primary, Colors.dark.secondary]}
                style={styles.header}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View style={styles.headerContent}>
                    <Ionicons name="document-text" size={32} color="white" />
                    <Text style={styles.headerTitle}>Terms & Conditions</Text>
                    <Text style={styles.headerSubtitle}>Please read these terms carefully</Text>
                </View>
            </LinearGradient>

            {/* Content */}
            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <ScreenContainer>
                    <View style={styles.card}>
                        <View style={styles.alertBox}>
                            <Ionicons
                                name="information-circle"
                                size={20}
                                color={Colors.dark.primary}
                            />
                            <Text style={styles.alertText}>
                                Welcome to LeQ. By accessing or using our services, you agree to be
                                bound by these Terms & Conditions. Please read them carefully.
                            </Text>
                        </View>

                        {/* Using the Service */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#667eea', '#764ba2']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="person-circle" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Using the Service</Text>
                                <Text style={styles.sectionText}>
                                    You must be at least 13 years old to create an account. You agree
                                    not to misuse the service or attempt to access other users'
                                    accounts.
                                </Text>
                            </View>
                        </View>

                        {/* Payments */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#f093fb', '#f5576c']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="card" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Payments</Text>
                                <Text style={styles.sectionText}>
                                    All payments are processed through our payment provider. Payments
                                    and refunds are subject to our Refund Policy.
                                </Text>
                            </View>
                        </View>

                        {/* Intellectual Property */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#4facfe', '#00f2fe']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="shield-checkmark" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Intellectual Property</Text>
                                <Text style={styles.sectionText}>
                                    All content on LeQ is owned by the platform or its licensors. You
                                    may not redistribute or copy content without permission.
                                </Text>
                            </View>
                        </View>

                        {/* Contact */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#fa709a', '#fee140']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="mail" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Contact</Text>
                                <Text style={styles.sectionText}>
                                    Questions about these terms should be sent to{' '}
                                    <Text style={styles.link}>legal@leq.example</Text>.
                                </Text>
                            </View>
                        </View>
                    </View>
                </ScreenContainer>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingVertical: 32,
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerContent: {
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: '700',
        color: 'white',
        marginTop: 12,
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    content: {
        flex: 1,
    },
    card: {
        backgroundColor: Colors.dark.card,
        margin: 16,
        borderRadius: 16,
        padding: 20,
    },
    alertBox: {
        flexDirection: 'row',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        borderLeftWidth: 4,
        borderLeftColor: Colors.dark.primary,
        padding: 16,
        borderRadius: 8,
        marginBottom: 24,
        gap: 12,
    },
    alertText: {
        flex: 1,
        fontSize: 14,
        color: Colors.dark.text,
        lineHeight: 22,
    },
    section: {
        flexDirection: 'row',
        marginBottom: 24,
        gap: 16,
    },
    iconBox: {
        width: 50,
        height: 50,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    sectionContent: {
        flex: 1,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    sectionText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 22,
    },
    link: {
        color: Colors.dark.primary,
        textDecorationLine: 'underline',
    },
});
