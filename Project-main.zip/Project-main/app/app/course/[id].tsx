/**
 * Course Detail Screen - Full course information
 */

import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Image,
    Alert,
    Dimensions
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors } from '@/constants/Colors';
import { CourseDetail, Module, Lesson } from '@/types';
import { courseService } from '@/services';
import { useAuthStore } from '@/context/authStore';
import { LoadingState, ErrorState, ScreenContainer } from '@/components/ui/index';
import { useResponsiveLayout, responsiveDimensions, typography, spacing } from '@/utils/responsive';

export default function CourseDetailScreen() {
    const { id } = useLocalSearchParams();
    const router = useRouter();
    const { isAuthenticated, user } = useAuthStore();
    const insets = useSafeAreaInsets();

    // Responsive layout
    const { isTablet, isLandscape, width, height, isSmallDevice } = useResponsiveLayout();

    // Dynamic dimensions
    const isLandscapeTablet = isTablet && isLandscape;

    // Calculate thumbnail height based on device size and orientation
    const getThumbnailHeight = () => {
        if (isLandscapeTablet) return height * 0.45; // Uses less vertical space in landscape
        if (isTablet) return 450;

        // For mobile devices, enforce 1:1 square aspect ratio
        return width;
    };

    const thumbnailHeight = getThumbnailHeight();

    const [isLoading, setIsLoading] = useState(true);
    const [isEnrolling, setIsEnrolling] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [course, setCourse] = useState<CourseDetail | null>(null);
    const [expandedModules, setExpandedModules] = useState<number[]>([]);

    const loadCourse = async () => {
        // Handle case where id is array or undefined
        const courseId = Array.isArray(id) ? id[0] : id;

        if (!courseId || courseId === 'undefined' || courseId === 'null') {
            console.warn('Invalid ID received:', id);
            setError('Invalid Course ID');
            setIsLoading(false);
            return;
        }

        try {
            setError(null);
            console.log('Loading course detail for ID:', courseId);
            const data = await courseService.getCourseDetail(courseId);
            setCourse(data);
            // Auto-expand first module
            if (data.modules?.length > 0) {
                setExpandedModules([data.modules[0].id]);
            }
        } catch (err: any) {
            console.error('Error loading course:', err);
            const errorMessage = err.response?.data?.detail || err.message || 'Failed to load course details.';
            setError(`${errorMessage} (ID: ${id})`);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        if (id) {
            loadCourse();
        }
    }, [id]);

    // Reload course when screen comes into focus (e.g., after payment)
    useFocusEffect(
        React.useCallback(() => {
            if (id) {
                console.log('Course screen focused, reloading data...');
                loadCourse();
            }
        }, [id])
    );

    const handleEnroll = async () => {
        if (!course) return;

        if (!isAuthenticated) {
            router.push('/(auth)/login');
            return;
        }

        if (course?.is_enrolled) {
            // Check for first lesson/module to resume
            if (course.modules && course.modules.length > 0 && course.modules[0].lessons && course.modules[0].lessons.length > 0) {
                handleLessonPress(course.modules[0].lessons[0]);
            } else {
                Alert.alert('Course Empty', 'This course does not have any content yet.');
            }
            return;
        }

        if (course?.is_free || user?.is_free_user) {
            // Free course - direct enrollment
            try {
                setIsEnrolling(true);
                await courseService.enrollCourse(course.id);
                Alert.alert('Success', 'You have been enrolled in this course!', [
                    { text: 'Start Learning', onPress: () => loadCourse() }
                ]);
                await loadCourse(); // Refresh to show enrolled state
            } catch (err: any) {
                Alert.alert('Error', err.response?.data?.error || 'Failed to enroll');
            } finally {
                setIsEnrolling(false);
            }
        } else {
            // Paid course - navigate to checkout
            if (course) {
                router.push({
                    pathname: '/payment/checkout',
                    params: { courseId: course.id }
                });
            }
        }
    };

    const handleLessonPress = (lesson: Lesson) => {
        // Allow access if enrolled (is_enrolled flag OR has enrollment_id) or if the lesson is a free preview
        // completed courses might have is_enrolled=false depending on API, but should have enrollment_id
        if (!course?.is_enrolled && !course?.enrollment_id && !lesson.is_free_preview) {
            Alert.alert('Locked', 'Please enroll in this course to access this lesson.');
            return;
        }

        const type = lesson.lesson_type === 'video' ? 'video' : 'audio';
        // Use actual URL from backend (supports YouTube links and direct audio/video files)
        const contentUrl = type === 'video' ? lesson.video_url : lesson.audio_url;

        if (!contentUrl) {
            Alert.alert('Error', 'No content URL available for this lesson.');
            console.error('[Course] Missing content URL for lesson:', lesson.id, lesson.title);
            return;
        }

        console.log('[Course] Opening lesson:', lesson.title);
        console.log('[Course] Content URL:', contentUrl);
        console.log('[Course] Type:', type);

        router.push({
            pathname: `/player/${type}`,
            params: {
                url: contentUrl,
                title: lesson.title,
                subtitle: course?.title,
                thumbnail: course?.thumbnail_url,
                lessonId: lesson.id
            }
        });
    };

    const toggleModule = (moduleId: number) => {
        setExpandedModules(prev =>
            prev.includes(moduleId)
                ? prev.filter(id => id !== moduleId)
                : [...prev, moduleId]
        );
    };

    const formatDuration = (minutes: number) => {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        if (hours > 0) {
            return `${hours}h ${mins}m`;
        }
        return `${mins} min`;
    };

    if (isLoading) {
        return <LoadingState message="Loading course..." />;
    }

    if (error || !course) {
        return <ErrorState message={error || 'Course not found'} onRetry={loadCourse} />;
    }

    return (
        <>
            <Stack.Screen
                options={{
                    headerTitle: '',
                    headerTransparent: false,
                    headerTintColor: '#fff',
                    headerStyle: { backgroundColor: Colors.dark.background },
                    headerShadowVisible: false,
                }}
            />

            <ScrollView
                style={styles.container}
                showsVerticalScrollIndicator={false}
            >
                {/* Course Thumbnail */}
                <View style={[styles.thumbnailContainer, { height: thumbnailHeight }]}>
                    {course.thumbnail_url ? (
                        <Image
                            source={{ uri: course.thumbnail_url }}
                            style={styles.thumbnail}
                            resizeMode="contain"
                        />
                    ) : (
                        <LinearGradient
                            colors={[Colors.dark.primary, Colors.dark.secondary]}
                            style={styles.thumbnailPlaceholder}
                        >
                            <Ionicons name="musical-notes" size={64} color="rgba(255,255,255,0.5)" />
                        </LinearGradient>
                    )}
                    <LinearGradient
                        colors={['transparent', Colors.dark.background]}
                        style={styles.thumbnailOverlay}
                    />
                </View>

                {/* Course Info */}
                <ScreenContainer>
                    <View style={[
                        styles.content,
                        isLandscapeTablet && styles.contentLandscape
                    ]}>
                        <View style={[
                            styles.mainColumn,
                            isLandscapeTablet && styles.leftColumn
                        ]}>
                            {/* Category & Level */}
                            <View style={styles.tags}>
                                <View style={styles.tag}>
                                    <Text style={styles.tagText}>{course.category?.name || 'General'}</Text>
                                </View>
                                <View style={[styles.tag, styles.levelTag]}>
                                    <Text style={styles.tagText}>{course.level}</Text>
                                </View>
                            </View>

                            {/* Title */}
                            <Text style={styles.title}>{course.title}</Text>

                            {/* Teacher */}
                            <View style={styles.teacherRow}>
                                <View style={styles.teacherAvatar}>
                                    {course.teacher?.profile_picture_url ? (
                                        <Image
                                            source={{ uri: course.teacher.profile_picture_url }}
                                            style={styles.teacherImage}
                                        />
                                    ) : (
                                        <Ionicons name="person" size={16} color={Colors.dark.textMuted} />
                                    )}
                                </View>
                                <Text style={styles.teacherName}>
                                    {course.teacher?.full_name || 'Unknown Instructor'}
                                </Text>
                            </View>

                            {/* Description */}
                            {!course.is_enrolled && (
                                <View style={styles.section}>
                                    <Text style={styles.sectionTitle}>About this course</Text>
                                    <Text style={styles.description}>{course.description || course.short_description}</Text>
                                </View>
                            )}
                        </View>

                        {/* Curriculum Column - Moves to right on Landscape Tablet */}
                        <View style={[
                            styles.curriculumColumn,
                            isLandscapeTablet && styles.rightColumn
                        ]}>
                            {course.modules && course.modules.length > 0 && (
                                <View style={[styles.section, isLandscapeTablet && { marginTop: 0 }]}>
                                    <Text style={styles.sectionTitle}>
                                        Curriculum ({course.total_lessons} lessons)
                                    </Text>

                                    {course.modules.map((module) => (
                                        <View key={module.id} style={styles.moduleContainer}>
                                            <TouchableOpacity
                                                style={styles.moduleHeader}
                                                onPress={() => toggleModule(module.id)}
                                            >
                                                <View style={styles.moduleInfo}>
                                                    <Text style={styles.moduleTitle}>{module.title}</Text>
                                                    <Text style={styles.moduleCount}>
                                                        {module.lessons?.length || 0} lessons
                                                    </Text>
                                                </View>
                                                <Ionicons
                                                    name={expandedModules.includes(module.id) ? 'chevron-up' : 'chevron-down'}
                                                    size={20}
                                                    color={Colors.dark.textMuted}
                                                />
                                            </TouchableOpacity>

                                            {expandedModules.includes(module.id) && module.lessons && (
                                                <View style={styles.lessonsContainer}>
                                                    {module.lessons.map((lesson, index) => (
                                                        <TouchableOpacity
                                                            key={lesson.id}
                                                            style={styles.lessonItem}
                                                            onPress={() => handleLessonPress(lesson)}
                                                        >
                                                            <View style={styles.lessonLeft}>
                                                                <View style={[
                                                                    styles.lessonNumber,
                                                                    { backgroundColor: `${Colors.dark.primary}20` }
                                                                ]}>
                                                                    <Ionicons
                                                                        name={lesson.lesson_type === 'video' ? 'videocam' : 'headset'}
                                                                        size={14}
                                                                        color={Colors.dark.primary}
                                                                    />
                                                                </View>
                                                                <View style={styles.lessonInfo}>
                                                                    <Text style={[
                                                                        styles.lessonTitle,
                                                                        !(course.is_enrolled || lesson.is_free_preview) && { color: Colors.dark.textMuted }
                                                                    ]}>{lesson.title}</Text>
                                                                </View>
                                                            </View>
                                                            {lesson.is_free_preview ? (
                                                                <View style={styles.freeTag}>
                                                                    <Text style={styles.freeTagText}>Free</Text>
                                                                </View>
                                                            ) : (
                                                                !course.is_enrolled && <Ionicons name="lock-closed" size={16} color={Colors.dark.textMuted} />
                                                            )}
                                                        </TouchableOpacity>
                                                    ))}
                                                </View>
                                            )}
                                        </View>
                                    ))}
                                </View>
                            )}
                        </View>

                        {/* Spacing for bottom button */}
                        <View style={{ width: '100%', height: course.is_enrolled ? 20 : 120 }} />
                    </View>
                </ScreenContainer>
            </ScrollView>

            {/* Bottom CTA */}
            {!course.is_enrolled && (
                <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, 16) }]}>
                    <ScreenContainer style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <View style={styles.priceContainer}>
                            {course.is_free || user?.is_free_user ? (
                                <Text style={styles.freePrice}>Free</Text>
                            ) : (
                                <>
                                    <Text style={styles.currentPrice}>
                                        ₹{(course.discount_price || course.price).toLocaleString('en-IN')}
                                    </Text>
                                    {course.discount_price && course.discount_price < course.price && (
                                        <Text style={styles.originalPrice}>
                                            ₹{course.price.toLocaleString('en-IN')}
                                        </Text>
                                    )}
                                </>
                            )}
                        </View>

                        <TouchableOpacity
                            style={styles.enrollButton}
                            onPress={handleEnroll}
                            disabled={isEnrolling}
                        >
                            <LinearGradient
                                colors={course.is_enrolled
                                    ? [Colors.dark.success, Colors.dark.success]
                                    : [Colors.dark.primary, Colors.dark.secondary]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={styles.enrollGradient}
                            >
                                {course.is_enrolled ? (
                                    <>
                                        <Ionicons name="play-circle" size={20} color="#fff" />
                                        <Text style={styles.enrollText}>Continue Learning</Text>
                                    </>
                                ) : (
                                    <Text style={styles.enrollText}>
                                        {isEnrolling ? 'Enrolling...' : (course.is_free || user?.is_free_user ? 'Enroll for Free' : 'Enroll Now')}
                                    </Text>
                                )}
                            </LinearGradient>
                        </TouchableOpacity>
                    </ScreenContainer>
                </View>
            )}
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    thumbnailContainer: {
        // height set dynamically in JSX
        position: 'relative',
        backgroundColor: '#000',
    },
    thumbnail: {
        width: '100%',
        height: '100%',
    },
    thumbnailPlaceholder: {
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    thumbnailOverlay: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: 100,
    },
    content: {
        padding: spacing.xl,
        marginTop: -40,
    },
    tags: {
        flexDirection: 'row',
        gap: spacing.sm,
        marginBottom: spacing.md,
    },
    tag: {
        backgroundColor: `${Colors.dark.primary}20`,
        paddingHorizontal: spacing.md,
        paddingVertical: 6,
        borderRadius: 16,
    },
    levelTag: {
        backgroundColor: `${Colors.dark.secondary}20`,
    },
    tagText: {
        fontSize: typography.caption,
        fontWeight: '600',
        color: Colors.dark.primary,
        textTransform: 'capitalize',
    },
    title: {
        fontSize: typography.h3,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: spacing.md,
        lineHeight: typography.h3 * 1.3,
    },
    teacherRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.sm,
        marginBottom: spacing.lg,
    },
    teacherAvatar: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: Colors.dark.card,
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
    },
    teacherImage: {
        width: '100%',
        height: '100%',
    },
    teacherName: {
        fontSize: typography.bodySmall,
        color: Colors.dark.textSecondary,
    },
    statsRow: {
        flexDirection: 'row',
        gap: spacing.xl,
        paddingVertical: spacing.lg,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: Colors.dark.border,
    },
    stat: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    statText: {
        fontSize: typography.bodySmall,
        fontWeight: '600',
        color: Colors.dark.text,
    },
    statLabel: {
        fontSize: typography.caption,
        color: Colors.dark.textMuted,
    },
    section: {
        marginTop: spacing.xl,
    },
    sectionTitle: {
        fontSize: typography.h5,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: spacing.md,
    },
    description: {
        fontSize: typography.body,
        color: Colors.dark.textSecondary,
        lineHeight: typography.body * 1.5,
    },
    moduleContainer: {
        backgroundColor: Colors.dark.card,
        borderRadius: 14,
        marginBottom: spacing.sm,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    moduleHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: spacing.lg,
    },
    moduleInfo: {
        flex: 1,
    },
    moduleTitle: {
        fontSize: typography.body,
        fontWeight: '600',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    moduleCount: {
        fontSize: typography.caption,
        color: Colors.dark.textMuted,
    },
    lessonsContainer: {
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
    },
    lessonItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.md,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    lessonLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.md,
        flex: 1,
    },
    lessonNumber: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: Colors.dark.backgroundSecondary,
        justifyContent: 'center',
        alignItems: 'center',
    },
    lessonNumberText: {
        fontSize: typography.caption,
        fontWeight: '600',
        color: Colors.dark.textMuted,
    },
    lessonInfo: {
        flex: 1,
    },
    lessonTitle: {
        fontSize: typography.bodySmall,
        color: Colors.dark.text,
        marginBottom: 2,
    },
    lessonDuration: {
        fontSize: typography.caption,
        color: Colors.dark.textMuted,
    },
    freeTag: {
        backgroundColor: `${Colors.dark.success}20`,
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
    },
    freeTagText: {
        fontSize: typography.tiny,
        fontWeight: '600',
        color: Colors.dark.success,
    },
    bottomBar: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: spacing.lg,
        backgroundColor: Colors.dark.backgroundSecondary,
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
    },
    priceContainer: {
        flexDirection: 'row',
        alignItems: 'baseline',
        gap: spacing.sm,
    },
    freePrice: {
        fontSize: typography.h4,
        fontWeight: '700',
        color: Colors.dark.success,
    },
    currentPrice: {
        fontSize: typography.h4,
        fontWeight: '700',
        color: Colors.dark.text,
    },
    originalPrice: {
        fontSize: typography.bodySmall,
        color: Colors.dark.textMuted,
        textDecorationLine: 'line-through',
    },
    enrollButton: {
        flex: 1,
        marginLeft: spacing.lg,
        borderRadius: 24,
        overflow: 'hidden',
    },
    enrollGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 14,
        gap: 8,
    },
    enrollText: {
        fontSize: typography.body,
        fontWeight: '600',
        color: '#fff',
    },
    // New layout styles
    contentLandscape: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: spacing.xl,
        alignItems: 'flex-start',
    },
    mainColumn: {
        width: '100%',
    },
    leftColumn: {
        flex: 1,
        minWidth: 300,
    },
    curriculumColumn: {
        width: '100%',
    },
    rightColumn: {
        flex: 0.8,
        minWidth: 300,
    },
});
