/**
 * Splash Screen - App logo with loading animation
 */

import { useEffect } from 'react';
import { View, Text, StyleSheet, Image, Animated } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuthStore } from '@/context/authStore';
import { Colors } from '@/constants/Colors';

export default function SplashScreen() {
    const router = useRouter();
    const { isInitialized, isAuthenticated, hasSeenOnboarding } = useAuthStore();
    const pulseAnim = new Animated.Value(1);

    // Pulse animation
    useEffect(() => {
        Animated.loop(
            Animated.sequence([
                Animated.timing(pulseAnim, {
                    toValue: 1.1,
                    duration: 1000,
                    useNativeDriver: true,
                }),
                Animated.timing(pulseAnim, {
                    toValue: 1,
                    duration: 1000,
                    useNativeDriver: true,
                }),
            ])
        ).start();
    }, []);

    // Navigate when initialized
    useEffect(() => {
        if (isInitialized) {
            const timer = setTimeout(() => {
                if (isAuthenticated) {
                    router.replace('/(tabs)');
                } else if (!hasSeenOnboarding) {
                    router.replace('/(auth)/onboarding');
                } else {
                    router.replace('/(auth)/login');
                }
            }, 1500);
            return () => clearTimeout(timer);
        }
    }, [isInitialized, isAuthenticated, hasSeenOnboarding]);

    return (
        <View style={styles.container}>
            <Animated.View style={[styles.logoContainer, { transform: [{ scale: pulseAnim }] }]}>
                <View style={styles.logoCircle}>
                    <Text style={styles.logoText}>LeQ</Text>
                </View>
            </Animated.View>
            <Text style={styles.tagline}>India's #1 Audio Learning Platform</Text>
            <View style={styles.loadingContainer}>
                <View style={styles.loadingDot} />
                <View style={[styles.loadingDot, styles.loadingDotDelayed]} />
                <View style={[styles.loadingDot, styles.loadingDotDelayed2]} />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logoContainer: {
        marginBottom: 24,
    },
    logoCircle: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: Colors.dark.primary,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: Colors.dark.primary,
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.4,
        shadowRadius: 24,
        elevation: 10,
    },
    logoText: {
        fontSize: 40,
        fontWeight: '800',
        color: '#fff',
    },
    tagline: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginTop: 8,
    },
    loadingContainer: {
        flexDirection: 'row',
        gap: 8,
        marginTop: 40,
    },
    loadingDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: Colors.dark.primary,
        opacity: 0.8,
    },
    loadingDotDelayed: {
        opacity: 0.5,
    },
    loadingDotDelayed2: {
        opacity: 0.3,
    },
});
