/**
 * OTP Verification Screen - Verify email after signup OR password reset
 */

import React, { useState, useRef, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Alert,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '@/context/authStore';
import { authService } from '@/services';
import { Colors } from '@/constants/Colors';
import { ScreenContainer } from '@/components/ui';

export default function VerifyOTPScreen() {
    const router = useRouter();
    const params = useLocalSearchParams<{
        user_id?: string;
        email: string;
        from?: string; // 'signup' or 'password_reset'
    }>();
    const { verifySignupOTP, resendSignupOTP, isLoading } = useAuthStore();

    const [otp, setOtp] = useState(['', '', '', '', '', '']);
    const [error, setError] = useState('');
    const [resendTimer, setResendTimer] = useState(60);
    const [isVerifying, setIsVerifying] = useState(false);
    const inputRefs = useRef<(TextInput | null)[]>([]);

    const isPasswordReset = params.from === 'password_reset';
    const isSignup = params.from === 'signup';

    // Countdown timer for resend
    useEffect(() => {
        if (resendTimer > 0) {
            const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
            return () => clearTimeout(timer);
        }
    }, [resendTimer]);

    const handleOtpChange = (value: string, index: number) => {
        if (!/^\d*$/.test(value)) return; // Only allow digits

        const newOtp = [...otp];
        newOtp[index] = value;
        setOtp(newOtp);
        setError('');

        // Auto-focus next input
        if (value && index < 5) {
            inputRefs.current[index + 1]?.focus();
        }

        // Auto-submit when all 6 digits are entered
        if (index === 5 && value && newOtp.every(digit => digit)) {
            handleVerify(newOtp.join(''));
        }
    };

    const handleKeyPress = (e: any, index: number) => {
        if (e.nativeEvent.key === 'Backspace' && !otp[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handleVerify = async (otpCode?: string) => {
        const otpValue = otpCode || otp.join('');

        if (otpValue.length !== 6) {
            setError('Please enter the complete 6-digit OTP');
            return;
        }

        setIsVerifying(true);

        try {
            if (isSignup && params.user_id) {
                // Signup OTP verification
                await verifySignupOTP(parseInt(params.user_id), otpValue);
                router.replace('/(tabs)');
            } else if (isPasswordReset) {
                // Password reset OTP verification
                const response = await authService.verifyResetOTP({
                    email: params.email,
                    otp: otpValue
                });

                // Navigate to reset password screen with token
                router.replace({
                    pathname: '/(auth)/reset-password',
                    params: {
                        email: params.email,
                        reset_token: response.reset_token,
                        user_id: response.user_id.toString()
                    }
                });
            }
        } catch (error: any) {
            const errorMsg = error.response?.data?.error || 'Invalid OTP. Please try again.';
            setError(errorMsg);
            setOtp(['', '', '', '', '', '']);
            inputRefs.current[0]?.focus();
        } finally {
            setIsVerifying(false);
        }
    };

    const handleResend = async () => {
        if (resendTimer > 0) return;

        try {
            if (isSignup && params.user_id) {
                await resendSignupOTP(parseInt(params.user_id), params.email);
            } else if (isPasswordReset) {
                await authService.forgotPassword({ email: params.email });
            }

            setResendTimer(60);
            Alert.alert('Success', 'OTP has been resent to your email');
        } catch (error: any) {
            Alert.alert('Error', error.response?.data?.error || 'Failed to resend OTP');
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <ScreenContainer>
                {/* Header */}
                <View style={styles.header}>
                    <View style={styles.iconContainer}>
                        <Ionicons
                            name={isPasswordReset ? "lock-closed-outline" : "mail-outline"}
                            size={60}
                            color={Colors.dark.primary}
                        />
                    </View>
                    <Text style={styles.title}>
                        {isPasswordReset ? 'Verify Reset Code' : 'Verify Your Email'}
                    </Text>
                    <Text style={styles.subtitle}>
                        We've sent a 6-digit code to{'\n'}
                        <Text style={styles.email}>{params.email}</Text>
                    </Text>
                </View>

                {/* OTP Input */}
                <View style={styles.otpContainer}>
                    {otp.map((digit, index) => (
                        <TextInput
                            key={index}
                            ref={ref => { inputRefs.current[index] = ref; }}
                            style={[
                                styles.otpInput,
                                digit && styles.otpInputFilled,
                                error && styles.otpInputError
                            ]}
                            value={digit}
                            onChangeText={(value) => handleOtpChange(value, index)}
                            onKeyPress={(e) => handleKeyPress(e, index)}
                            keyboardType="number-pad"
                            maxLength={1}
                            selectTextOnFocus
                            autoFocus={index === 0}
                        />
                    ))}
                </View>

                {error ? <Text style={styles.errorText}>{error}</Text> : null}

                {/* Verify Button */}
                <TouchableOpacity
                    style={styles.verifyButton}
                    onPress={() => handleVerify()}
                    disabled={isVerifying || otp.join('').length !== 6}
                >
                    <LinearGradient
                        colors={[Colors.dark.primary, Colors.dark.secondary]}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.verifyGradient}
                    >
                        <Text style={styles.verifyText}>
                            {isVerifying ? 'Verifying...' : isPasswordReset ? 'Verify Code' : 'Verify Email'}
                        </Text>
                    </LinearGradient>
                </TouchableOpacity>

                {/* Resend */}
                <View style={styles.resendContainer}>
                    <Text style={styles.resendText}>Didn't receive the code? </Text>
                    {resendTimer > 0 ? (
                        <Text style={styles.timerText}>Resend in {resendTimer}s</Text>
                    ) : (
                        <TouchableOpacity onPress={handleResend}>
                            <Text style={styles.resendLink}>Resend OTP</Text>
                        </TouchableOpacity>
                    )}
                </View>
            </ScreenContainer>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        alignItems: 'center',
        marginTop: 60,
        marginBottom: 40,
    },
    iconContainer: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: `${Colors.dark.primary}20`,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 24,
    },
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 12,
    },
    subtitle: {
        fontSize: 15,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        lineHeight: 22,
    },
    email: {
        color: Colors.dark.primary,
        fontWeight: '600',
    },
    otpContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 16,
        paddingHorizontal: 10,
    },
    otpInput: {
        width: 50,
        height: 60,
        borderRadius: 12,
        borderWidth: 2,
        borderColor: Colors.dark.border,
        backgroundColor: Colors.dark.card,
        fontSize: 24,
        fontWeight: '600',
        color: Colors.dark.text,
        textAlign: 'center',
    },
    otpInputFilled: {
        borderColor: Colors.dark.primary,
        backgroundColor: `${Colors.dark.primary}10`,
    },
    otpInputError: {
        borderColor: Colors.dark.danger,
    },
    errorText: {
        color: Colors.dark.danger,
        fontSize: 14,
        textAlign: 'center',
        marginBottom: 16,
    },
    verifyButton: {
        borderRadius: 28,
        overflow: 'hidden',
        marginTop: 8,
        marginBottom: 24,
    },
    verifyGradient: {
        paddingVertical: 16,
        alignItems: 'center',
    },
    verifyText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#fff',
    },
    resendContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    resendText: {
        color: Colors.dark.textSecondary,
        fontSize: 14,
    },
    timerText: {
        color: Colors.dark.textMuted,
        fontSize: 14,
    },
    resendLink: {
        color: Colors.dark.primary,
        fontSize: 14,
        fontWeight: '600',
    },
});
