/**
 * Signup Screen - User registration
 */

import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    Alert,
    Image
} from 'react-native';
import { useRouter, Link } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '@/context/authStore';
import { Colors } from '@/constants/Colors';
import { ScreenContainer } from '@/components/ui';

export default function SignupScreen() {
    const router = useRouter();
    const { register, isLoading } = useAuthStore();

    const [formData, setFormData] = useState({
        email: '',
        first_name: '',
        last_name: '',
        phone: '',
        password: '',
        password_confirm: '',
    });
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const updateField = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: '' }));
        }
    };

    const validate = () => {
        const newErrors: Record<string, string> = {};

        if (!formData.first_name.trim()) {
            newErrors.first_name = 'First name is required';
        }

        if (!formData.last_name.trim()) {
            newErrors.last_name = 'Last name is required';
        }

        if (!formData.email.trim()) {
            newErrors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'Please enter a valid email';
        }

        if (!formData.phone.trim()) {
            newErrors.phone = 'Phone number is required';
        } else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
            newErrors.phone = 'Please enter a valid 10-digit phone number';
        }

        if (!formData.password) {
            newErrors.password = 'Password is required';
        } else if (formData.password.length < 8) {
            newErrors.password = 'Password must be at least 8 characters';
        }

        if (formData.password !== formData.password_confirm) {
            newErrors.password_confirm = 'Passwords do not match';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSignup = async () => {
        if (!validate()) return;

        try {
            const response = await register({
                email: formData.email.trim(),
                first_name: formData.first_name.trim(),
                last_name: formData.last_name.trim(),
                phone: formData.phone.trim(),
                password: formData.password,
                password_confirm: formData.password_confirm,
            });

            // Navigate to OTP verification screen
            router.push({
                pathname: '/(auth)/verify-otp',
                params: {
                    user_id: response.user_id.toString(),
                    email: response.email,
                    from: 'signup'
                }
            });
        } catch (error: any) {
            const errorData = error.response?.data;
            if (errorData && typeof errorData === 'object') {
                const newErrors: Record<string, string> = {};
                Object.keys(errorData).forEach(key => {
                    const messages = errorData[key];
                    newErrors[key] = Array.isArray(messages) ? messages[0] : messages;
                });
                setErrors(newErrors);
            } else {
                Alert.alert('Registration Failed', 'An error occurred. Please try again.');
            }
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <ScrollView
                contentContainerStyle={styles.scrollContent}
                keyboardShouldPersistTaps="handled"
            >
                <ScreenContainer>
                    {/* Header */}
                    <View style={styles.header}>
                        <Image
                            source={require('../../assets/images/Logo.png')}
                            style={styles.logoImage}
                        />
                        <Text style={styles.welcomeText}>Create Account</Text>
                        <Text style={styles.subtitleText}>Start your learning journey today</Text>
                    </View>

                    {/* Form */}
                    <View style={styles.form}>
                        {/* Name Row */}
                        <View style={styles.row}>
                            <View style={[styles.inputContainer, styles.halfInput]}>
                                <TextInput
                                    style={styles.input}
                                    placeholder="First Name"
                                    placeholderTextColor={Colors.dark.textMuted}
                                    value={formData.first_name}
                                    onChangeText={(v) => updateField('first_name', v)}
                                    autoCapitalize="words"
                                />
                            </View>
                            <View style={[styles.inputContainer, styles.halfInput]}>
                                <TextInput
                                    style={styles.input}
                                    placeholder="Last Name"
                                    placeholderTextColor={Colors.dark.textMuted}
                                    value={formData.last_name}
                                    onChangeText={(v) => updateField('last_name', v)}
                                    autoCapitalize="words"
                                />
                            </View>
                        </View>
                        {(errors.first_name || errors.last_name) && (
                            <Text style={styles.errorText}>{errors.first_name || errors.last_name}</Text>
                        )}

                        {/* Email */}
                        <View style={styles.inputContainer}>
                            <Ionicons name="mail-outline" size={20} color={Colors.dark.textMuted} style={styles.inputIcon} />
                            <TextInput
                                style={styles.input}
                                placeholder="Email"
                                placeholderTextColor={Colors.dark.textMuted}
                                value={formData.email}
                                onChangeText={(v) => updateField('email', v)}
                                keyboardType="email-address"
                                autoCapitalize="none"
                                autoComplete="email"
                            />
                        </View>
                        {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

                        {/* Phone */}
                        <View style={styles.inputContainer}>
                            <Ionicons name="call-outline" size={20} color={Colors.dark.textMuted} style={styles.inputIcon} />
                            <TextInput
                                style={styles.input}
                                placeholder="Phone Number"
                                placeholderTextColor={Colors.dark.textMuted}
                                value={formData.phone}
                                onChangeText={(v) => updateField('phone', v)}
                                keyboardType="phone-pad"
                            />
                        </View>
                        {errors.phone && <Text style={styles.errorText}>{errors.phone}</Text>}

                        {/* Password */}
                        <View style={styles.inputContainer}>
                            <Ionicons name="lock-closed-outline" size={20} color={Colors.dark.textMuted} style={styles.inputIcon} />
                            <TextInput
                                style={styles.input}
                                placeholder="Password"
                                placeholderTextColor={Colors.dark.textMuted}
                                value={formData.password}
                                onChangeText={(v) => updateField('password', v)}
                                secureTextEntry={!showPassword}
                                autoCapitalize="none"
                            />
                            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                                <Ionicons
                                    name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                                    size={20}
                                    color={Colors.dark.textMuted}
                                />
                            </TouchableOpacity>
                        </View>
                        {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

                        {/* Confirm Password */}
                        <View style={styles.inputContainer}>
                            <Ionicons name="lock-closed-outline" size={20} color={Colors.dark.textMuted} style={styles.inputIcon} />
                            <TextInput
                                style={styles.input}
                                placeholder="Confirm Password"
                                placeholderTextColor={Colors.dark.textMuted}
                                value={formData.password_confirm}
                                onChangeText={(v) => updateField('password_confirm', v)}
                                secureTextEntry={!showPassword}
                                autoCapitalize="none"
                            />
                        </View>
                        {errors.password_confirm && <Text style={styles.errorText}>{errors.password_confirm}</Text>}

                        {/* Signup Button */}
                        <TouchableOpacity
                            style={styles.signupButton}
                            onPress={handleSignup}
                            disabled={isLoading}
                        >
                            <LinearGradient
                                colors={[Colors.dark.primary, Colors.dark.secondary]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={styles.signupGradient}
                            >
                                <Text style={styles.signupText}>
                                    {isLoading ? 'Creating Account...' : 'Create Account'}
                                </Text>
                            </LinearGradient>
                        </TouchableOpacity>

                        {/* Login Link */}
                        <View style={styles.loginContainer}>
                            <Text style={styles.loginText}>Already have an account? </Text>
                            <Link href="/(auth)/login" asChild>
                                <TouchableOpacity>
                                    <Text style={styles.loginLink}>Sign In</Text>
                                </TouchableOpacity>
                            </Link>
                        </View>
                    </View>
                </ScreenContainer>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    scrollContent: {
        flexGrow: 1,
        paddingHorizontal: 24,
        paddingTop: 60,
        paddingBottom: 40,
    },
    header: {
        alignItems: 'center',
        marginBottom: 32,
    },
    logoImage: {
        width: 80,
        height: 80,
        marginBottom: 16,
        resizeMode: 'contain',
    },
    welcomeText: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    subtitleText: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    form: {
        flex: 1,
    },
    row: {
        flexDirection: 'row',
        gap: 12,
        marginBottom: 12,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: Colors.dark.border,
        paddingHorizontal: 16,
        marginBottom: 12,
    },
    halfInput: {
        flex: 1,
        marginBottom: 0,
    },
    inputIcon: {
        marginRight: 12,
    },
    input: {
        flex: 1,
        paddingVertical: 16,
        fontSize: 15,
        color: Colors.dark.text,
    },
    errorText: {
        color: Colors.dark.danger,
        fontSize: 12,
        marginTop: -8,
        marginBottom: 12,
        marginLeft: 4,
    },
    signupButton: {
        borderRadius: 28,
        overflow: 'hidden',
        marginTop: 12,
        marginBottom: 24,
    },
    signupGradient: {
        paddingVertical: 16,
        alignItems: 'center',
    },
    signupText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#fff',
    },
    loginContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    loginText: {
        color: Colors.dark.textSecondary,
        fontSize: 14,
    },
    loginLink: {
        color: Colors.dark.primary,
        fontSize: 14,
        fontWeight: '600',
    },
});
