/**
 * Onboarding Screen - Intro slides for first-time users
 */

import React, { useState, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Dimensions,
    NativeSyntheticEvent,
    NativeScrollEvent
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '@/context/authStore';
import { Colors } from '@/constants/Colors';
import { ScreenContainer } from '@/components/ui';

const { width, height } = Dimensions.get('window');

interface Slide {
    id: number;
    icon: keyof typeof Ionicons.glyphMap;
    title: string;
    description: string;
    colors: string[];
}

const slides: Slide[] = [
    {
        id: 1,
        icon: 'headset',
        title: 'Learn On The Go',
        description: 'Listen to courses while commuting, exercising, or doing daily tasks. Transform every moment into a learning opportunity.',
        colors: [Colors.dark.primary, Colors.dark.secondary],
    },
    {
        id: 2,
        icon: 'cloud-download',
        title: 'Offline Learning',
        description: 'Download courses and listen offline without internet. Learn anywhere, anytime, without any interruptions.',
        colors: ['#EC4899', '#D946EF'],
    },
    {
        id: 3,
        icon: 'ribbon',
        title: 'Earn Certificates',
        description: 'Complete courses and earn verified certificates to showcase your skills and achievements to the world.',
        colors: ['#10B981', '#06B6D4'],
    },
];

export default function OnboardingScreen() {
    const router = useRouter();
    const { setHasSeenOnboarding } = useAuthStore();
    const scrollViewRef = useRef<ScrollView>(null);
    const [activeIndex, setActiveIndex] = useState(0);

    const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
        const contentOffset = event.nativeEvent.contentOffset.x;
        const index = Math.round(contentOffset / width);
        if (index !== activeIndex && index >= 0 && index < slides.length) {
            setActiveIndex(index);
        }
    };

    const handleNext = () => {
        if (activeIndex < slides.length - 1) {
            scrollViewRef.current?.scrollTo({
                x: (activeIndex + 1) * width,
                animated: true,
            });
            setActiveIndex(activeIndex + 1);
        } else {
            handleComplete();
        }
    };

    const handleSkip = () => {
        handleComplete();
    };

    const handleComplete = async () => {
        await setHasSeenOnboarding(true);
        router.replace('/(auth)/login');
    };

    return (
        <View style={styles.container}>
            {/* Skip button */}
            <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
                <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>

            {/* Slides */}
            <ScrollView
                ref={scrollViewRef}
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onScroll={handleScroll}
                scrollEventThrottle={16}
            >
                {slides.map((slide, index) => (
                    <View key={slide.id} style={styles.slide}>
                        <ScreenContainer>
                            <View style={styles.slideContent}>
                                {/* Icon with gradient background */}
                                <LinearGradient
                                    colors={slide.colors as [string, string]}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                    style={styles.iconContainer}
                                >
                                    <Ionicons name={slide.icon} size={80} color="#fff" />
                                </LinearGradient>

                                <Text style={styles.title}>{slide.title}</Text>
                                <Text style={styles.description}>{slide.description}</Text>
                            </View>
                        </ScreenContainer>
                    </View>
                ))}
            </ScrollView>

            {/* Pagination */}
            <View style={styles.pagination}>
                {slides.map((_, index) => (
                    <View
                        key={index}
                        style={[
                            styles.dot,
                            index === activeIndex && styles.activeDot,
                        ]}
                    />
                ))}
            </View>

            {/* Continue button */}
            <TouchableOpacity style={styles.continueButton} onPress={handleNext}>
                <LinearGradient
                    colors={[Colors.dark.primary, Colors.dark.secondary]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.continueGradient}
                >
                    <Text style={styles.continueText}>
                        {activeIndex === slides.length - 1 ? 'Get Started' : 'Continue'}
                    </Text>
                    <Ionicons name="arrow-forward" size={18} color="#fff" />
                </LinearGradient>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    skipButton: {
        position: 'absolute',
        top: 60,
        right: 24,
        zIndex: 10,
    },
    skipText: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        fontWeight: '500',
    },
    slide: {
        width,
        paddingHorizontal: 0, // Remove padding as ScreenContainer handles it or inner view
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 100,
    },
    slideContent: {
        alignItems: 'center',
        paddingHorizontal: 20,
    },
    iconContainer: {
        width: 160,
        height: 160,
        borderRadius: 80,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 48,
        shadowColor: Colors.dark.primary,
        shadowOffset: { width: 0, height: 12 },
        shadowOpacity: 0.4,
        shadowRadius: 32,
        elevation: 12,
    },
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.text,
        textAlign: 'center',
        marginBottom: 16,
    },
    description: {
        fontSize: 15,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        lineHeight: 24,
        paddingHorizontal: 20,
    },
    pagination: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        marginBottom: 32,
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: Colors.dark.textMuted,
    },
    activeDot: {
        width: 24,
        backgroundColor: Colors.dark.primary,
    },
    continueButton: {
        marginHorizontal: 24,
        marginBottom: 50,
        borderRadius: 28,
        overflow: 'hidden',
    },
    continueGradient: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 16,
        gap: 8,
    },
    continueText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#fff',
    },
});
