/**
 * About Screen
 */

import React from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/ui';

export default function AboutScreen() {
    const router = useRouter();

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <LinearGradient
                colors={[Colors.dark.primary, Colors.dark.secondary]}
                style={styles.header}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View style={styles.headerContent}>
                    <Ionicons name="people" size={32} color="white" />
                    <Text style={styles.headerTitle}>About LeQ</Text>
                    <Text style={styles.headerSubtitle}>
                        Transforming the way you learn through audio
                    </Text>
                </View>
            </LinearGradient>

            {/* Content */}
            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <ScreenContainer>
                    {/* Who We Are */}
                    <View style={styles.card}>
                        <LinearGradient
                            colors={[Colors.dark.primary, Colors.dark.secondary]}
                            style={styles.logoCircle}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                        >
                            <Ionicons name="headset" size={48} color="white" />
                        </LinearGradient>
                        <Text style={styles.cardTitle}>Who We Are</Text>
                        <Text style={styles.cardText}>
                            LeQ is an audio-first learning platform dedicated to making high-quality
                            education accessible anytime, anywhere. We partner with expert instructors
                            to produce concise, engaging audio courses across a variety of subjects.
                        </Text>
                    </View>

                    {/* Mission */}
                    <View style={[styles.card, styles.missionCard]}>
                        <View style={styles.missionHeader}>
                            <View style={styles.missionIconBox}>
                                <Ionicons name="flag" size={28} color="white" />
                            </View>
                            <Text style={styles.missionTitle}>Our Mission</Text>
                        </View>
                        <Text style={styles.missionText}>
                            To transform everyday moments into meaningful learning by delivering premium
                            audio lessons designed for busy learners. We believe education should fit
                            into your life, not the other way around.
                        </Text>
                    </View>

                    {/* What We Offer */}
                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>What We Offer</Text>
                        <Text style={styles.sectionSubtitle}>
                            Everything you need for audio learning
                        </Text>

                        <View style={styles.featuresGrid}>
                            {/* Expert Instructors */}
                            <View style={styles.featureCard}>
                                <LinearGradient
                                    colors={['#667eea', '#764ba2']}
                                    style={styles.featureIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="mic" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.featureTitle}>Expert Instructors</Text>
                                <Text style={styles.featureText}>
                                    Short-form audio lessons led by industry experts and professionals
                                </Text>
                            </View>

                            {/* Learning Paths */}
                            <View style={styles.featureCard}>
                                <LinearGradient
                                    colors={['#f093fb', '#f5576c']}
                                    style={styles.featureIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="git-branch" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.featureTitle}>Learning Paths</Text>
                                <Text style={styles.featureText}>
                                    Curated learning paths and structured courses for progressive
                                    learning
                                </Text>
                            </View>

                            {/* Offline Access */}
                            <View style={styles.featureCard}>
                                <LinearGradient
                                    colors={['#4facfe', '#00f2fe']}
                                    style={styles.featureIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="cloud-download" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.featureTitle}>Offline Access</Text>
                                <Text style={styles.featureText}>
                                    Download lessons for offline listening and seamless progress sync
                                </Text>
                            </View>

                            {/* Affordable Plans */}
                            <View style={styles.featureCard}>
                                <LinearGradient
                                    colors={['#fa709a', '#fee140']}
                                    style={styles.featureIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="pricetag" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.featureTitle}>Affordable Plans</Text>
                                <Text style={styles.featureText}>
                                    Flexible pricing options and subscription plans for every budget
                                </Text>
                            </View>
                        </View>
                    </View>

                    {/* CTA */}
                    <LinearGradient
                        colors={[Colors.dark.primary, Colors.dark.secondary]}
                        style={styles.ctaCard}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                    >
                        <Text style={styles.ctaTitle}>Get Involved</Text>
                        <Text style={styles.ctaText}>
                            Whether you're an instructor, learner, or partner, we'd love to hear from
                            you.
                        </Text>
                        <TouchableOpacity
                            style={styles.ctaButton}
                            onPress={() => router.push('/contact')}
                        >
                            <Ionicons name="mail" size={20} color={Colors.dark.primary} />
                            <Text style={styles.ctaButtonText}>Contact Us</Text>
                        </TouchableOpacity>
                    </LinearGradient>
                </ScreenContainer>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingVertical: 32,
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerContent: {
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: '700',
        color: 'white',
        marginTop: 12,
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
        textAlign: 'center',
    },
    content: {
        flex: 1,
    },
    card: {
        backgroundColor: Colors.dark.card,
        margin: 16,
        borderRadius: 16,
        padding: 24,
        alignItems: 'center',
    },
    logoCircle: {
        width: 100,
        height: 100,
        borderRadius: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    cardTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 12,
    },
    cardText: {
        fontSize: 15,
        color: Colors.dark.textMuted,
        lineHeight: 24,
        textAlign: 'center',
    },
    missionCard: {
        borderWidth: 2,
        borderColor: Colors.dark.primary,
        alignItems: 'flex-start',
    },
    missionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 16,
        gap: 16,
    },
    missionIconBox: {
        width: 60,
        height: 60,
        backgroundColor: Colors.dark.primary,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    missionTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: Colors.dark.text,
    },
    missionText: {
        fontSize: 15,
        color: Colors.dark.textMuted,
        lineHeight: 24,
    },
    section: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: Colors.dark.text,
        textAlign: 'center',
        marginBottom: 8,
    },
    sectionSubtitle: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        textAlign: 'center',
        marginBottom: 24,
    },
    featuresGrid: {
        gap: 16,
    },
    featureCard: {
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 16,
    },
    featureIcon: {
        width: 50,
        height: 50,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 12,
    },
    featureTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    featureText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 20,
    },
    ctaCard: {
        margin: 16,
        borderRadius: 16,
        padding: 24,
        alignItems: 'center',
        marginBottom: 32,
    },
    ctaTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: 'white',
        marginBottom: 12,
    },
    ctaText: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
        textAlign: 'center',
        marginBottom: 20,
        lineHeight: 22,
    },
    ctaButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 24,
        gap: 8,
    },
    ctaButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.primary,
    },
});
