/**
 * Root Layout - Main app navigation structure
 * Handles auth state and routing
 */

import { useRef, useState, useCallback, useEffect } from 'react';
import { View, StyleSheet, Image, Animated, Dimensions, LogBox } from 'react-native';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { DarkTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import 'react-native-reanimated';

// Ignore specific deprecation warnings
LogBox.ignoreLogs([
  'Expo AV has been deprecated',
  'shadow* style props are deprecated',
  'textShadow* style props are deprecated',
  'Unable to activate keep awake',
  'Error: Unable to activate keep awake',
]);

import { useAuthStore } from '@/context/authStore';
import { Colors } from '@/constants/Colors';
import { LoadingState } from '@/components/ui/index';
import { setupPushNotifications } from '@/services/pushNotificationService';

export {
  ErrorBoundary,
} from 'expo-router';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

// Custom dark theme matching LEQ web app
const LEQDarkTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: Colors.dark.primary,
    background: Colors.dark.background,
    card: Colors.dark.card,
    text: Colors.dark.text,
    border: Colors.dark.border,
    notification: Colors.dark.accent,
  },
};

export default function RootLayout() {
  const [loaded, error] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
    ...FontAwesome.font,
  });

  const { initialize, isInitialized, isAuthenticated, hasSeenOnboarding } = useAuthStore();
  const router = useRouter();
  const segments = useSegments();

  const [appIsReady, setAppIsReady] = useState(false);
  const [splashAnimationFinished, setSplashAnimationFinished] = useState(false);

  // Animation values
  const splashOpacity = useRef(new Animated.Value(1)).current;
  const logoScale = useRef(new Animated.Value(0.3)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;

  // Initialize auth state
  useEffect(() => {
    async function prepare() {
      try {
        await initialize();
      } catch (e) {
        console.warn(e);
      } finally {
        setAppIsReady(true);
      }
    }
    prepare();
  }, []);

  // Setup push notifications when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      let subscription: any;

      const initNotifications = async () => {
        const sub = await setupPushNotifications(router);
        subscription = sub;
      };

      initNotifications();

      return () => {
        if (subscription && typeof subscription.remove === 'function') {
          subscription.remove();
        }
      };
    }
  }, [isAuthenticated]);

  // Handle font loading errors
  useEffect(() => {
    if (error) throw error;
  }, [error]);

  // Handle Splash Screen Logic
  useEffect(() => {
    if (loaded && appIsReady) {
      // Hide the native splash screen immediately to show our custom animated one
      SplashScreen.hideAsync();

      // Start animations
      Animated.sequence([
        // 1. Entrance: Fade in + Bounce
        Animated.parallel([
          Animated.timing(logoOpacity, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.spring(logoScale, {
            toValue: 1,
            friction: 4,  // Bouncier
            tension: 50,
            useNativeDriver: true,
          }),
        ]),

        // 2. Breathing / Pulse
        Animated.sequence([
          Animated.timing(logoScale, { toValue: 1.15, duration: 600, useNativeDriver: true }),
          Animated.timing(logoScale, { toValue: 1.0, duration: 600, useNativeDriver: true }),
        ]),

        // 3. Exit: Fade out
        Animated.timing(splashOpacity, {
          toValue: 0,
          duration: 400,
          useNativeDriver: true,
        })
      ]).start(() => {
        setSplashAnimationFinished(true);
      });
    }
  }, [loaded, appIsReady]);

  // Handle auth routing
  useEffect(() => {
    if (!isInitialized || !splashAnimationFinished) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!isAuthenticated && !inAuthGroup) {
      // Not authenticated, redirect to auth flow
      if (!hasSeenOnboarding) {
        router.replace('/(auth)/onboarding');
      } else {
        router.replace('/(auth)/login');
      }
    } else if (isAuthenticated && inAuthGroup) {
      // Authenticated, redirect to main app
      router.replace('/(tabs)');
    }
  }, [isAuthenticated, isInitialized, hasSeenOnboarding, segments, splashAnimationFinished]);

  if (!loaded || !isInitialized) {
    return (
      <View style={styles.loadingContainer}>
        <LoadingState message="Loading..." />
      </View>
    );
  }

  return (
    <ThemeProvider value={LEQDarkTheme}>
      {!splashAnimationFinished && (
        <Animated.View style={[styles.splashContainer, { opacity: splashOpacity }]}>
          <Animated.Image
            source={require('../assets/images/Logo.png')}
            style={[
              styles.splashLogo,
              {
                opacity: logoOpacity,
                transform: [{ scale: logoScale }]
              }
            ]}
          />
        </Animated.View>
      )}
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen
          name="course/[id]"
          options={{
            headerShown: true,
            headerStyle: { backgroundColor: Colors.dark.background },
            headerTintColor: Colors.dark.text,
            headerTitle: '',
            headerBackTitle: 'Back',
          }}
        />
        <Stack.Screen
          name="notifications"
          options={{
            headerShown: true,
            headerStyle: { backgroundColor: Colors.dark.background },
            headerTintColor: Colors.dark.text,
            headerTitle: 'Notifications',
          }}
        />
      </Stack>
    </ThemeProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  splashContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#0F0F0F',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  splashLogo: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
  }
});
