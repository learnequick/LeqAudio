/**
 * Tabs Layout - Bottom tab navigation
 * Fully responsive across all device sizes
 */

import { Platform } from 'react-native';
import { Tabs } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import {
  spacing,
  typography,
  iconSizes,
  responsiveDimensions,
  getSafeBottomPadding,
} from '@/utils/responsive';

import { HomeIcon, MySpaceIcon } from '@/components/Icons';

export default function TabLayout() {
  const insets = useSafeAreaInsets();

  // Dynamic responsive tab bar height
  // 60 is the base height for content (icons + spacing)
  const bottomPadding = Math.max(insets.bottom, spacing.md);
  const tabBarHeight = 60 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors.dark.primary,
        tabBarInactiveTintColor: Colors.dark.textMuted,
        tabBarStyle: {
          backgroundColor: Colors.dark.backgroundSecondary,
          borderTopColor: Colors.dark.border,
          borderTopWidth: 1,
          paddingTop: spacing.sm,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          paddingHorizontal: responsiveDimensions.isSmallDevice ? spacing.xs : 0,
        },
        tabBarLabelStyle: {
          fontSize: typography.tiny,
          fontWeight: '600',
          marginTop: 4,
        },
        tabBarShowLabel: false,
        tabBarIconStyle: {
          marginTop: responsiveDimensions.isSmallDevice ? 2 : 4,
        },
        headerShown: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => (
            <HomeIcon
              width={iconSizes.large}
              height={iconSizes.large}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="courses"
        options={{
          title: 'Courses',
          tabBarIcon: ({ color, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'school' : 'school-outline'}
              size={iconSizes.large}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="my-learning"
        options={{
          title: 'My Learning',
          tabBarIcon: ({ color, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'play-circle' : 'play-circle-outline'}
              size={iconSizes.large}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="my-space"
        options={{
          title: 'My Space',
          tabBarIcon: ({ color }) => (
            <MySpaceIcon
              width={iconSizes.large}
              height={iconSizes.large}
              color={color}
            />
          ),
        }}
      />
    </Tabs>
  );
}
