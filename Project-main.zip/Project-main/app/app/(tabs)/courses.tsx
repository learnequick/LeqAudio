/**
 * Courses Screen - Browse all courses with filters
 * Fully responsive across all device sizes
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    TextInput,
    StyleSheet,
    RefreshControl
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors } from '@/constants/Colors';
import { Course, Category } from '@/types';
import { courseService } from '@/services';
import { CourseCard, LoadingState, ErrorState, EmptyState } from '@/components/ui/index';
import {
    spacing,
    typography,
    iconSizes,
    borderRadius,
    responsiveDimensions,
    useResponsiveLayout,
} from '@/utils/responsive';

export default function CoursesScreen() {
    const router = useRouter();
    const params = useLocalSearchParams();
    const insets = useSafeAreaInsets();
    const { numColumns, isTablet } = useResponsiveLayout();

    const [isLoading, setIsLoading] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [courses, setCourses] = useState<Course[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

    const loadData = async () => {
        try {
            setError(null);

            const [coursesData, categoriesData] = await Promise.all([
                courseService.getCourses({
                    category: selectedCategory || undefined,
                    search: searchQuery || undefined,
                }),
                courseService.getCategories(),
            ]);

            setCourses(coursesData);
            setCategories(categoriesData);

        } catch (err) {
            setError('Failed to load courses. Please try again.');
        } finally {
            setIsLoading(false);
            setIsRefreshing(false);
        }
    };

    useEffect(() => {
        loadData();
    }, [selectedCategory]);

    useEffect(() => {
        // Handle search params from navigation
        if (params.category) {
            setSelectedCategory(Number(params.category));
        }
    }, [params]);

    const onRefresh = useCallback(() => {
        setIsRefreshing(true);
        loadData();
    }, [selectedCategory, searchQuery]);

    const handleSearch = () => {
        setIsLoading(true);
        loadData();
    };

    const handleCoursePress = (course: Course) => {
        router.push(`/course/${course.id}`);
    };

    const handleCategorySelect = (categoryId: number | null) => {
        setSelectedCategory(categoryId);
        setIsLoading(true);
    };

    const renderCourse = ({ item }: { item: Course }) => {
        // Calculate proper width based on number of columns
        // For single column (phones portrait), use full width minus padding
        // For multi-column (tablets/landscape), distribute evenly with gaps
        const itemWidth = numColumns === 1
            ? '100%'
            : `${(100 / numColumns) - (isTablet ? 1.5 : 2)}%`;

        return (
            <View style={[styles.courseWrapper, { width: itemWidth as any }]}>
                <CourseCard course={item} onPress={handleCoursePress} style={{ width: '100%' }} />
            </View>
        );
    };

    if (isLoading && !isRefreshing) {
        return <LoadingState message="Loading courses..." />;
    }

    if (error) {
        return <ErrorState message={error} onRetry={loadData} />;
    }

    return (
        <View style={[styles.container, { paddingTop: insets.top }]}>
            {/* Header */}
            <View style={styles.header}>
                <Text style={styles.title}>Explore Courses</Text>

                {/* Search Bar */}
                <View style={styles.searchContainer}>
                    <Ionicons name="search" size={20} color={Colors.dark.textMuted} />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search courses..."
                        placeholderTextColor={Colors.dark.textMuted}
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                        onSubmitEditing={handleSearch}
                        returnKeyType="search"
                    />
                    {searchQuery.length > 0 && (
                        <TouchableOpacity onPress={() => {
                            setSearchQuery('');
                            setIsLoading(true);
                            loadData();
                        }}>
                            <Ionicons name="close-circle" size={20} color={Colors.dark.textMuted} />
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            {/* Category Pills */}
            <FlatList
                horizontal
                data={[{ id: null, name: 'All' }, ...categories]}
                keyExtractor={(item) => String(item.id)}
                showsHorizontalScrollIndicator={false}
                style={{ flexGrow: 0 }}
                contentContainerStyle={styles.categoryList}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={[
                            styles.categoryPill,
                            (item.id === null ? selectedCategory === null : selectedCategory === item.id) && styles.categoryPillActive,
                        ]}
                        onPress={() => handleCategorySelect(item.id)}
                    >
                        <Text style={[
                            styles.categoryText,
                            (item.id === null ? selectedCategory === null : selectedCategory === item.id) && styles.categoryTextActive,
                        ]}>
                            {item.name}
                        </Text>
                    </TouchableOpacity>
                )}
            />

            {/* Course List */}
            {courses.length === 0 ? (
                <EmptyState
                    icon="book-outline"
                    title="No courses found"
                    message={searchQuery ? `No courses match "${searchQuery}"` : "No courses available in this category"}
                    actionLabel="Clear filters"
                    onAction={() => {
                        setSearchQuery('');
                        setSelectedCategory(null);
                    }}
                />
            ) : (
                <FlatList
                    key={`courses-grid-${numColumns}`}
                    data={courses}
                    keyExtractor={(item) => String(item.id)}
                    numColumns={numColumns}
                    columnWrapperStyle={numColumns > 1 ? styles.courseRow : undefined}
                    contentContainerStyle={styles.courseList}
                    renderItem={renderCourse}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl
                            refreshing={isRefreshing}
                            onRefresh={onRefresh}
                            tintColor={Colors.dark.primary}
                        />
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.md,
    },
    title: {
        fontSize: typography.h3,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: spacing.lg,
        marginTop: spacing.sm,
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: borderRadius.md,
        paddingHorizontal: spacing.md,
        minHeight: responsiveDimensions.isSmallDevice ? 44 : 48,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    searchInput: {
        flex: 1,
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.sm,
        fontSize: typography.body,
        color: Colors.dark.text,
    },
    categoryList: {
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.md,
        gap: spacing.sm,
        marginBottom: spacing.sm,
    },
    categoryPill: {
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.sm,
        height: responsiveDimensions.isSmallDevice ? 36 : 38,
        borderRadius: responsiveDimensions.isSmallDevice ? 18 : 19,
        backgroundColor: Colors.dark.card,
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'flex-start',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.15,
        shadowRadius: 2,
        elevation: 2,
    },
    categoryPillActive: {
        backgroundColor: Colors.dark.primary,
    },
    categoryText: {
        fontSize: typography.bodySmall,
        fontWeight: '500',
        color: Colors.dark.textSecondary,
    },
    categoryTextActive: {
        color: '#fff',
    },
    courseList: {
        padding: spacing.lg,
        paddingBottom: 100,
    },
    courseRow: {
        justifyContent: 'space-between',
        // Gap removed to prevent overflow with fixed widths
        paddingBottom: spacing.sm,
    },
    courseWrapper: {
        marginBottom: spacing.lg,
    },
});
