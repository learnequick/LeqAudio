/**
 * Home Screen - Main dashboard with banners and courses
 * Fully responsive across all device sizes
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Image
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors } from '@/constants/Colors';
import { Banner, Course, Category } from '@/types';
import { bannerService, courseService, notificationService } from '@/services';
import { BannerCarousel, CategorySection, LoadingState, ErrorState, ScreenContainer } from '@/components/ui/index';
import {
  spacing,
  typography,
  iconSizes,
  borderRadius,
  responsiveDimensions,
  getMinTouchTarget,
} from '@/utils/responsive';

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);

  const [banners, setBanners] = useState<Banner[]>([]);
  const [featuredCourses, setFeaturedCourses] = useState<Course[]>([]);
  const [trendingCourses, setTrendingCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [coursesByCategory, setCoursesByCategory] = useState<Record<number, Course[]>>({});

  const loadData = async () => {
    try {
      setError(null);

      const [bannersData, featuredData, trendingData, categoriesData] = await Promise.all([
        bannerService.getHomeBanners().catch(() => []),
        courseService.getFeaturedCourses().catch(() => []),
        courseService.getTrendingCourses().catch(() => []),
        courseService.getCategories().catch(() => []),
      ]);

      setBanners(bannersData);
      setFeaturedCourses(featuredData);
      setTrendingCourses(trendingData);
      setCategories(categoriesData);

      // Check unread count initially
      checkUnreadNotifications();

      // Load courses for each category
      const categoryCoursesMap: Record<number, Course[]> = {};
      for (const category of categoriesData.slice(0, 5)) {
        try {
          const courses = await courseService.getCourses({ category: category.id });
          if (courses.length > 0) {
            categoryCoursesMap[category.id] = courses.slice(0, 10);
          }
        } catch (err) {
          console.log(`Failed to load courses for category ${category.id}`);
        }
      }
      setCoursesByCategory(categoryCoursesMap);

    } catch (err) {
      setError('Failed to load content. Please try again.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const checkUnreadNotifications = async () => {
    try {
      const count = await notificationService.getUnreadCount();
      setUnreadCount(count);
    } catch (err) {
      console.log('Failed to check unread notifications');
    }
  };

  useFocusEffect(
    useCallback(() => {
      checkUnreadNotifications();
    }, [])
  );

  const onRefresh = useCallback(() => {
    setIsRefreshing(true);
    // Refresh both data and notifications
    Promise.all([loadData(), checkUnreadNotifications()]).finally(() => {
      setIsRefreshing(false);
    });
  }, []);

  const handleCoursePress = (course: Course) => {
    router.push(`/course/${course.id}`);
  };

  const handleBannerPress = (banner: Banner) => {
    if (banner.action_url) {
      // Handle banner action (could be course ID, URL, etc.)
      console.log('Banner pressed:', banner.action_url);
    }
  };

  const handleNotificationsPress = () => {
    router.push('/notifications');
  };

  if (isLoading) {
    return <LoadingState message="Loading your dashboard..." />;
  }

  if (error) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Top Navigation Bar */}
      <View style={styles.navbar}>
        <View style={styles.logoContainer}>
          <Image
            source={require('../../assets/images/Logo.png')}
            style={styles.logoImage}
          />
          <Text style={styles.logoTitle}>LeQ Audio</Text>
        </View>
        <TouchableOpacity
          style={styles.notificationButton}
          onPress={handleNotificationsPress}
        >
          <MaterialCommunityIcons
            name={unreadCount > 0 ? "bell-badge-outline" : "bell-outline"}
            size={24}
            color={Colors.dark.text}
          />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onRefresh}
            tintColor={Colors.dark.primary}
            colors={[Colors.dark.primary]}
          />
        }
      >
        <ScreenContainer>
          {/* Banner Carousel */}
          {banners.length > 0 && (
            <View style={styles.section}>
              <BannerCarousel
                banners={banners}
                onBannerPress={handleBannerPress}
              />
            </View>
          )}

          {/* Featured Courses */}
          {featuredCourses.length > 0 && (
            <CategorySection
              title="Featured Courses"
              subtitle="Hand-picked premium courses"
              icon="star"
              iconColor="#F59E0B"
              courses={featuredCourses}
              onCoursePress={handleCoursePress}
              onViewAll={() => router.push('/courses?featured=true')}
              variant="thumbnail"
              size="small"
            />
          )}

          {/* Trending Courses */}
          {trendingCourses.length > 0 && (
            <CategorySection
              title="Trending Now"
              subtitle="Most popular this week"
              icon="flame"
              iconColor="#EF4444"
              courses={trendingCourses}
              onCoursePress={handleCoursePress}
              onViewAll={() => router.push('/courses?sort=trending')}
              variant="thumbnail"
              size="small"
            />
          )}

          {/* Courses by Category */}
          {categories.map((category) => {
            const courses = coursesByCategory[category.id];
            if (!courses || courses.length === 0) return null;

            return (
              <CategorySection
                key={category.id}
                title={category.name}
                courses={courses}
                onCoursePress={handleCoursePress}
                onViewAll={() => router.push(`/courses?category=${category.id}`)}
                variant="thumbnail"
                size="small"
              />
            );
          })}

          {/* Footer spacing */}
          <View style={styles.footer} />
        </ScreenContainer>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  logoImage: {
    width: responsiveDimensions.isSmallDevice ? 32 : 36,
    height: responsiveDimensions.isSmallDevice ? 32 : 36,
    resizeMode: 'contain',
    marginRight: 4
  },
  logoTitle: {
    fontSize: typography.h5,
    fontWeight: '700',
    color: Colors.dark.text,
  },
  notificationButton: {
    width: getMinTouchTarget(),
    height: getMinTouchTarget(),
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    marginTop: spacing.lg,
  },
  footer: {
    height: 100,
  },
});
