/**
 * My Space Screen - User profile and settings
 */

import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Image,
    Alert,
    Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

import { Colors } from '@/constants/Colors';
import { useAuthStore } from '@/context/authStore';
import { LoadingState, ScreenContainer } from '@/components/ui/index';

export default function MySpaceScreen() {
    const router = useRouter();
    const insets = useSafeAreaInsets();
    const { user, logout, isLoading, refreshUser } = useAuthStore();

    useEffect(() => {
        refreshUser();
    }, []);

    const handleLogout = () => {
        if (Platform.OS === 'web') {
            if (window.confirm('Are you sure you want to logout?')) {
                logout().then(() => {
                    router.replace('/(auth)/login');
                });
            }
        } else {
            Alert.alert(
                'Logout',
                'Are you sure you want to logout?',
                [
                    { text: 'Cancel', style: 'cancel' },
                    {
                        text: 'Logout',
                        style: 'destructive',
                        onPress: async () => {
                            await logout();
                            router.replace('/(auth)/login');
                        }
                    },
                ]
            );
        }
    };

    if (!user) {
        return <LoadingState message="Loading profile..." />;
    }

    const menuItems = [
        {
            icon: 'person-outline' as const,
            label: 'Edit Profile',
            onPress: () => router.push('/edit-profile')
        },
        {
            icon: 'notifications-outline' as const,
            label: 'Notifications',
            onPress: () => router.push('/notifications')
        },
        {
            icon: 'information-circle-outline' as const,
            label: 'About LeQ',
            onPress: () => router.push('/about')
        },
        {
            icon: 'mail-outline' as const,
            label: 'Contact Us',
            onPress: () => router.push('/contact')
        },
        {
            icon: 'document-text-outline' as const,
            label: 'Terms & Conditions',
            onPress: () => router.push('/terms')
        },
        {
            icon: 'receipt-outline' as const,
            label: 'Refund Policy',
            onPress: () => router.push('/refund-policy')
        },
    ];

    return (
        <View style={[styles.container, { paddingTop: insets.top }]}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <ScreenContainer>
                    {/* Profile Header */}
                    <View style={styles.profileHeader}>
                        <LinearGradient
                            colors={[Colors.dark.primary, Colors.dark.secondary]}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                            style={styles.profileBackground}
                        />

                        <View style={styles.profileContent}>
                            {/* Avatar */}
                            <View style={styles.avatarContainer}>
                                {user.profile_picture_url ? (
                                    <Image
                                        source={{ uri: user.profile_picture_url }}
                                        style={styles.avatar}
                                    />
                                ) : (
                                    <View style={styles.avatarPlaceholder}>
                                        <Text style={styles.avatarText}>
                                            {user.first_name?.[0]?.toUpperCase() || user.email[0].toUpperCase()}
                                        </Text>
                                    </View>
                                )}
                            </View>

                            {/* User Info */}
                            <Text style={styles.userName}>{user.full_name || `${user.first_name} ${user.last_name}`}</Text>
                            <Text style={styles.userEmail}>{user.email}</Text>

                            {/* Stats */}
                            <View style={styles.statsContainer}>
                                <View style={styles.statItem}>
                                    <Text style={styles.statValue}>{user.total_enrollments || 0}</Text>
                                    <Text style={styles.statLabel}>Enrolled</Text>
                                </View>
                                <View style={styles.statDivider} />
                                <View style={styles.statItem}>
                                    <Text style={styles.statValue}>{user.total_completed || 0}</Text>
                                    <Text style={styles.statLabel}>Completed</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                    {/* Menu Items */}
                    <View style={styles.menuContainer}>
                        {menuItems.map((item, index) => (
                            <TouchableOpacity
                                key={index}
                                style={styles.menuItem}
                                onPress={item.onPress}
                            >
                                <View style={styles.menuItemLeft}>
                                    <View style={styles.menuIconContainer}>
                                        <Ionicons name={item.icon} size={22} color={Colors.dark.primary} />
                                    </View>
                                    <Text style={styles.menuItemText}>{item.label}</Text>
                                </View>
                                <Ionicons name="chevron-forward" size={18} color={Colors.dark.textMuted} />
                            </TouchableOpacity>
                        ))}
                    </View>

                    {/* Logout Button */}
                    <TouchableOpacity
                        style={styles.logoutButton}
                        onPress={handleLogout}
                        disabled={isLoading}
                    >
                        <Ionicons name="log-out-outline" size={20} color={Colors.dark.danger} />
                        <Text style={styles.logoutText}>
                            {isLoading ? 'Logging out...' : 'Logout'}
                        </Text>
                    </TouchableOpacity>

                    {/* App Version */}
                    <Text style={styles.version}>Version 1.0.0</Text>

                    {/* Footer spacing */}
                    <View style={styles.footer} />
                </ScreenContainer>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    profileHeader: {
        position: 'relative',
        paddingTop: 40,
        paddingBottom: 24,
    },
    profileBackground: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 120,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    profileContent: {
        alignItems: 'center',
        paddingHorizontal: 24,
    },
    avatarContainer: {
        marginBottom: 16,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        borderWidth: 4,
        borderColor: Colors.dark.background,
    },
    avatarPlaceholder: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: Colors.dark.card,
        borderWidth: 4,
        borderColor: Colors.dark.background,
        justifyContent: 'center',
        alignItems: 'center',
    },
    avatarText: {
        fontSize: 36,
        fontWeight: '700',
        color: Colors.dark.primary,
    },
    userName: {
        fontSize: 22,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    userEmail: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginBottom: 20,
    },
    statsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 16,
        paddingVertical: 16,
        paddingHorizontal: 32,
        // Shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15,
        shadowRadius: 4,
        elevation: 3,
    },
    statItem: {
        alignItems: 'center',
        paddingHorizontal: 24,
    },
    statValue: {
        fontSize: 24,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    statLabel: {
        fontSize: 12,
        color: Colors.dark.textMuted,
    },
    statDivider: {
        width: 1,
        height: 40,
        backgroundColor: Colors.dark.border,
        opacity: 0.5,
    },
    menuContainer: {
        paddingHorizontal: 16,
        marginTop: 8,
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: Colors.dark.card,
        borderRadius: 14,
        padding: 16,
        marginBottom: 10,
        // Shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
    },
    menuItemLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 14,
    },
    menuIconContainer: {
        width: 40,
        height: 40,
        borderRadius: 12,
        backgroundColor: `${Colors.dark.primary}15`,
        justifyContent: 'center',
        alignItems: 'center',
    },
    menuItemText: {
        fontSize: 15,
        fontWeight: '500',
        color: Colors.dark.text,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        marginHorizontal: 16,
        marginTop: 16,
        paddingVertical: 16,
        borderRadius: 14,
        backgroundColor: `${Colors.dark.danger}15`,
        borderWidth: 1,
        borderColor: `${Colors.dark.danger}30`,
    },
    logoutText: {
        fontSize: 15,
        fontWeight: '600',
        color: Colors.dark.danger,
    },
    version: {
        textAlign: 'center',
        fontSize: 12,
        color: Colors.dark.textMuted,
        marginTop: 24,
    },
    footer: {
        height: 100,
    },
});
