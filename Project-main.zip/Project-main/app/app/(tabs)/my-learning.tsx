/**
 * My Learning Screen - Enrolled courses with progress
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    RefreshControl
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors } from '@/constants/Colors';
import { Enrollment } from '@/types';
import { enrollmentService } from '@/services';
import { EnrollmentCard, LoadingState, ErrorState, EmptyState } from '@/components/ui/index';
import { spacing } from '@/utils/responsive';


type TabType = 'all' | 'active' | 'completed';

export default function MyLearningScreen() {
    const router = useRouter();
    const insets = useSafeAreaInsets();

    const [isLoading, setIsLoading] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [activeTab, setActiveTab] = useState<TabType>('all');
    const [activeEnrollments, setActiveEnrollments] = useState<Enrollment[]>([]);
    const [completedEnrollments, setCompletedEnrollments] = useState<Enrollment[]>([]);

    const loadData = async () => {
        try {
            setError(null);

            const allEnrollments = await enrollmentService.getEnrollments();

            // Filter enrollments on the client side since backend endpoints might be varying
            const active = allEnrollments.filter(e => e.progress_percentage < 100);
            const completed = allEnrollments.filter(e => e.progress_percentage === 100);

            setActiveEnrollments(active);
            setCompletedEnrollments(completed);

        } catch (err) {
            setError('Failed to load your courses. Please try again.');
        } finally {
            setIsLoading(false);
            setIsRefreshing(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const onRefresh = useCallback(() => {
        setIsRefreshing(true);
        loadData();
    }, []);

    const handleEnrollmentPress = (enrollment: Enrollment) => {
        // Extract ID from various possible locations
        const courseId = enrollment.course_id ||
            (typeof enrollment.course === 'object' ? enrollment.course?.id : enrollment.course);

        if (courseId) {
            router.push(`/course/${courseId}`);
        } else {
            console.error("Invalid enrollment or course ID", enrollment);
        }
    };

    const currentEnrollments = activeTab === 'all'
        ? [...activeEnrollments, ...completedEnrollments]
        : activeTab === 'active'
            ? activeEnrollments
            : completedEnrollments;

    if (isLoading && !isRefreshing) {
        return <LoadingState message="Loading your courses..." />;
    }

    if (error) {
        return <ErrorState message={error} onRetry={loadData} />;
    }

    return (
        <View style={[styles.container, { paddingTop: insets.top }]}>
            {/* Header */}
            <View style={styles.header}>
                <Text style={styles.title}>My Learning</Text>

                {/* Tabs */}
                <View style={styles.tabs}>
                    <TouchableOpacity
                        style={[styles.tab, activeTab === 'all' && styles.tabActive]}
                        onPress={() => setActiveTab('all')}
                    >
                        <Text style={[styles.tabText, activeTab === 'all' && styles.tabTextActive]}>
                            All ({activeEnrollments.length + completedEnrollments.length})
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.tab, activeTab === 'active' && styles.tabActive]}
                        onPress={() => setActiveTab('active')}
                    >
                        <Text style={[styles.tabText, activeTab === 'active' && styles.tabTextActive]}>
                            In Progress ({activeEnrollments.length})
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.tab, activeTab === 'completed' && styles.tabActive]}
                        onPress={() => setActiveTab('completed')}
                    >
                        <Text style={[styles.tabText, activeTab === 'completed' && styles.tabTextActive]}>
                            Completed ({completedEnrollments.length})
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>

            {/* Enrollment List */}
            {currentEnrollments.length === 0 ? (
                <EmptyState
                    icon={activeTab === 'active' ? 'book-outline' : 'checkmark-circle-outline'}
                    title={activeTab === 'active' ? 'No courses in progress' : 'No completed courses'}
                    message={activeTab === 'active'
                        ? 'Start learning by enrolling in a course'
                        : 'Complete a course to see it here'}
                    actionLabel="Browse Courses"
                    onAction={() => router.push('/(tabs)/courses')}
                />
            ) : (
                <FlatList
                    data={currentEnrollments}
                    keyExtractor={(item) => String(item.id)}
                    renderItem={({ item }) => (
                        <EnrollmentCard enrollment={item} onPress={handleEnrollmentPress} />
                    )}
                    contentContainerStyle={styles.list}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl
                            refreshing={isRefreshing}
                            onRefresh={onRefresh}
                            tintColor={Colors.dark.primary}
                        />
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingHorizontal: 16,
        paddingBottom: 16,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    title: {
        fontSize: 24,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 16,
        marginTop: 8,
    },
    tabs: {
        flexDirection: 'row',
        gap: 8,
    },
    tab: {
        paddingHorizontal: 16,
        paddingVertical: 10,
        height: 38, // Enforce height
        borderRadius: 19,
        backgroundColor: Colors.dark.card,
        justifyContent: 'center',
        alignItems: 'center',
        // Shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 3,
    },
    tabActive: {
        backgroundColor: Colors.dark.primary,
        borderColor: Colors.dark.primary,
    },
    tabText: {
        fontSize: 13,
        fontWeight: '500',
        color: Colors.dark.textSecondary,
    },
    tabTextActive: {
        color: '#fff',
    },
    list: {
        padding: 16,
        paddingBottom: 100,
    },
});
