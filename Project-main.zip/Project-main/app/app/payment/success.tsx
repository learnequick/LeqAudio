/**
 * Payment Success Screen
 */

import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { Colors } from '@/constants/Colors';
import { ScreenContainer } from '@/components/ui';

export default function PaymentSuccessScreen() {
    const { courseId, courseTitle } = useLocalSearchParams();
    const router = useRouter();

    const handleStartLearning = () => {
        if (courseId) {
            router.replace(`/course/${courseId}`);
        } else {
            router.replace('/(tabs)/courses');
        }
    };

    const handleGoHome = () => {
        router.replace('/(tabs)');
    };

    return (
        <>
            <Stack.Screen
                options={{
                    headerShown: false,
                }}
            />

            <View style={styles.container}>
                <LinearGradient
                    colors={[Colors.dark.background, Colors.dark.backgroundSecondary]}
                    style={styles.gradient}
                >
                    <ScreenContainer style={{ flex: 1, justifyContent: 'space-between' }}>
                        {/* Success Animation */}
                        <View style={styles.animationContainer}>
                            <View style={styles.successCircle}>
                                <Ionicons name="checkmark" size={80} color="#fff" />
                            </View>
                        </View>

                        {/* Success Message */}
                        <View style={styles.content}>
                            <Text style={styles.title}>Payment Successful!</Text>
                            <Text style={styles.subtitle}>
                                Your enrollment has been confirmed
                            </Text>

                            {courseTitle && (
                                <View style={styles.courseInfo}>
                                    <Ionicons name="book" size={20} color={Colors.dark.primary} />
                                    <Text style={styles.courseTitle} numberOfLines={2}>
                                        {courseTitle}
                                    </Text>
                                </View>
                            )}

                            <View style={styles.infoBox}>
                                <Ionicons name="information-circle" size={20} color={Colors.dark.primary} />
                                <Text style={styles.infoText}>
                                    You can now access all course materials and start learning right away!
                                </Text>
                            </View>
                        </View>

                        {/* Action Buttons */}
                        <View style={styles.buttonContainer}>
                            <TouchableOpacity
                                style={styles.primaryButton}
                                onPress={handleStartLearning}
                            >
                                <LinearGradient
                                    colors={[Colors.dark.primary, Colors.dark.secondary]}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 0 }}
                                    style={styles.buttonGradient}
                                >
                                    <Ionicons name="play-circle" size={20} color="#fff" />
                                    <Text style={styles.primaryButtonText}>Start Learning</Text>
                                </LinearGradient>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.secondaryButton}
                                onPress={handleGoHome}
                            >
                                <Text style={styles.secondaryButtonText}>Go to Home</Text>
                            </TouchableOpacity>
                        </View>
                    </ScreenContainer>
                </LinearGradient>
            </View>
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    gradient: {
        flex: 1,
        justifyContent: 'space-between',
        padding: 20,
        paddingTop: 60,
        paddingBottom: 40,
    },
    animationContainer: {
        alignItems: 'center',
        marginTop: 40,
    },
    successCircle: {
        width: 160,
        height: 160,
        borderRadius: 80,
        backgroundColor: Colors.dark.success,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: Colors.dark.success,
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 16,
        elevation: 8,
    },
    content: {
        alignItems: 'center',
        gap: 16,
    },
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.text,
        textAlign: 'center',
    },
    subtitle: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
    },
    courseInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        backgroundColor: Colors.dark.card,
        paddingHorizontal: 20,
        paddingVertical: 16,
        borderRadius: 12,
        marginTop: 8,
        width: '100%',
    },
    courseTitle: {
        flex: 1,
        fontSize: 15,
        fontWeight: '600',
        color: Colors.dark.text,
    },
    infoBox: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 12,
        backgroundColor: `${Colors.dark.primary}20`,
        padding: 16,
        borderRadius: 12,
        borderLeftWidth: 3,
        borderLeftColor: Colors.dark.primary,
        marginTop: 8,
    },
    infoText: {
        flex: 1,
        fontSize: 14,
        color: Colors.dark.textSecondary,
        lineHeight: 20,
    },
    buttonContainer: {
        gap: 12,
    },
    primaryButton: {
        borderRadius: 24,
        overflow: 'hidden',
    },
    buttonGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 16,
        gap: 8,
    },
    primaryButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#fff',
    },
    secondaryButton: {
        backgroundColor: Colors.dark.card,
        borderRadius: 24,
        paddingVertical: 16,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    secondaryButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.text,
    },
});
