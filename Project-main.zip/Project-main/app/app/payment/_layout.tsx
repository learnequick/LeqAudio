import { Stack } from 'expo-router';

export default function PaymentLayout() {
    return (
        <Stack>
            <Stack.Screen
                name="checkout"
                options={{
                    headerShown: true,
                    presentation: 'card',
                }}
            />
            <Stack.Screen
                name="razorpay"
                options={{
                    headerShown: true,
                    headerTitle: 'Payment',
                    presentation: 'modal',
                    headerBackTitle: 'Cancel',
                }}
            />
            <Stack.Screen
                name="success"
                options={{
                    headerShown: true,
                    presentation: 'card',
                }}
            />
            <Stack.Screen
                name="failure"
                options={{
                    headerShown: true,
                    presentation: 'card',
                }}
            />
        </Stack>
    );
}
