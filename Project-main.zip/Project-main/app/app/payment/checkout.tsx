/**
 * Checkout Screen - Payment processing with coupon support
 */

import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Image,
    TextInput,
    Alert,
    ActivityIndicator,
    Platform,
    SafeAreaView,
    KeyboardAvoidingView,
    NativeModules
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors } from '@/constants/Colors';
import { CourseDetail } from '@/types';
import { courseService, paymentService } from '@/services';
import { LoadingState, ErrorState, ScreenContainer } from '@/components/ui/index';

export default function CheckoutScreen() {
    const { courseId } = useLocalSearchParams();
    const router = useRouter();
    const insets = useSafeAreaInsets();

    const [isLoading, setIsLoading] = useState(true);
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [course, setCourse] = useState<CourseDetail | null>(null);

    // Coupon state
    const [couponCode, setCouponCode] = useState('');
    const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
    const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
    const [couponMessage, setCouponMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

    // Pricing state
    const [originalAmount, setOriginalAmount] = useState(0);
    const [discountAmount, setDiscountAmount] = useState(0);
    const [finalAmount, setFinalAmount] = useState(0);

    useEffect(() => {
        loadCourse();
    }, [courseId]);

    const loadCourse = async () => {
        const id = Array.isArray(courseId) ? courseId[0] : courseId;

        if (!id) {
            setError('Invalid Course ID');
            setIsLoading(false);
            return;
        }

        try {
            setError(null);
            const data = await courseService.getCourseDetail(id);
            setCourse(data);

            // Set initial pricing
            const price = data.discount_price || data.price;
            setOriginalAmount(price);
            setFinalAmount(price);
        } catch (err: any) {
            console.error('Error loading course:', err);
            setError(err.response?.data?.detail || 'Failed to load course details.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleApplyCoupon = async () => {
        if (!couponCode.trim()) {
            setCouponMessage({ type: 'error', text: 'Please enter a coupon code' });
            return;
        }

        if (!course) return;

        setIsValidatingCoupon(true);
        setCouponMessage(null);

        try {
            const response = await paymentService.validateCoupon(couponCode.trim(), course.id);

            if (response.valid) {
                setAppliedCoupon(couponCode.trim().toUpperCase());
                setDiscountAmount(response.discount_amount || 0);
                setFinalAmount(response.final_amount || originalAmount);
                setCouponMessage({ type: 'success', text: response.message });
            } else {
                setCouponMessage({ type: 'error', text: response.message });
            }
        } catch (err: any) {
            console.error('Error validating coupon:', err);
            setCouponMessage({ type: 'error', text: 'Failed to validate coupon. Please try again.' });
        } finally {
            setIsValidatingCoupon(false);
        }
    };

    const handleRemoveCoupon = () => {
        setAppliedCoupon(null);
        setCouponCode('');
        setDiscountAmount(0);
        setFinalAmount(originalAmount);
        setCouponMessage(null);
    };

    const handlePayment = async () => {
        console.log('Pay Now button clicked!');
        if (!course) {
            console.log('No course found');
            return;
        }

        console.log('Processing payment for course:', course.id);
        setIsProcessing(true);

        try {
            // Step 1: Create order on backend
            console.log('Creating payment order...');
            const orderResponse = await paymentService.createOrder(
                course.id,
                appliedCoupon || undefined
            );

            console.log('Order created:', orderResponse);

            // For web platform, use Razorpay web checkout
            if (Platform.OS === 'web') {
                console.log('Initializing Razorpay web checkout...');

                // Load Razorpay script dynamically
                const loadRazorpayScript = () => {
                    return new Promise((resolve) => {
                        // Check if already loaded
                        if ((window as any).Razorpay) {
                            console.log('Razorpay script already loaded');
                            resolve(true);
                            return;
                        }

                        const script = document.createElement('script');
                        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
                        script.onload = () => {
                            console.log('Razorpay script loaded successfully');
                            resolve(true);
                        };
                        script.onerror = () => {
                            console.error('Failed to load Razorpay script');
                            resolve(false);
                        };
                        document.body.appendChild(script);
                    });
                };

                const scriptLoaded = await loadRazorpayScript();

                if (!scriptLoaded) {
                    setIsProcessing(false);
                    Alert.alert('Error', 'Failed to load payment gateway. Please try again.');
                    return;
                }

                // Initialize Razorpay checkout
                const options = {
                    key: orderResponse.key_id,
                    amount: Math.round(orderResponse.amount * 100), // Amount in paise
                    currency: orderResponse.currency || 'INR',
                    name: 'LeQ',
                    description: course.title,
                    image: course.thumbnail_url || '',
                    order_id: orderResponse.order_id,
                    handler: async function (response: any) {
                        console.log('Payment successful on web:', response);

                        try {
                            // Verify payment on backend
                            const verifyResponse = await paymentService.verifyPayment({
                                payment_id: orderResponse.payment_id,
                                razorpay_payment_id: response.razorpay_payment_id,
                                razorpay_order_id: response.razorpay_order_id,
                                razorpay_signature: response.razorpay_signature,
                            });

                            console.log('Payment verified:', verifyResponse);
                            setIsProcessing(false);

                            // Navigate to success screen
                            router.push({
                                pathname: '/payment/success',
                                params: {
                                    courseId: course.id,
                                    courseTitle: course.title
                                }
                            });
                        } catch (verifyError: any) {
                            console.error('Payment verification failed:', verifyError);
                            setIsProcessing(false);

                            router.push({
                                pathname: '/payment/failure',
                                params: {
                                    courseId: course.id,
                                    error: 'Payment verification failed'
                                }
                            });
                        }
                    },
                    prefill: {
                        name: 'User Name', // TODO: Get from user profile
                        email: 'user@example.com', // TODO: Get from user profile
                        contact: '9999999999' // TODO: Get from user profile
                    },
                    notes: {
                        course_id: course.id,
                        course_title: course.title,
                    },
                    theme: {
                        color: '#8B5CF6'
                    },
                    modal: {
                        ondismiss: function () {
                            console.log('Payment modal dismissed by user');
                            setIsProcessing(false);
                        }
                    }
                };

                console.log('Opening Razorpay checkout with options:', options);

                // Create and open Razorpay checkout
                const rzp = new (window as any).Razorpay(options);

                rzp.on('payment.failed', function (response: any) {
                    console.error('Payment failed on web:', response.error);
                    setIsProcessing(false);

                    router.push({
                        pathname: '/payment/failure',
                        params: {
                            courseId: course.id,
                            error: response.error.description || 'Payment failed'
                        }
                    });
                });

                rzp.open();
                setIsProcessing(false); // Reset as modal is now handling the flow
                return;
            }

            // Step 2: For mobile, open Razorpay payment gateway

            router.push({
                pathname: '/payment/razorpay',
                params: {
                    order_id: orderResponse.order_id,
                    key_id: orderResponse.key_id,
                    amount: Math.round(orderResponse.amount * 100).toString(),
                    currency: orderResponse.currency || 'INR',
                    name: 'LeQ',
                    description: course.title,
                    image: course.thumbnail_url || '',
                    payment_id: orderResponse.payment_id,
                    course_id: course.id,
                    course_title: course.title,
                    prefill_email: 'user@example.com',
                    prefill_contact: '9999999999'
                }
            });
            setIsProcessing(false);
        } catch (error: any) {
            console.error('Error in payment flow:', error);
            setIsProcessing(false);

            Alert.alert(
                'Payment Error',
                error.response?.data?.error || error.message || 'Failed to initiate payment. Please try again.',
                [{ text: 'OK' }]
            );
        }
    };

    if (isLoading) {
        return <LoadingState message="Loading checkout..." />;
    }

    if (error || !course) {
        return <ErrorState message={error || 'Course not found'} onRetry={loadCourse} />;
    }

    return (
        <SafeAreaView style={styles.wrapper}>
            <Stack.Screen
                options={{
                    headerTitle: 'Checkout',
                    headerStyle: { backgroundColor: Colors.dark.background },
                    headerTintColor: Colors.dark.text,
                }}
            />

            <KeyboardAvoidingView
                style={styles.keyboardView}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
            >
                <ScrollView
                    style={styles.container}
                    contentContainerStyle={styles.scrollContent}
                    showsVerticalScrollIndicator={false}
                    bounces={false}
                >
                    <ScreenContainer>
                        {/* Course Summary */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Order Summary</Text>

                            <View style={styles.courseCard}>
                                {course.thumbnail_url ? (
                                    <Image
                                        source={{ uri: course.thumbnail_url }}
                                        style={styles.courseThumbnail}
                                        resizeMode="cover"
                                    />
                                ) : (
                                    <LinearGradient
                                        colors={[Colors.dark.primary, Colors.dark.secondary]}
                                        style={styles.courseThumbnail}
                                    >
                                        <Ionicons name="musical-notes" size={32} color="rgba(255,255,255,0.5)" />
                                    </LinearGradient>
                                )}

                                <View style={styles.courseInfo}>
                                    <Text style={styles.courseTitle} numberOfLines={2}>{course.title}</Text>
                                    <Text style={styles.courseTeacher}>{course.teacher?.full_name || 'Unknown Instructor'}</Text>
                                </View>
                            </View>
                        </View>

                        {/* Coupon Section */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Have a coupon code?</Text>

                            <View style={styles.couponContainer}>
                                <View style={styles.couponInputRow}>
                                    <TextInput
                                        style={[styles.couponInput, appliedCoupon && styles.couponInputDisabled]}
                                        placeholder="Enter coupon code"
                                        placeholderTextColor={Colors.dark.textMuted}
                                        value={couponCode}
                                        onChangeText={setCouponCode}
                                        editable={!appliedCoupon}
                                        autoCapitalize="characters"
                                    />

                                    {!appliedCoupon ? (
                                        <TouchableOpacity
                                            style={styles.couponButton}
                                            onPress={handleApplyCoupon}
                                            disabled={isValidatingCoupon}
                                        >
                                            {isValidatingCoupon ? (
                                                <ActivityIndicator size="small" color="#fff" />
                                            ) : (
                                                <Text style={styles.couponButtonText}>Apply</Text>
                                            )}
                                        </TouchableOpacity>
                                    ) : (
                                        <TouchableOpacity
                                            style={styles.removeCouponButton}
                                            onPress={handleRemoveCoupon}
                                        >
                                            <Ionicons name="close" size={20} color={Colors.dark.error} />
                                        </TouchableOpacity>
                                    )}
                                </View>

                                {couponMessage && (
                                    <View style={[
                                        styles.couponMessage,
                                        couponMessage.type === 'success' ? styles.couponMessageSuccess : styles.couponMessageError
                                    ]}>
                                        <Ionicons
                                            name={couponMessage.type === 'success' ? 'checkmark-circle' : 'alert-circle'}
                                            size={16}
                                            color={couponMessage.type === 'success' ? Colors.dark.success : Colors.dark.error}
                                        />
                                        <Text style={[
                                            styles.couponMessageText,
                                            couponMessage.type === 'success' ? styles.couponMessageTextSuccess : styles.couponMessageTextError
                                        ]}>{couponMessage.text}</Text>
                                    </View>
                                )}
                            </View>
                        </View>

                        {/* Price Breakdown */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Price Details</Text>

                            <View style={styles.priceCard}>
                                <View style={styles.priceRow}>
                                    <Text style={styles.priceLabel}>Original Price</Text>
                                    <Text style={styles.priceValue}>₹{originalAmount.toLocaleString('en-IN')}</Text>
                                </View>

                                {discountAmount > 0 && (
                                    <View style={styles.priceRow}>
                                        <Text style={[styles.priceLabel, styles.discountLabel]}>
                                            <Ionicons name="pricetag" size={14} /> Discount {appliedCoupon && `(${appliedCoupon})`}
                                        </Text>
                                        <Text style={styles.discountValue}>-₹{discountAmount.toLocaleString('en-IN')}</Text>
                                    </View>
                                )}

                                <View style={styles.divider} />

                                <View style={styles.priceRow}>
                                    <Text style={styles.totalLabel}>Total Amount</Text>
                                    <Text style={styles.totalValue}>₹{finalAmount.toLocaleString('en-IN')}</Text>
                                </View>
                            </View>
                        </View>

                        {/* Security Badge */}
                        <View style={styles.securityBadge}>
                            <Ionicons name="shield-checkmark" size={20} color={Colors.dark.success} />
                            <Text style={styles.securityText}>Secure payment powered by Razorpay</Text>
                        </View>
                    </ScreenContainer>
                </ScrollView>

                {/* Pay Button - Fixed at bottom */}
                <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, 16) }]}>
                    <ScreenContainer style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <View style={styles.bottomPriceContainer}>
                            <Text style={styles.bottomPriceLabel}>Total</Text>
                            <Text style={styles.bottomPriceValue}>₹{finalAmount.toLocaleString('en-IN')}</Text>
                        </View>

                        <TouchableOpacity
                            style={styles.payButton}
                            onPress={handlePayment}
                            disabled={isProcessing}
                            activeOpacity={0.7}
                        >
                            <LinearGradient
                                colors={[Colors.dark.primary, Colors.dark.secondary]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={styles.payGradient}
                            >
                                {isProcessing ? (
                                    <>
                                        <ActivityIndicator size="small" color="#fff" />
                                        <Text style={styles.payText}>Processing...</Text>
                                    </>
                                ) : (
                                    <>
                                        <Ionicons name="lock-closed" size={20} color="#fff" />
                                        <Text style={styles.payText}>Pay Now</Text>
                                    </>
                                )}
                            </LinearGradient>
                        </TouchableOpacity>
                    </ScreenContainer>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    keyboardView: {
        flex: 1,
    },
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    scrollContent: {
        paddingBottom: 20,
    },
    section: {
        padding: 20,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 16,
    },
    courseCard: {
        flexDirection: 'row',
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 12,
        gap: 12,
    },
    courseThumbnail: {
        width: 80,
        height: 80,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
    },
    courseInfo: {
        flex: 1,
        justifyContent: 'center',
    },
    courseTitle: {
        fontSize: 15,
        fontWeight: '600',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    courseTeacher: {
        fontSize: 13,
        color: Colors.dark.textSecondary,
    },
    couponContainer: {
        gap: 12,
    },
    couponInputRow: {
        flexDirection: 'row',
        gap: 8,
    },
    couponInput: {
        flex: 1,
        backgroundColor: Colors.dark.card,
        borderWidth: 1,
        borderColor: Colors.dark.border,
        borderRadius: 8,
        paddingHorizontal: 16,
        paddingVertical: 12,
        fontSize: 14,
        color: Colors.dark.text,
    },
    couponInputDisabled: {
        opacity: 0.6,
    },
    couponButton: {
        backgroundColor: Colors.dark.primary,
        borderRadius: 8,
        paddingHorizontal: 24,
        justifyContent: 'center',
        alignItems: 'center',
        minWidth: 80,
    },
    couponButtonText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#fff',
    },
    removeCouponButton: {
        backgroundColor: Colors.dark.card,
        borderWidth: 1,
        borderColor: Colors.dark.error,
        borderRadius: 8,
        paddingHorizontal: 16,
        justifyContent: 'center',
        alignItems: 'center',
    },
    couponMessage: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        padding: 12,
        borderRadius: 8,
    },
    couponMessageSuccess: {
        backgroundColor: `${Colors.dark.success}20`,
    },
    couponMessageError: {
        backgroundColor: `${Colors.dark.error}20`,
    },
    couponMessageText: {
        fontSize: 13,
        flex: 1,
    },
    couponMessageTextSuccess: {
        color: Colors.dark.success,
    },
    couponMessageTextError: {
        color: Colors.dark.error,
    },
    priceCard: {
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 16,
        gap: 12,
    },
    priceRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    priceLabel: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    priceValue: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.text,
    },
    discountLabel: {
        color: Colors.dark.success,
    },
    discountValue: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.success,
    },
    divider: {
        height: 1,
        backgroundColor: Colors.dark.border,
    },
    totalLabel: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
    },
    totalValue: {
        fontSize: 18,
        fontWeight: '700',
        color: Colors.dark.primary,
    },
    securityBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        padding: 20,
    },
    securityText: {
        fontSize: 13,
        color: Colors.dark.textMuted,
    },
    bottomBar: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        backgroundColor: Colors.dark.backgroundSecondary,
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
        elevation: 8,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    bottomPriceContainer: {
        gap: 4,
    },
    bottomPriceLabel: {
        fontSize: 12,
        color: Colors.dark.textMuted,
    },
    bottomPriceValue: {
        fontSize: 20,
        fontWeight: '700',
        color: Colors.dark.text,
    },
    payButton: {
        flex: 1,
        marginLeft: 16,
        borderRadius: 24,
        overflow: 'hidden',
    },
    payGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 14,
        gap: 8,
    },
    payText: {
        fontSize: 15,
        fontWeight: '600',
        color: '#fff',
    },
});

