import React from 'react';
import { StyleSheet, View, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { paymentService } from '@/services';

export default function RazorpayScreen() {
    const router = useRouter();
    const params = useLocalSearchParams();
    const insets = useSafeAreaInsets();

    // Extract parameters
    const {
        order_id,
        key_id,
        amount,
        currency,
        name,
        description,
        image,
        prefill_name,
        prefill_email,
        prefill_contact,
        theme_color
    } = params;

    const handleNavigationStateChange = (navState: any) => {
        // Handle external redirects if necessary (e.g. UPI apps)
    };

    const handleMessage = async (event: any) => {
        try {
            const data = JSON.parse(event.nativeEvent.data);
            console.log('WebView Message:', data);

            if (data.type === 'PAYMENT_SUCCESS') {
                // Verify payment on backend
                try {
                    const verifyResponse = await paymentService.verifyPayment({
                        payment_id: params.payment_id as string, // This comes from our backend order creation
                        razorpay_payment_id: data.payload.razorpay_payment_id,
                        razorpay_order_id: data.payload.razorpay_order_id,
                        razorpay_signature: data.payload.razorpay_signature,
                    });

                    router.dismiss(); // Close webview
                    router.replace({
                        pathname: '/payment/success',
                        params: {
                            courseId: params.course_id,
                            courseTitle: params.course_title
                        }
                    });
                } catch (err) {
                    console.error('Verification error:', err);
                    router.dismiss();
                    router.replace({
                        pathname: '/payment/failure',
                        params: {
                            courseId: params.course_id,
                            error: 'Payment verification failed'
                        }
                    });
                }
            } else if (data.type === 'PAYMENT_ERROR') {
                router.dismiss();
                router.replace({
                    pathname: '/payment/failure',
                    params: {
                        courseId: params.course_id,
                        error: data.payload.description || 'Payment failed'
                    }
                });
            } else if (data.type === 'PAYMENT_CANCELLED') {
                router.back();
            }
        } catch (err) {
            console.error('Error parsing webview message', err);
        }
    };

    const razorpayHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Payment</title>
            <style>
                body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: ${Colors.dark.background}; color: white; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
                .loader { border: 4px solid #f3f3f3; border-radius: 50%; border-top: 4px solid ${Colors.dark.primary}; width: 30px; height: 30px; -webkit-animation: spin 2s linear infinite; animation: spin 2s linear infinite; }
                @-webkit-keyframes spin { 0% { -webkit-transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); } }
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            </style>
        </head>
        <body>
            <div class="loader"></div>
            <p style="margin-left: 10px;">Initializing secure payment...</p>
            
            <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
            <script>
                var options = {
                    "key": "${key_id}",
                    "amount": "${amount}", 
                    "currency": "${currency}",
                    "name": "${name}",
                    "description": "${description}",
                    "image": "${image}",
                    "order_id": "${order_id}",
                    "prefill": {
                        "name": "${prefill_name || ''}",
                        "email": "${prefill_email || ''}",
                        "contact": "${prefill_contact || ''}"
                    },
                    "theme": {
                        "color": "${theme_color || '#8B5CF6'}"
                    },
                    "modal": {
                        "confirm_close": true,
                        "ondismiss": function(){
                            window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'PAYMENT_CANCELLED' }));
                        }
                    }
                };
                
                options.handler = function (response){
                    window.ReactNativeWebView.postMessage(JSON.stringify({
                        type: 'PAYMENT_SUCCESS',
                        payload: response
                    }));
                };

                var rzp1 = new Razorpay(options);
                
                rzp1.on('payment.failed', function (response){
                    window.ReactNativeWebView.postMessage(JSON.stringify({
                        type: 'PAYMENT_ERROR',
                        payload: response.error
                    }));
                });

                // Auto open
                window.onload = function(){
                    rzp1.open();
                };
            </script>
        </body>
        </html>
    `;

    return (
        <View style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
            <Stack.Screen
                options={{
                    headerStyle: { backgroundColor: Colors.dark.background },
                    headerTintColor: Colors.dark.text,
                }}
            />
            <WebView
                source={{ html: razorpayHtml }}
                onMessage={handleMessage}
                onNavigationStateChange={handleNavigationStateChange}
                javaScriptEnabled={true}
                domStorageEnabled={true}
                startInLoadingState={true}
                renderLoading={() => (
                    <View style={styles.loadingContainer}>
                        <ActivityIndicator size="large" color={Colors.dark.primary} />
                    </View>
                )}
                style={{ flex: 1, backgroundColor: 'transparent' }}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    loadingContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.dark.background,
    }
});
