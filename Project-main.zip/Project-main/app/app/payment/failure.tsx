/**
 * Payment Failure Screen
 */

import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { Colors } from '@/constants/Colors';
import { ScreenContainer } from '@/components/ui';

export default function PaymentFailureScreen() {
    const { courseId, error } = useLocalSearchParams();
    const router = useRouter();

    const handleTryAgain = () => {
        if (courseId) {
            router.replace({
                pathname: '/payment/checkout',
                params: { courseId }
            });
        } else {
            router.replace('/(tabs)/courses');
        }
    };

    const handleGoHome = () => {
        router.replace('/(tabs)');
    };

    const handleContactSupport = () => {
        router.push('/contact');
    };

    return (
        <>
            <Stack.Screen
                options={{
                    headerShown: false,
                }}
            />

            <View style={styles.container}>
                <LinearGradient
                    colors={[Colors.dark.background, Colors.dark.backgroundSecondary]}
                    style={styles.gradient}
                >
                    <ScreenContainer style={{ flex: 1, justifyContent: 'space-between' }}>
                        {/* Error Icon */}
                        <View style={styles.iconContainer}>
                            <View style={styles.errorCircle}>
                                <Ionicons name="close" size={80} color="#fff" />
                            </View>
                        </View>

                        {/* Error Message */}
                        <View style={styles.content}>
                            <Text style={styles.title}>Payment Failed</Text>
                            <Text style={styles.subtitle}>
                                We couldn't process your payment
                            </Text>

                            {error && (
                                <View style={styles.errorBox}>
                                    <Ionicons name="alert-circle" size={20} color={Colors.dark.error} />
                                    <Text style={styles.errorText}>
                                        {typeof error === 'string' ? error : 'An error occurred during payment processing'}
                                    </Text>
                                </View>
                            )}

                            <View style={styles.reasonsBox}>
                                <Text style={styles.reasonsTitle}>Common reasons:</Text>
                                <View style={styles.reasonItem}>
                                    <Ionicons name="ellipse" size={6} color={Colors.dark.textMuted} />
                                    <Text style={styles.reasonText}>Insufficient balance</Text>
                                </View>
                                <View style={styles.reasonItem}>
                                    <Ionicons name="ellipse" size={6} color={Colors.dark.textMuted} />
                                    <Text style={styles.reasonText}>Payment gateway timeout</Text>
                                </View>
                                <View style={styles.reasonItem}>
                                    <Ionicons name="ellipse" size={6} color={Colors.dark.textMuted} />
                                    <Text style={styles.reasonText}>Incorrect card details</Text>
                                </View>
                                <View style={styles.reasonItem}>
                                    <Ionicons name="ellipse" size={6} color={Colors.dark.textMuted} />
                                    <Text style={styles.reasonText}>Network connection issue</Text>
                                </View>
                            </View>
                        </View>

                        {/* Action Buttons */}
                        <View style={styles.buttonContainer}>
                            <TouchableOpacity
                                style={styles.primaryButton}
                                onPress={handleTryAgain}
                            >
                                <LinearGradient
                                    colors={[Colors.dark.primary, Colors.dark.secondary]}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 0 }}
                                    style={styles.buttonGradient}
                                >
                                    <Ionicons name="refresh" size={20} color="#fff" />
                                    <Text style={styles.primaryButtonText}>Try Again</Text>
                                </LinearGradient>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.secondaryButton}
                                onPress={handleContactSupport}
                            >
                                <Ionicons name="help-circle-outline" size={20} color={Colors.dark.text} />
                                <Text style={styles.secondaryButtonText}>Contact Support</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.tertiaryButton}
                                onPress={handleGoHome}
                            >
                                <Text style={styles.tertiaryButtonText}>Go to Home</Text>
                            </TouchableOpacity>
                        </View>
                    </ScreenContainer>
                </LinearGradient>
            </View>
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    gradient: {
        flex: 1,
        justifyContent: 'space-between',
        padding: 20,
        paddingTop: 60,
        paddingBottom: 40,
    },
    iconContainer: {
        alignItems: 'center',
        marginTop: 40,
    },
    errorCircle: {
        width: 160,
        height: 160,
        borderRadius: 80,
        backgroundColor: Colors.dark.error,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: Colors.dark.error,
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 16,
        elevation: 8,
    },
    content: {
        alignItems: 'center',
        gap: 16,
    },
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.text,
        textAlign: 'center',
    },
    subtitle: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
    },
    errorBox: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 12,
        backgroundColor: `${Colors.dark.error}20`,
        padding: 16,
        borderRadius: 12,
        borderLeftWidth: 3,
        borderLeftColor: Colors.dark.error,
        width: '100%',
        marginTop: 8,
    },
    errorText: {
        flex: 1,
        fontSize: 14,
        color: Colors.dark.error,
        lineHeight: 20,
    },
    reasonsBox: {
        backgroundColor: Colors.dark.card,
        padding: 16,
        borderRadius: 12,
        width: '100%',
        gap: 12,
    },
    reasonsTitle: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    reasonItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
    },
    reasonText: {
        fontSize: 13,
        color: Colors.dark.textMuted,
    },
    buttonContainer: {
        gap: 12,
    },
    primaryButton: {
        borderRadius: 24,
        overflow: 'hidden',
    },
    buttonGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 16,
        gap: 8,
    },
    primaryButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#fff',
    },
    secondaryButton: {
        backgroundColor: Colors.dark.card,
        borderRadius: 24,
        paddingVertical: 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    secondaryButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.text,
    },
    tertiaryButton: {
        paddingVertical: 16,
        alignItems: 'center',
    },
    tertiaryButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.textMuted,
    },
});
