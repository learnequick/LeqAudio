/**
 * Contact Screen
 */

import React, { useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    TextInput,
    Alert,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/ui';

export default function ContactScreen() {
    const router = useRouter();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [subject, setSubject] = useState('');
    const [message, setMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async () => {
        if (!name || !email || !message) {
            Alert.alert('Error', 'Please fill in all required fields');
            return;
        }

        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
            setIsLoading(false);
            Alert.alert('Success', 'Your message has been sent successfully!', [
                { text: 'OK', onPress: () => router.back() },
            ]);
        }, 1500);
    };

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <LinearGradient
                colors={[Colors.dark.primary, Colors.dark.secondary]}
                style={styles.header}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View style={styles.headerContent}>
                    <Ionicons name="mail" size={32} color="white" />
                    <Text style={styles.headerTitle}>Contact Us</Text>
                    <Text style={styles.headerSubtitle}>We'd love to hear from you</Text>
                </View>
            </LinearGradient>

            {/* Content */}
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={{ flex: 1 }}
            >
                <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                    <ScreenContainer>
                        {/* Contact Form Card */}
                        <View style={styles.card}>
                            <View style={styles.iconCircle}>
                                <Ionicons name="chatbubbles" size={32} color="white" />
                            </View>
                            <Text style={styles.cardTitle}>Get In Touch</Text>
                            <Text style={styles.cardSubtitle}>
                                Have a question, feedback, or need help? Fill out the form below or
                                reach us directly using the contact details.
                            </Text>

                            <View style={styles.form}>
                                {/* Name Input */}
                                <View style={styles.inputContainer}>
                                    <Text style={styles.label}>Your Name</Text>
                                    <TextInput
                                        style={styles.input}
                                        placeholder="Enter your full name"
                                        placeholderTextColor={Colors.dark.textMuted}
                                        value={name}
                                        onChangeText={setName}
                                    />
                                </View>

                                {/* Email Input */}
                                <View style={styles.inputContainer}>
                                    <Text style={styles.label}>Email</Text>
                                    <TextInput
                                        style={styles.input}
                                        placeholder="your.email@example.com"
                                        placeholderTextColor={Colors.dark.textMuted}
                                        keyboardType="email-address"
                                        autoCapitalize="none"
                                        value={email}
                                        onChangeText={setEmail}
                                    />
                                </View>

                                {/* Subject Input */}
                                <View style={styles.inputContainer}>
                                    <Text style={styles.label}>Subject</Text>
                                    <TextInput
                                        style={styles.input}
                                        placeholder="What is this regarding?"
                                        placeholderTextColor={Colors.dark.textMuted}
                                        value={subject}
                                        onChangeText={setSubject}
                                    />
                                </View>

                                {/* Message Input */}
                                <View style={styles.inputContainer}>
                                    <Text style={styles.label}>Message</Text>
                                    <TextInput
                                        style={[styles.input, styles.textArea]}
                                        placeholder="Tell us how we can help you..."
                                        placeholderTextColor={Colors.dark.textMuted}
                                        multiline
                                        numberOfLines={6}
                                        textAlignVertical="top"
                                        value={message}
                                        onChangeText={setMessage}
                                    />
                                </View>

                                {/* Submit Button */}
                                <TouchableOpacity
                                    style={styles.submitButton}
                                    onPress={handleSubmit}
                                    disabled={isLoading}
                                >
                                    <LinearGradient
                                        colors={[Colors.dark.primary, Colors.dark.secondary]}
                                        style={styles.submitGradient}
                                        start={{ x: 0, y: 0 }}
                                        end={{ x: 1, y: 1 }}
                                    >
                                        {isLoading ? (
                                            <Text style={styles.submitButtonText}>Sending...</Text>
                                        ) : (
                                            <>
                                                <Ionicons name="paper-plane" size={20} color="white" />
                                                <Text style={styles.submitButtonText}>Send Message</Text>
                                            </>
                                        )}
                                    </LinearGradient>
                                </TouchableOpacity>
                            </View>
                        </View>

                        {/* Contact Details Grid */}
                        <View style={styles.detailsGrid}>
                            {/* Address */}
                            <View style={styles.detailCard}>
                                <LinearGradient
                                    colors={['#667eea', '#764ba2']}
                                    style={styles.detailIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="location" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.detailTitle}>Address</Text>
                                <Text style={styles.detailText}>Beta 2{'\n'}Greater Noida</Text>
                            </View>

                            {/* Email */}
                            <View style={styles.detailCard}>
                                <LinearGradient
                                    colors={['#f093fb', '#f5576c']}
                                    style={styles.detailIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="mail" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.detailTitle}>Email</Text>
                                <Text style={styles.detailText}>learnequick@gmail.com</Text>
                            </View>

                            {/* Phone */}
                            <View style={styles.detailCard}>
                                <LinearGradient
                                    colors={['#4facfe', '#00f2fe']}
                                    style={styles.detailIcon}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="call" size={24} color="white" />
                                </LinearGradient>
                                <Text style={styles.detailTitle}>Phone</Text>
                                <Text style={styles.detailText}>+91 9934556012</Text>
                            </View>
                        </View>

                        {/* Bottom Padding */}
                        <View style={{ height: 40 }} />
                    </ScreenContainer>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingVertical: 32,
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerContent: {
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: '700',
        color: 'white',
        marginTop: 12,
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    content: {
        flex: 1,
    },
    card: {
        backgroundColor: Colors.dark.card,
        margin: 16,
        borderRadius: 16,
        padding: 24,
        alignItems: 'center',
    },
    iconCircle: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: Colors.dark.backgroundSecondary,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
        overflow: 'hidden', // Ensure gradient stays within circle if applied
    },
    cardTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 12,
    },
    cardSubtitle: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        textAlign: 'center',
        marginBottom: 24,
        lineHeight: 20,
    },
    form: {
        width: '100%',
    },
    inputContainer: {
        marginBottom: 20,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    input: {
        backgroundColor: Colors.dark.background,
        borderRadius: 8,
        padding: 12,
        color: Colors.dark.text,
        borderWidth: 1,
        borderColor: Colors.dark.border,
        fontSize: 14,
    },
    textArea: {
        height: 120,
        textAlignVertical: 'top',
    },
    submitButton: {
        borderRadius: 12,
        overflow: 'hidden',
        marginTop: 12,
    },
    submitGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 16,
        gap: 8,
    },
    submitButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
    },
    detailsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingHorizontal: 8,
        gap: 16,
        justifyContent: 'center',
    },
    detailCard: {
        backgroundColor: Colors.dark.card,
        width: '45%', // Approximate for 2 columns or slightly adjusted for 3
        borderRadius: 12,
        padding: 16,
        alignItems: 'center',
        minWidth: 140, // Ensure decent width on smaller screens
        flexGrow: 1,
    },
    detailIcon: {
        width: 50,
        height: 50,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 12,
    },
    detailTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    detailText: {
        fontSize: 13,
        color: Colors.dark.textMuted,
        textAlign: 'center',
    },
});
