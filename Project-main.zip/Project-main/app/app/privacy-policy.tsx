/**
 * Privacy Policy Screen
 */

import React from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/ui';

export default function PrivacyPolicyScreen() {
    const router = useRouter();

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <LinearGradient
                colors={[Colors.dark.primary, Colors.dark.secondary]}
                style={styles.header}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View style={styles.headerContent}>
                    <Ionicons name="shield-checkmark" size={32} color="white" />
                    <Text style={styles.headerTitle}>Privacy Policy</Text>
                    <Text style={styles.headerSubtitle}>How we protect your data</Text>
                </View>
            </LinearGradient>

            {/* Content */}
            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <ScreenContainer>
                    <View style={styles.card}>
                        <View style={styles.alertBox}>
                            <Ionicons
                                name="lock-closed"
                                size={20}
                                color={Colors.dark.primary}
                            />
                            <Text style={styles.alertText}>
                                Your privacy is important to us. This policy explains how we collect,
                                use, and safeguard your personal information when you use LeQ.
                            </Text>
                        </View>

                        {/* Information Collection */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#667eea', '#764ba2']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="cloud-download" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Information We Collect</Text>
                                <Text style={styles.sectionText}>
                                    We collect information you provide directly to us, such as your
                                    name, email address, and profile information when you create an account
                                    or purchase a course.
                                </Text>
                            </View>
                        </View>

                        {/* Data Usage */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#f093fb', '#f5576c']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="analytics" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>How We Use Data</Text>
                                <Text style={styles.sectionText}>
                                    Your data is used to provide and personalize our services,
                                    process payments, and communicate with you about your
                                    courses and updates.
                                </Text>
                            </View>
                        </View>

                        {/* Data Security */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#4facfe', '#00f2fe']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="shield" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Data Security</Text>
                                <Text style={styles.sectionText}>
                                    We implement industry-standard security measures to protect
                                    your personal information from unauthorized access,
                                    alteration, or disclosure.
                                </Text>
                            </View>
                        </View>

                        {/* Contact */}
                        <View style={styles.section}>
                            <LinearGradient
                                colors={['#fa709a', '#fee140']}
                                style={styles.iconBox}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                            >
                                <Ionicons name="mail" size={24} color="white" />
                            </LinearGradient>
                            <View style={styles.sectionContent}>
                                <Text style={styles.sectionTitle}>Privacy Contact</Text>
                                <Text style={styles.sectionText}>
                                    If you have any questions about our privacy practices,
                                    please contact us at{' '}
                                    <Text style={styles.link}>privacy@leq.example</Text>.
                                </Text>
                            </View>
                        </View>
                    </View>
                </ScreenContainer>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingVertical: 32,
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerContent: {
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: '700',
        color: 'white',
        marginTop: 12,
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    content: {
        flex: 1,
    },
    card: {
        backgroundColor: Colors.dark.card,
        margin: 16,
        borderRadius: 16,
        padding: 20,
    },
    alertBox: {
        flexDirection: 'row',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        borderLeftWidth: 4,
        borderLeftColor: Colors.dark.primary,
        padding: 16,
        borderRadius: 8,
        marginBottom: 24,
        gap: 12,
    },
    alertText: {
        flex: 1,
        fontSize: 14,
        color: Colors.dark.text,
        lineHeight: 22,
    },
    section: {
        flexDirection: 'row',
        marginBottom: 24,
        gap: 16,
    },
    iconBox: {
        width: 50,
        height: 50,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    sectionContent: {
        flex: 1,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    sectionText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 22,
    },
    link: {
        color: Colors.dark.primary,
        textDecorationLine: 'underline',
    },
});
