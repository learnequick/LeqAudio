/**
 * Notifications Screen - User notifications
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    RefreshControl
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { Colors } from '@/constants/Colors';
import { Notification } from '@/types';
import { notificationService } from '@/services';
import { LoadingState, ErrorState, EmptyState, ScreenContainer } from '@/components/ui/index';

export default function NotificationsScreen() {
    const router = useRouter();

    const [isLoading, setIsLoading] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [notifications, setNotifications] = useState<Notification[]>([]);

    const loadNotifications = async () => {
        try {
            setError(null);
            const data = await notificationService.getNotifications();
            setNotifications(data);
        } catch (err) {
            setError('Failed to load notifications. Please try again.');
        } finally {
            setIsLoading(false);
            setIsRefreshing(false);
        }
    };

    useEffect(() => {
        loadNotifications();
    }, []);

    const onRefresh = useCallback(() => {
        setIsRefreshing(true);
        loadNotifications();
    }, []);

    const handleNotificationPress = async (notification: Notification) => {
        // Mark as read
        if (!notification.is_read) {
            await notificationService.markAsRead(notification.id);
            setNotifications(prev =>
                prev.map(n => n.id === notification.id ? { ...n, is_read: true } : n)
            );
        }

        // Navigate based on notification type
        if (notification.course) {
            router.push(`/course/${notification.course.id}`);
        }
    };

    const handleMarkAllRead = async () => {
        try {
            await notificationService.markAllAsRead();
            setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
        } catch (err) {
            console.error('Failed to mark all as read');
        }
    };

    const formatTime = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 60) {
            return `${diffMins}m ago`;
        } else if (diffHours < 24) {
            return `${diffHours}h ago`;
        } else if (diffDays < 7) {
            return `${diffDays}d ago`;
        } else {
            return date.toLocaleDateString();
        }
    };

    const getNotificationIcon = (type: string): keyof typeof Ionicons.glyphMap => {
        switch (type) {
            case 'course_update':
                return 'book';
            case 'enrollment':
                return 'checkmark-circle';
            case 'payment':
                return 'card';
            case 'certificate':
                return 'ribbon';
            default:
                return 'notifications';
        }
    };

    const renderNotification = ({ item }: { item: Notification }) => (
        <TouchableOpacity
            style={[styles.notificationItem, !item.is_read && styles.unreadItem]}
            onPress={() => handleNotificationPress(item)}
        >
            <View style={[styles.iconContainer, !item.is_read && styles.unreadIcon]}>
                <Ionicons
                    name={getNotificationIcon(item.notification_type)}
                    size={20}
                    color={item.is_read ? Colors.dark.textMuted : Colors.dark.primary}
                />
            </View>
            <View style={styles.contentContainer}>
                <Text style={[styles.title, !item.is_read && styles.unreadTitle]}>
                    {item.title}
                </Text>
                <Text style={styles.message} numberOfLines={2}>
                    {item.message}
                </Text>
                <Text style={styles.time}>{formatTime(item.created_at)}</Text>
            </View>
            {!item.is_read && <View style={styles.unreadDot} />}
        </TouchableOpacity>
    );

    if (isLoading && !isRefreshing) {
        return (
            <>
                <Stack.Screen options={{ title: 'Notifications' }} />
                <LoadingState message="Loading notifications..." />
            </>
        );
    }

    if (error) {
        return (
            <>
                <Stack.Screen options={{ title: 'Notifications' }} />
                <ErrorState message={error} onRetry={loadNotifications} />
            </>
        );
    }

    const unreadCount = notifications.filter(n => !n.is_read).length;

    return (
        <>
            <Stack.Screen
                options={{
                    title: 'Notifications',
                    headerRight: unreadCount > 0 ? () => (
                        <TouchableOpacity onPress={handleMarkAllRead} style={styles.markAllButton}>
                            <Text style={styles.markAllText}>Mark all read</Text>
                        </TouchableOpacity>
                    ) : undefined,
                }}
            />

            <View style={styles.container}>
                <ScreenContainer>
                    {notifications.length === 0 ? (
                        <EmptyState
                            icon="notifications-off-outline"
                            title="No notifications"
                            message="You're all caught up! Check back later for updates."
                        />
                    ) : (
                        <FlatList
                            data={notifications}
                            keyExtractor={(item) => String(item.id)}
                            renderItem={renderNotification}
                            contentContainerStyle={styles.list}
                            showsVerticalScrollIndicator={false}
                            refreshControl={
                                <RefreshControl
                                    refreshing={isRefreshing}
                                    onRefresh={onRefresh}
                                    tintColor={Colors.dark.primary}
                                />
                            }
                        />
                    )}
                </ScreenContainer>
            </View>
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    markAllButton: {
        marginRight: 8,
    },
    markAllText: {
        fontSize: 14,
        color: Colors.dark.primary,
        fontWeight: '500',
    },
    list: {
        padding: 16,
    },
    notificationItem: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: Colors.dark.card,
        borderRadius: 14,
        padding: 14,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    unreadItem: {
        backgroundColor: `${Colors.dark.primary}08`,
        borderColor: `${Colors.dark.primary}30`,
    },
    iconContainer: {
        width: 44,
        height: 44,
        borderRadius: 12,
        backgroundColor: Colors.dark.backgroundSecondary,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    unreadIcon: {
        backgroundColor: `${Colors.dark.primary}20`,
    },
    contentContainer: {
        flex: 1,
    },
    title: {
        fontSize: 15,
        fontWeight: '500',
        color: Colors.dark.text,
        marginBottom: 4,
    },
    unreadTitle: {
        fontWeight: '600',
    },
    message: {
        fontSize: 13,
        color: Colors.dark.textSecondary,
        lineHeight: 18,
        marginBottom: 6,
    },
    time: {
        fontSize: 11,
        color: Colors.dark.textMuted,
    },
    unreadDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: Colors.dark.primary,
        marginLeft: 8,
        marginTop: 4,
    },
});
