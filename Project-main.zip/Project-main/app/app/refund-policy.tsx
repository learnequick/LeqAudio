/**
 * Refund Policy Screen
 */

import React from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/ui';

export default function RefundPolicyScreen() {
    const router = useRouter();

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <LinearGradient
                colors={[Colors.dark.primary, Colors.dark.secondary]}
                style={styles.header}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View style={styles.headerContent}>
                    <Ionicons name="receipt" size={32} color="white" />
                    <Text style={styles.headerTitle}>Refund & Cancellation Policy</Text>
                    <Text style={styles.headerSubtitle}>
                        Important information about refunds
                    </Text>
                </View>
            </LinearGradient>

            {/* Content */}
            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <ScreenContainer>
                    <View style={styles.card}>
                        {/* Last Updated */}
                        <View style={styles.alertBox}>
                            <Ionicons name="warning" size={20} color="#FDB022" />
                            <Text style={styles.alertText}>
                                Last updated: Jan 1, 2026
                            </Text>
                        </View>

                        {/* Summary Card */}
                        <View style={styles.summaryCard}>
                            <View style={styles.summaryIconBox}>
                                <Ionicons name="information-circle" size={32} color="white" />
                            </View>
                            <View style={styles.summaryContent}>
                                <Text style={styles.summaryTitle}>Summary</Text>
                                <Text style={styles.summaryText}>
                                    All sales are final. Once a course is purchased, refunds are not
                                    provided under normal circumstances. Refunds may only be considered
                                    in exceptional cases at our sole discretion.
                                </Text>
                            </View>
                        </View>

                        {/* Sections */}
                        <View style={styles.sectionsContainer}>
                            {/* Eligibility */}
                            <View style={styles.section}>
                                <LinearGradient
                                    colors={['#667eea', '#764ba2']}
                                    style={styles.iconBox}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="checkmark-circle" size={24} color="white" />
                                </LinearGradient>
                                <View style={styles.sectionContent}>
                                    <Text style={styles.sectionTitle}>Eligibility</Text>
                                    <View style={styles.bulletList}>
                                        <View style={styles.bulletItem}>
                                            <View style={styles.bullet} />
                                            <Text style={styles.bulletText}>
                                                No refunds are provided for course purchases once
                                                completed.
                                            </Text>
                                        </View>
                                        <View style={styles.bulletItem}>
                                            <View style={styles.bullet} />
                                            <Text style={styles.bulletText}>
                                                Refunds may be considered only in special
                                                circumstances such as technical issues preventing
                                                access to purchased content, duplicate purchases, or
                                                other exceptional cases.
                                            </Text>
                                        </View>
                                        <View style={styles.bulletItem}>
                                            <View style={styles.bullet} />
                                            <Text style={styles.bulletText}>
                                                All refund requests are subject to review and approval
                                                by our support team.
                                            </Text>
                                        </View>
                                        <View style={styles.bulletItem}>
                                            <View style={styles.bullet} />
                                            <Text style={styles.bulletText}>
                                                Subscription cancellations will remain active until
                                                the current billing period ends; no refunds for unused
                                                portions.
                                            </Text>
                                        </View>
                                    </View>
                                </View>
                            </View>

                            {/* How to Request */}
                            <View style={styles.section}>
                                <LinearGradient
                                    colors={['#f093fb', '#f5576c']}
                                    style={styles.iconBox}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="paper-plane" size={24} color="white" />
                                </LinearGradient>
                                <View style={styles.sectionContent}>
                                    <Text style={styles.sectionTitle}>How to Request a Refund</Text>
                                    <Text style={styles.sectionText}>
                                        If you believe your situation qualifies for a refund under
                                        special circumstances, please contact our support team
                                        directly at{' '}
                                        <Text style={styles.link}>support@leq.example</Text> with
                                        detailed information about your case. Refund requests are
                                        reviewed on a case-by-case basis.
                                    </Text>
                                </View>
                            </View>

                            {/* Processing Time */}
                            <View style={styles.section}>
                                <LinearGradient
                                    colors={['#4facfe', '#00f2fe']}
                                    style={styles.iconBox}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                >
                                    <Ionicons name="time" size={24} color="white" />
                                </LinearGradient>
                                <View style={styles.sectionContent}>
                                    <Text style={styles.sectionTitle}>Processing Time</Text>
                                    <Text style={styles.sectionText}>
                                        If a refund is approved, it will typically be processed within
                                        5-7 business days. Please note that approval is not guaranteed
                                        and depends on the specific circumstances of each case.
                                    </Text>
                                </View>
                            </View>
                        </View>
                    </View>
                </ScreenContainer>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        paddingVertical: 32,
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerContent: {
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 22,
        fontWeight: '700',
        color: 'white',
        marginTop: 12,
        marginBottom: 8,
        textAlign: 'center',
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    content: {
        flex: 1,
    },
    card: {
        backgroundColor: Colors.dark.card,
        margin: 16,
        borderRadius: 16,
        padding: 20,
    },
    alertBox: {
        flexDirection: 'row',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        borderLeftWidth: 4,
        borderLeftColor: '#FDB022',
        padding: 16,
        borderRadius: 8,
        marginBottom: 24,
        gap: 12,
        alignItems: 'center',
    },
    alertText: {
        fontSize: 14,
        color: Colors.dark.text,
        fontWeight: '600',
    },
    summaryCard: {
        backgroundColor: 'rgba(253, 176, 34, 0.1)',
        borderWidth: 1,
        borderColor: 'rgba(253, 176, 34, 0.3)',
        borderRadius: 12,
        padding: 20,
        flexDirection: 'row',
        gap: 16,
        marginBottom: 32,
    },
    summaryIconBox: {
        width: 60,
        height: 60,
        backgroundColor: '#FDB022',
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    summaryContent: {
        flex: 1,
    },
    summaryTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: '#FDB022', // Using yellow/gold for summary title
        marginBottom: 8,
    },
    summaryText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 22,
    },
    sectionsContainer: {
        gap: 32,
    },
    section: {
        flexDirection: 'row',
        gap: 16,
    },
    iconBox: {
        width: 50,
        height: 50,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    sectionContent: {
        flex: 1,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.dark.text,
        marginBottom: 8,
    },
    sectionText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 22,
    },
    link: {
        color: Colors.dark.primary,
        textDecorationLine: 'underline',
    },
    bulletList: {
        gap: 12,
    },
    bulletItem: {
        flexDirection: 'row',
        gap: 12,
    },
    bullet: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: Colors.dark.textMuted,
        marginTop: 8,
    },
    bulletText: {
        fontSize: 14,
        color: Colors.dark.textMuted,
        lineHeight: 22,
        flex: 1,
    },
});
