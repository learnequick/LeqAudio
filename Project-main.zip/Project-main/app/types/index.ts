/**
 * TypeScript Types for LEQ Mobile App
 */

export interface User {
    id: number;
    email: string;
    first_name: string;
    last_name: string;
    full_name: string;
    phone: string;
    role: 'student' | 'teacher' | 'admin';
    profile_picture_url: string | null;
    email_verified: boolean;
    date_joined: string;
    total_enrollments: number;
    total_completed: number;
    is_free_user: boolean;
}

export interface AuthResponse {
    token: string;
    user: User;
}

export interface Category {
    id: number;
    name: string;
    slug: string;
    description: string;
    icon: string;
    course_count: number;
}

export interface Teacher {
    id: number;
    full_name: string;
    profile_picture_url: string | null;
}

export interface Course {
    id: number;
    title: string;
    slug: string;
    short_description: string;
    description: string;
    thumbnail_url: string | null;
    teacher: Teacher;
    category: Category;
    level: 'beginner' | 'intermediate' | 'advanced';
    price: number;
    discount_price: number | null;
    actual_price: number;
    is_free: boolean;
    is_featured: boolean;
    average_rating: number;
    total_reviews: number;
    total_enrollments: number;
    total_duration_minutes: number;
    total_lessons: number;
    created_at: string;
}

export interface CourseDetail extends Course {
    modules: Module[];
    is_enrolled: boolean;
    enrollment_id: number | null;
}

export interface Module {
    id: number;
    title: string;
    order: number;
    lessons: Lesson[];
}

export interface Lesson {
    id: number;
    title: string;
    description: string;
    lesson_type: 'audio' | 'video';
    order: number;
    audio_url: string | null;
    video_url: string | null;
    duration_seconds: number;
    duration_minutes: number;
    is_free_preview: boolean;
    is_completed: boolean;
    progress_percentage: number;
}

export interface Enrollment {
    id: number;
    course: Course | number;
    course_id?: number;
    course_title?: string;
    course_thumbnail?: string;
    teacher_name?: string;
    enrolled_at: string;
    status: 'active' | 'completed' | 'expired';
    progress_percentage: number;
    last_accessed_at: string | null;
    completed_lessons: number;
    total_lessons: number;
}

export interface Banner {
    id: number;
    title: string;
    subtitle: string;
    image_url: string;
    action_url: string;
    action_text: string;
    order: number;
}

export interface Notification {
    id: number;
    title: string;
    message: string;
    notification_type: string;
    is_read: boolean;
    created_at: string;
    course: Course | null;
    lesson: Lesson | null;
}

export interface Review {
    id: number;
    rating: number;
    comment: string;
    student: {
        id: number;
        full_name: string;
        profile_picture_url: string | null;
    };
    created_at: string;
}

export interface ApiError {
    error: string;
    message?: string;
}
