import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';

export const lessonService = {
    /**
     * Update lesson progress
     * @param id Lesson ID
     * @param progress Percentage (0-100)
     */
    async updateProgress(id: number | string, progress: number): Promise<void> {
        await api.post(API_ENDPOINTS.LESSONS.UPDATE_PROGRESS(id), {
            progress_percentage: Math.min(100, Math.max(0, progress))
        });
    }
};

export default lessonService;
