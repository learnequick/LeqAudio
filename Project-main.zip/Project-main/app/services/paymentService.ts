/**
 * Payment Service - Handles payment operations
 */

import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';

export interface CouponValidationResponse {
    valid: boolean;
    message: string;
    discount_amount?: number;
    final_amount?: number;
    original_amount?: number;
    discount_type?: 'percentage' | 'fixed';
    discount_value?: number;
}

export interface CreateOrderResponse {
    payment_id: string;
    order_id: string;
    amount: number;
    currency: string;
    key_id?: string;
    course_title?: string;
}

export interface VerifyPaymentResponse {
    status: 'success' | 'failed';
    payment_id?: string;
    message: string;
    redirect_url?: string;
}

class PaymentService {
    /**
     * Validate a coupon code for a course
     */
    async validateCoupon(couponCode: string, courseId: number | string): Promise<CouponValidationResponse> {
        try {
            console.log('Validating coupon:', { couponCode, courseId });
            const response = await api.post(API_ENDPOINTS.PAYMENTS.VALIDATE_COUPON, {
                coupon_code: couponCode,
                course_id: courseId
            });
            console.log('Coupon validation response:', response.data);
            return response.data;
        } catch (error: any) {
            console.error('Error validating coupon:', error);
            console.error('Error response:', error.response?.data);
            // Return error response if available
            if (error.response?.data) {
                return {
                    valid: false,
                    message: error.response.data.message || 'Failed to validate coupon'
                };
            }
            throw error;
        }
    }

    /**
     * Create a payment order
     */
    async createOrder(courseId: number | string, couponCode?: string): Promise<CreateOrderResponse> {
        try {
            const response = await api.post(API_ENDPOINTS.PAYMENTS.CREATE_ORDER, {
                course_id: courseId,
                coupon_code: couponCode
            });
            return response.data;
        } catch (error: any) {
            console.error('Error creating order:', error);
            throw error;
        }
    }

    /**
     * Verify payment after completion
     */
    async verifyPayment(paymentData: {
        payment_id: string;
        razorpay_order_id: string;
        razorpay_payment_id: string;
        razorpay_signature: string;
    }): Promise<VerifyPaymentResponse> {
        try {
            const response = await api.post(API_ENDPOINTS.PAYMENTS.VERIFY, paymentData);
            return response.data;
        } catch (error: any) {
            console.error('Error verifying payment:', error);
            throw error;
        }
    }

    /**
     * Get payment history
     */
    async getPaymentHistory() {
        try {
            const response = await api.get(API_ENDPOINTS.PAYMENTS.LIST);
            return response.data;
        } catch (error: any) {
            console.error('Error fetching payment history:', error);
            throw error;
        }
    }
}

export const paymentService = new PaymentService();
