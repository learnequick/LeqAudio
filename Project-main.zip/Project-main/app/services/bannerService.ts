/**
 * Banner Service - Banner API calls
 */

import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';
import { Banner } from '@/types';

export const bannerService = {
    /**
     * Get all active banners
     */
    async getBanners(): Promise<Banner[]> {
        const response = await api.get(API_ENDPOINTS.BANNERS.LIST);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get home page banners
     */
    async getHomeBanners(): Promise<Banner[]> {
        const response = await api.get(API_ENDPOINTS.BANNERS.HOME);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },
};

export default bannerService;
