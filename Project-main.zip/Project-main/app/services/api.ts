/**
 * API Service - Axios instance with auth interceptor
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import { API_BASE_URL } from '@/constants/Api';
import { secureStorage } from '@/utils/storage';

// Token storage key
const TOKEN_KEY = 'leq_auth_token';

// Create axios instance
const api: AxiosInstance = axios.create({
    baseURL: API_BASE_URL,
    timeout: 30000,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor - add auth token
api.interceptors.request.use(
    async (config) => {
        try {
            const token = await secureStorage.getItem(TOKEN_KEY);
            if (token) {
                config.headers.Authorization = `Token ${token}`;
            }
        } catch (error) {
            console.error('Error getting token:', error);
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor - handle errors
api.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
        if (error.response?.status === 401) {
            // Token expired or invalid - clear token
            await secureStorage.removeItem(TOKEN_KEY);
        }
        return Promise.reject(error);
    }
);

// Token management functions
export const setAuthToken = async (token: string): Promise<void> => {
    await secureStorage.setItem(TOKEN_KEY, token);
};

export const getAuthToken = async (): Promise<string | null> => {
    return await secureStorage.getItem(TOKEN_KEY);
};

export const removeAuthToken = async (): Promise<void> => {
    await secureStorage.removeItem(TOKEN_KEY);
};

export default api;
