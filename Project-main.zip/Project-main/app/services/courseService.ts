/**
 * Course Service - Course and Category API calls
 */

import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';
import { Course, CourseDetail, Category } from '@/types';

interface CoursesFilter {
    category?: number;
    level?: string;
    is_free?: boolean;
    is_featured?: boolean;
    search?: string;
    ordering?: string;
}

export const courseService = {
    /**
     * Get all categories
     */
    async getCategories(): Promise<Category[]> {
        const response = await api.get(API_ENDPOINTS.CATEGORIES);
        // Handle both paginated and non-paginated responses
        const data = response.data;
        if (Array.isArray(data)) {
            return data;
        } else if (data && Array.isArray(data.results)) {
            return data.results;
        }
        return [];
    },

    /**
     * Get courses list with optional filters
     */
    async getCourses(filters?: CoursesFilter): Promise<Course[]> {
        const params = new URLSearchParams();
        if (filters) {
            if (filters.category) params.append('category', String(filters.category));
            if (filters.level) params.append('level', filters.level);
            if (filters.is_free !== undefined) params.append('is_free', String(filters.is_free));
            if (filters.is_featured !== undefined) params.append('is_featured', String(filters.is_featured));
            if (filters.search) params.append('search', filters.search);
            if (filters.ordering) params.append('ordering', filters.ordering);
        }
        const query = params.toString();
        const url = query ? `${API_ENDPOINTS.COURSES.LIST}?${query}` : API_ENDPOINTS.COURSES.LIST;
        const response = await api.get(url);
        // Handle both paginated and non-paginated responses
        const data = response.data;
        if (Array.isArray(data)) {
            return data;
        } else if (data && Array.isArray(data.results)) {
            return data.results;
        }
        return [];
    },

    /**
     * Get course detail by ID
     */
    async getCourseDetail(id: number | string): Promise<CourseDetail> {
        const response = await api.get<CourseDetail>(API_ENDPOINTS.COURSES.DETAIL(id));
        return response.data;
    },

    /**
     * Get featured courses
     */
    async getFeaturedCourses(): Promise<Course[]> {
        const response = await api.get(API_ENDPOINTS.COURSES.FEATURED);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get trending courses
     */
    async getTrendingCourses(): Promise<Course[]> {
        const response = await api.get(API_ENDPOINTS.COURSES.TRENDING);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get top-rated courses
     */
    async getTopRatedCourses(): Promise<Course[]> {
        const response = await api.get(API_ENDPOINTS.COURSES.TOP_RATED);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Enroll in a course
     */
    async enrollCourse(id: number | string): Promise<{ id: number; course: Course }> {
        const response = await api.post(API_ENDPOINTS.COURSES.ENROLL(id));
        return response.data;
    },

    /**
     * Search courses
     */
    async searchCourses(query: string): Promise<Course[]> {
        const response = await api.get(`${API_ENDPOINTS.SEARCH}?q=${encodeURIComponent(query)}`);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },
};

export default courseService;
