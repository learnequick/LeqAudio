/**
 * Notification Service - Notification API calls
 */

import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';
import { Notification } from '@/types';

export const notificationService = {
    /**
     * Get all notifications
     */
    async getNotifications(): Promise<Notification[]> {
        const response = await api.get(API_ENDPOINTS.NOTIFICATIONS.LIST);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get unread notifications
     */
    async getUnreadNotifications(): Promise<Notification[]> {
        const response = await api.get(API_ENDPOINTS.NOTIFICATIONS.UNREAD);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Mark notification as read
     */
    async markAsRead(id: number | string): Promise<Notification> {
        const response = await api.post<Notification>(API_ENDPOINTS.NOTIFICATIONS.MARK_READ(id));
        return response.data;
    },

    /**
     * Mark all notifications as read
     */
    async markAllAsRead(): Promise<{ message: string }> {
        const response = await api.post(API_ENDPOINTS.NOTIFICATIONS.MARK_ALL_READ);
        return response.data;
    },

    /**
     * Get unread count
     */
    async getUnreadCount(): Promise<number> {
        const notifications = await this.getUnreadNotifications();
        return notifications.length;
    },
};

export default notificationService;
