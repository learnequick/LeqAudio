/**
 * Enrollment Service - User enrollments API calls
 */

import api from './api';
import { API_ENDPOINTS } from '@/constants/Api';
import { Enrollment } from '@/types';

export const enrollmentService = {
    /**
     * Get all user enrollments
     */
    async getEnrollments(): Promise<Enrollment[]> {
        const response = await api.get(API_ENDPOINTS.ENROLLMENTS.LIST);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get active enrollments
     */
    async getActiveEnrollments(): Promise<Enrollment[]> {
        const response = await api.get(API_ENDPOINTS.ENROLLMENTS.ACTIVE);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get completed enrollments
     */
    async getCompletedEnrollments(): Promise<Enrollment[]> {
        const response = await api.get(API_ENDPOINTS.ENROLLMENTS.COMPLETED);
        const data = response.data;
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.results)) return data.results;
        return [];
    },

    /**
     * Get enrollment detail
     */
    async getEnrollmentDetail(id: number | string): Promise<Enrollment> {
        const response = await api.get<Enrollment>(API_ENDPOINTS.ENROLLMENTS.DETAIL(id));
        return response.data;
    },
};

export default enrollmentService;
