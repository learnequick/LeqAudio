import { Platform } from 'react-native';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import api from './api';

// Import type only to avoid side effects in Expo Go
import type * as NotificationsType from 'expo-notifications';

// Check if running in Expo Go
const isExpoGo = Constants.executionEnvironment === 'storeClient';

export const requestPushPermissions = async (): Promise<string | undefined> => {
    // if (isExpoGo) {
    //     console.log("Push notifications are not supported in Expo Go");
    //     return;
    // }

    const Notifications: typeof NotificationsType = require('expo-notifications');

    if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }

    // if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
    }
    if (finalStatus !== 'granted') {
        console.log('Failed to get push token for push notification!');
        return;
    }

    // Get the token
    const projectId = Constants?.expoConfig?.extra?.eas?.projectId ?? Constants?.easConfig?.projectId;
    try {
        const tokenOptions = projectId ? { projectId } : undefined;
        const tokenData = await Notifications.getExpoPushTokenAsync(tokenOptions);
        return tokenData.data;
    } catch (e) {
        console.error("Error getting push token:", e);
        return undefined;
    }
    // } else {
    // console.log('Must use physical device for Push Notifications');
    // }
};

export const registerDeviceToken = async (token: string) => {
    try {
        await api.post('/notifications/register-device/', {
            token: token,
            platform: Platform.OS,
        });
        console.log('Device token registered:', token);
    } catch (error) {
        console.error('Failed to register device token:', error);
    }
};

export const setupPushNotifications = async (router?: any) => {
    // if (isExpoGo) return;

    try {
        const Notifications: typeof NotificationsType = require('expo-notifications');

        Notifications.setNotificationHandler({
            handleNotification: async () => ({
                shouldShowAlert: true,
                shouldPlaySound: true,
                shouldSetBadge: false,
                shouldShowBanner: true,
                shouldShowList: true,
            }),
        });

        const token = await requestPushPermissions();
        if (token) {
            await registerDeviceToken(token);
        }

        if (router) {
            const subscription = Notifications.addNotificationResponseReceivedListener(response => {
                const url = response.notification.request.content.data.url;
                if (url) {
                    router.push(url);
                }
            });
            return subscription;
        }
    } catch (error) {
        console.error("Error setting up push notifications:", error);
    }
};
