/**
 * Auth Service - Authentication API calls
 */

import api, { setAuthToken, removeAuthToken } from './api';
import { API_ENDPOINTS } from '@/constants/Api';
import { AuthResponse, User } from '@/types';

interface LoginParams {
    email: string;
    password: string;
}

interface RegisterParams {
    email: string;
    first_name: string;
    last_name: string;
    phone: string;
    password: string;
    password_confirm: string;
}

interface ForgotPasswordParams {
    email: string;
}

interface VerifyOTPParams {
    email: string;
    otp: string;
}

interface ResetPasswordParams {
    user_id: number;
    reset_token: string;
    new_password: string;
}

export const authService = {
    /**
     * Login user with email and password
     */
    async login(params: LoginParams): Promise<AuthResponse> {
        const response = await api.post<AuthResponse>(API_ENDPOINTS.AUTH.LOGIN, params);
        await setAuthToken(response.data.token);
        return response.data;
    },

    /**
     * Register new user - returns user_id and email for OTP verification
     */
    async register(params: RegisterParams): Promise<{ message: string; user_id: number; email: string; requires_verification: boolean }> {
        const response = await api.post<{ message: string; user_id: number; email: string; requires_verification: boolean }>(
            API_ENDPOINTS.AUTH.REGISTER,
            params
        );
        return response.data;
    },

    /**
     * Verify signup OTP and complete registration
     */
    async verifySignupOTP(user_id: number, otp: string): Promise<AuthResponse> {
        const response = await api.post<AuthResponse>(API_ENDPOINTS.AUTH.VERIFY_SIGNUP_OTP, {
            user_id,
            otp
        });
        await setAuthToken(response.data.token);
        return response.data;
    },

    /**
     * Resend signup verification OTP
     */
    async resendSignupOTP(user_id: number, email: string): Promise<{ message: string }> {
        const response = await api.post<{ message: string }>(API_ENDPOINTS.AUTH.RESEND_SIGNUP_OTP, {
            user_id,
            email
        });
        return response.data;
    },

    /**
     * Logout current user
     */
    async logout(): Promise<void> {
        try {
            await api.post(API_ENDPOINTS.AUTH.LOGOUT);
        } catch (error) {
            // Ignore logout errors, still clear token
        }
        await removeAuthToken();
    },

    /**
     * Get current user profile
     */
    async getProfile(): Promise<User> {
        const response = await api.get<User>(API_ENDPOINTS.USER.PROFILE);
        return response.data;
    },

    /**
     * Update user profile
     */
    async updateProfile(data: Partial<User>, imageUri?: string): Promise<User> {
        if (imageUri) {
            const formData = new FormData();

            // Append text fields
            if (data.first_name) formData.append('first_name', data.first_name);
            if (data.last_name) formData.append('last_name', data.last_name);
            if (data.phone) formData.append('phone', data.phone);

            // Append image
            const filename = imageUri.split('/').pop() || 'profile.jpg';
            const match = /\.(\w+)$/.exec(filename);
            const type = match ? `image/${match[1]}` : 'image/jpeg';

            // @ts-ignore
            formData.append('profile_picture', { uri: imageUri, name: filename, type });

            const response = await api.patch<User>(API_ENDPOINTS.USER.PROFILE, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            return response.data;
        } else {
            const response = await api.patch<User>(API_ENDPOINTS.USER.PROFILE, data);
            return response.data;
        }
    },

    /**
     * Send forgot password OTP
     */
    async forgotPassword(params: ForgotPasswordParams): Promise<{ message: string; email: string }> {
        const response = await api.post(API_ENDPOINTS.AUTH.FORGOT_PASSWORD, params);
        return response.data;
    },

    /**
     * Verify reset OTP
     */
    async verifyResetOTP(params: VerifyOTPParams): Promise<{ reset_token: string; user_id: number }> {
        const response = await api.post(API_ENDPOINTS.AUTH.VERIFY_RESET_OTP, params);
        return response.data;
    },

    /**
     * Reset password with verified token
     */
    async resetPassword(params: ResetPasswordParams): Promise<{ message: string }> {
        const response = await api.post(API_ENDPOINTS.AUTH.RESET_PASSWORD, params);
        return response.data;
    },

    /**
     * Change password
     */
    async changePassword(old_password: string, new_password: string): Promise<{ message: string }> {
        const response = await api.post(API_ENDPOINTS.AUTH.CHANGE_PASSWORD, {
            old_password,
            new_password,
        });
        return response.data;
    },
};

export default authService;
