/**
 * Responsive Utilities
 * Handles responsive sizing, spacing, and typography across all device sizes
 * 
 * This file provides both:
 * 1. Static utilities for use outside of React components
 * 2. Re-exports from the new useResponsive hook for use inside components
 */

import { Dimensions, Platform, PixelRatio } from 'react-native';

// Re-export everything from the new hook for convenience
export {
    useResponsive,
    BREAKPOINTS,
} from '@/hooks/useResponsive';

export type {
    Breakpoint,
    ResponsiveValue,
    UseResponsiveReturn,
    SpacingScale,
    TypographyScale,
    IconScale,
    GridConfig,
    AccessibilityConfig,
    LayoutInfo,
} from '@/hooks/useResponsive';

// Get device dimensions (static - use hook for dynamic)
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// Base dimensions (iPhone 14 Pro as reference)
const BASE_WIDTH = 393;
const BASE_HEIGHT = 852;

// Device size categories
export enum DeviceSize {
    SMALL = 'small',   // < 375px width (iPhone SE, small Android)
    MEDIUM = 'medium', // 375-414px (iPhone 12, 13, most Android)
    LARGE = 'large',   // > 414px (iPhone Pro Max, large Android)
    TABLET = 'tablet', // > 600px (iPads, Android tablets)
}

// Aspect ratio categories
export enum AspectRatioCategory {
    NARROW = 'narrow',   // < 1.8 (older devices)
    STANDARD = 'standard', // 1.8 - 2.1 (most modern phones)
    TALL = 'tall',       // > 2.1 (very tall devices)
}

/**
 * Get current device size category (static)
 */
export const getDeviceSize = (): DeviceSize => {
    if (SCREEN_WIDTH >= 600) return DeviceSize.TABLET;
    if (SCREEN_WIDTH >= 414) return DeviceSize.LARGE;
    if (SCREEN_WIDTH >= 375) return DeviceSize.MEDIUM;
    return DeviceSize.SMALL;
};

/**
 * Get aspect ratio category (static)
 */
export const getAspectRatioCategory = (): AspectRatioCategory => {
    const aspectRatio = SCREEN_HEIGHT / SCREEN_WIDTH;
    if (aspectRatio > 2.1) return AspectRatioCategory.TALL;
    if (aspectRatio >= 1.8) return AspectRatioCategory.STANDARD;
    return AspectRatioCategory.NARROW;
};

/**
 * Check if device has notch/punch-hole (static heuristic)
 */
export const hasNotch = (): boolean => {
    const aspectRatio = SCREEN_HEIGHT / SCREEN_WIDTH;

    if (Platform.OS === 'ios') {
        return aspectRatio > 2.0;
    }

    if (Platform.OS === 'android') {
        return aspectRatio > 1.95;
    }

    return false;
};

/**
 * Scale size based on screen width (static)
 */
export const scaleWidth = (size: number): number => {
    return (SCREEN_WIDTH / BASE_WIDTH) * size;
};

/**
 * Scale size based on screen height (static)
 */
export const scaleHeight = (size: number): number => {
    return (SCREEN_HEIGHT / BASE_HEIGHT) * size;
};

/**
 * Moderate scale - scales less aggressively (static)
 */
export const moderateScale = (size: number, factor: number = 0.5): number => {
    return size + (scaleWidth(size) - size) * factor;
};

/**
 * Scale font size based on device (static)
 */
export const scaleFontSize = (size: number): number => {
    const deviceSize = getDeviceSize();

    switch (deviceSize) {
        case DeviceSize.SMALL:
            return moderateScale(size, 0.3);
        case DeviceSize.MEDIUM:
            return moderateScale(size, 0.4);
        case DeviceSize.LARGE:
            return moderateScale(size, 0.5);
        case DeviceSize.TABLET:
            return moderateScale(size, 0.7);
        default:
            return size;
    }
};

/**
 * Get responsive spacing (static)
 */
export const getSpacing = (baseSpacing: number): number => {
    const deviceSize = getDeviceSize();

    switch (deviceSize) {
        case DeviceSize.SMALL:
            return Math.max(baseSpacing * 0.85, 4);
        case DeviceSize.MEDIUM:
            return baseSpacing;
        case DeviceSize.LARGE:
            return baseSpacing * 1.1;
        case DeviceSize.TABLET:
            return baseSpacing * 1.3;
        default:
            return baseSpacing;
    }
};

/**
 * Get safe area padding for top (static)
 */
export const getSafeTopPadding = (basePadding: number = 0): number => {
    if (Platform.OS === 'ios') {
        return hasNotch() ? 44 + basePadding : 20 + basePadding;
    }
    if (Platform.OS === 'android') {
        return hasNotch() ? 40 + basePadding : 24 + basePadding;
    }
    return basePadding;
};

/**
 * Get safe area padding for bottom (static)
 */
export const getSafeBottomPadding = (basePadding: number = 0): number => {
    if (Platform.OS === 'ios') {
        return hasNotch() ? 34 + basePadding : 0 + basePadding;
    }
    if (Platform.OS === 'android') {
        return hasNotch() ? 24 + basePadding : 0 + basePadding;
    }
    return basePadding;
};

/**
 * Get minimum touch target size (48dp Android, 44pt iOS)
 */
export const getMinTouchTarget = (): number => {
    return Platform.OS === 'ios' ? 44 : 48;
};

/**
 * Get responsive border radius (static)
 */
export const getResponsiveBorderRadius = (baseRadius: number): number => {
    return moderateScale(baseRadius, 0.3);
};

/**
 * Get responsive icon size (static)
 */
export const getResponsiveIconSize = (baseSize: number): number => {
    const deviceSize = getDeviceSize();

    switch (deviceSize) {
        case DeviceSize.SMALL:
            return Math.max(baseSize * 0.9, 16);
        case DeviceSize.MEDIUM:
            return baseSize;
        case DeviceSize.LARGE:
            return baseSize * 1.1;
        case DeviceSize.TABLET:
            return baseSize * 1.3;
        default:
            return baseSize;
    }
};

/**
 * Check if device is in landscape mode (static)
 */
export const isLandscape = (): boolean => {
    return SCREEN_WIDTH > SCREEN_HEIGHT;
};

/**
 * Get pixel ratio (static)
 */
export const getPixelRatio = (): number => {
    return PixelRatio.get();
};

/**
 * Check if device is high density (retina) (static)
 */
export const isHighDensity = (): boolean => {
    return PixelRatio.get() >= 2;
};

/**
 * Responsive dimensions object (static - prefer hook for dynamic values)
 */
export const responsiveDimensions = {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    isSmallDevice: getDeviceSize() === DeviceSize.SMALL,
    isMediumDevice: getDeviceSize() === DeviceSize.MEDIUM,
    isLargeDevice: getDeviceSize() === DeviceSize.LARGE,
    isTablet: getDeviceSize() === DeviceSize.TABLET,
    hasNotch: hasNotch(),
    isLandscape: isLandscape(),
    aspectRatio: SCREEN_HEIGHT / SCREEN_WIDTH,
    aspectRatioCategory: getAspectRatioCategory(),
};

/**
 * Responsive typography scale (static)
 */
export const typography = {
    h1: scaleFontSize(32),
    h2: scaleFontSize(28),
    h3: scaleFontSize(24),
    h4: scaleFontSize(20),
    h5: scaleFontSize(18),
    h6: scaleFontSize(16),
    body: scaleFontSize(15),
    bodySmall: scaleFontSize(13),
    caption: scaleFontSize(12),
    tiny: scaleFontSize(10),
};

/**
 * Responsive spacing scale (static)
 */
export const spacing = {
    xs: getSpacing(4),
    sm: getSpacing(8),
    md: getSpacing(12),
    lg: getSpacing(16),
    xl: getSpacing(20),
    xxl: getSpacing(24),
    xxxl: getSpacing(32),
};

/**
 * Responsive icon sizes (static)
 */
export const iconSizes = {
    tiny: getResponsiveIconSize(12),
    small: getResponsiveIconSize(16),
    medium: getResponsiveIconSize(20),
    large: getResponsiveIconSize(28),
    xlarge: getResponsiveIconSize(32),
    xxlarge: getResponsiveIconSize(48),
};

/**
 * Responsive border radius (static)
 */
export const borderRadius = {
    xs: getResponsiveBorderRadius(4),
    sm: getResponsiveBorderRadius(8),
    md: getResponsiveBorderRadius(12),
    lg: getResponsiveBorderRadius(16),
    xl: getResponsiveBorderRadius(20),
    full: 9999,
};

export default {
    scaleWidth,
    scaleHeight,
    moderateScale,
    scaleFontSize,
    getSpacing,
    getSafeTopPadding,
    getSafeBottomPadding,
    getMinTouchTarget,
    getResponsiveBorderRadius,
    getResponsiveIconSize,
    getDeviceSize,
    getAspectRatioCategory,
    hasNotch,
    isLandscape,
    getPixelRatio,
    isHighDensity,
    responsiveDimensions,
    typography,
    spacing,
    borderRadius,
};

/**
 * Hook for responsive values that update on dimension changes
 * @deprecated Use useResponsive() from '@/hooks/useResponsive' instead
 */
import { useWindowDimensions } from 'react-native';

export const useResponsiveLayout = () => {
    const { width, height } = useWindowDimensions();

    const isLandscapeMode = width > height;
    const isTabletMode = width >= 600;
    const isLargeDeviceMode = width >= 414;
    const isSmallDeviceMode = width < 375;

    // Recalculate dynamic values based on current width
    const getResponsiveWidth = (baseWidth: number) => {
        return (width / BASE_WIDTH) * baseWidth;
    };

    // Calculate number of columns based on device type and orientation
    let numColumns: number;
    if (isTabletMode) {
        numColumns = isLandscapeMode ? 4 : 3;
    } else {
        numColumns = isLandscapeMode ? 3 : 2;
    }

    return {
        width,
        height,
        isLandscape: isLandscapeMode,
        isTablet: isTabletMode,
        isLargeDevice: isLargeDeviceMode,
        isSmallDevice: isSmallDeviceMode,
        getResponsiveWidth,
        numColumns,
        containerWidth: isTabletMode ? Math.min(width * 0.8, 800) : '100%' as const,
    };
};
