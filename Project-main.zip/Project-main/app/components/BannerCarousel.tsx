/**
 * Banner Carousel Component
 * Horizontal scrolling banners with auto-play
 * Fully responsive across all device sizes
 */

import React, { useRef, useState, useEffect } from 'react';
import {
    View,
    Text,
    Image,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    NativeSyntheticEvent,
    NativeScrollEvent,
    useWindowDimensions
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { Banner } from '@/types';
import { spacing, typography, borderRadius, responsiveDimensions, useResponsiveLayout } from '@/utils/responsive';

interface BannerCarouselProps {
    banners: Banner[];
    onBannerPress?: (banner: Banner) => void;
    autoPlay?: boolean;
    autoPlayInterval?: number;
}

export function BannerCarousel({
    banners,
    onBannerPress,
    autoPlay = true,
    autoPlayInterval = 5000
}: BannerCarouselProps) {
    const scrollViewRef = useRef<ScrollView>(null);
    const [activeIndex, setActiveIndex] = useState(0);
    const { width } = useWindowDimensions();
    const { isTablet } = useResponsiveLayout();

    // Responsive aspect ratio:
    // Mobile & Tablet: 1920/600 (3.2) - Fixed cinematic wide ratio
    const BANNER_ASPECT_RATIO = 1920 / 600;

    // Layout constants
    const GAP = responsiveDimensions.isSmallDevice ? 16 : 24;
    const PADDING_H = spacing.lg;

    // Constrain banner width
    // On mobile: width - (padding * 2) to show a bit of the next card or full centered
    const availableWidth = width - (PADDING_H * 2);
    const maxBannerWidth = 800;

    const BANNER_WIDTH = width >= 600
        ? Math.min(availableWidth, maxBannerWidth)
        : width - (PADDING_H * 2); // Full width minus padding for mobile

    const BANNER_HEIGHT = BANNER_WIDTH / BANNER_ASPECT_RATIO;

    // Auto-play functionality
    useEffect(() => {
        if (!autoPlay || banners.length <= 1) return;

        const interval = setInterval(() => {
            const nextIndex = (activeIndex + 1) % banners.length;
            scrollViewRef.current?.scrollTo({
                x: nextIndex * (BANNER_WIDTH + GAP),
                animated: true,
            });
            setActiveIndex(nextIndex);
        }, autoPlayInterval);

        return () => clearInterval(interval);
    }, [activeIndex, banners.length, autoPlay, autoPlayInterval, BANNER_WIDTH]);

    const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
        const contentOffset = event.nativeEvent.contentOffset.x;
        const index = Math.round(contentOffset / (BANNER_WIDTH + GAP));
        if (index !== activeIndex && index >= 0 && index < banners.length) {
            setActiveIndex(index);
        }
    };

    if (banners.length === 0) return null;

    return (
        <View style={styles.container}>
            <ScrollView
                ref={scrollViewRef}
                horizontal
                pagingEnabled={false}
                showsHorizontalScrollIndicator={false}
                onScroll={handleScroll}
                scrollEventThrottle={16}
                contentContainerStyle={[
                    styles.scrollContent,
                    {
                        paddingHorizontal: PADDING_H + (width - BANNER_WIDTH - (PADDING_H * 2)) / 2,
                        gap: GAP
                    }
                ]}
                snapToInterval={BANNER_WIDTH + GAP}
                snapToAlignment="center"
                decelerationRate="fast"
                contentInsetAdjustmentBehavior="never"
            >
                {banners.map((banner, index) => (
                    <TouchableOpacity
                        key={banner.id}
                        style={[styles.bannerContainer, { width: BANNER_WIDTH, height: BANNER_HEIGHT }]}
                        onPress={() => onBannerPress?.(banner)}
                        activeOpacity={0.95}
                    >
                        {banner.image_url ? (
                            <Image
                                source={{ uri: banner.image_url }}
                                style={styles.bannerImage}
                                resizeMode="cover"
                            />
                        ) : (
                            <LinearGradient
                                colors={[Colors.dark.primary, Colors.dark.secondary]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 1 }}
                                style={styles.bannerGradient}
                            />
                        )}

                        {/* Overlay gradient */}
                        <LinearGradient
                            colors={['transparent', 'rgba(0,0,0,0.7)']}
                            style={styles.overlay}
                        />

                        {/* Banner content */}
                        <View style={styles.bannerContent}>
                            <Text style={styles.bannerTitle} numberOfLines={2}>
                                {banner.title}
                            </Text>
                            {banner.subtitle && (
                                <Text style={styles.bannerSubtitle} numberOfLines={1}>
                                    {banner.subtitle}
                                </Text>
                            )}
                            {banner.action_text && (
                                <View style={styles.actionButton}>
                                    <Text style={styles.actionText}>{banner.action_text}</Text>
                                </View>
                            )}
                        </View>
                    </TouchableOpacity>
                ))}
            </ScrollView>

            {/* Pagination dots */}
            {banners.length > 1 && (
                <View style={styles.pagination}>
                    {banners.map((_, index) => (
                        <View
                            key={index}
                            style={[
                                styles.dot,
                                index === activeIndex && styles.activeDot,
                            ]}
                        />
                    ))}
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        marginBottom: spacing.lg,
    },
    scrollContent: {
        // Gap handled inline
    },
    bannerContainer: {
        borderRadius: borderRadius.sm,
        overflow: 'hidden',
        backgroundColor: Colors.dark.card,
        // Margin removed to rely on gap
    },
    bannerImage: {
        width: '100%',
        height: '100%',
    },
    bannerGradient: {
        width: '100%',
        height: '100%',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
    },
    bannerContent: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: spacing.lg,
    },
    bannerTitle: {
        fontSize: responsiveDimensions.isSmallDevice ? typography.h5 : typography.h4,
        fontWeight: '700',
        color: '#fff',
        marginBottom: 4,
    },
    bannerSubtitle: {
        fontSize: typography.bodySmall,
        color: 'rgba(255,255,255,0.8)',
        marginBottom: spacing.md,
    },
    actionButton: {
        alignSelf: 'flex-start',
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.sm,
        borderRadius: borderRadius.full,
    },
    actionText: {
        color: '#fff',
        fontSize: typography.caption,
        fontWeight: '600',
    },
    pagination: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: spacing.md,
        gap: 6,
    },
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: Colors.dark.textMuted,
    },
    activeDot: {
        width: responsiveDimensions.isSmallDevice ? 16 : 18,
        backgroundColor: Colors.dark.primary,
    },
});

export default BannerCarousel;
