/**
 * Video Player Component
 * Full-featured video player matching LEQ web app design with YouTube support
 * Fully responsive across all device sizes and orientations
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    StatusBar,
    Platform,
    useWindowDimensions,
} from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import { useRouter, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import YoutubePlayer from 'react-native-youtube-iframe';
import {
    typography,
    spacing,
    iconSizes,
    borderRadius,
    responsiveDimensions,
    getSafeTopPadding,
    getSafeBottomPadding,
    getMinTouchTarget,
} from '@/utils/responsive';

const { width, height } = Dimensions.get('window');

import { lessonService } from '@/services';

interface VideoPlayerProps {
    videoUrl: string;
    title: string;
    subtitle?: string;
    lessonId?: number;
    onBack?: () => void;
}

// Extract YouTube video ID from URL
function extractYouTubeId(url: string): string | null {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
        /^([a-zA-Z0-9_-]{11})$/
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
            return match[1];
        }
    }

    return null;
}

export function VideoPlayer({ videoUrl, title, subtitle, lessonId, onBack }: VideoPlayerProps) {
    const { width, height } = useWindowDimensions();
    const router = useRouter();
    const insets = useSafeAreaInsets();
    const videoRef = useRef<Video>(null);

    // Determine if using YouTube
    const youtubeVideoId = extractYouTubeId(videoUrl);
    const isUsingYouTube = !!youtubeVideoId;

    // YouTube player refs
    const youtubePlayerRef = useRef<any>(null);
    const youtubeWebViewRef = useRef<any>(null);
    const durationFetchedRef = useRef<boolean>(false);
    const youtubePlayingRef = useRef<boolean>(false);

    const [status, setStatus] = useState<AVPlaybackStatus | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const [position, setPosition] = useState(0);
    const [duration, setDuration] = useState(0);
    const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [showSpeedMenu, setShowSpeedMenu] = useState(false);
    const [youtubeReady, setYoutubeReady] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // Progress tracking refs
    const lastProgressUpdate = useRef<number>(0);
    const progressUpdateInterval = useRef<NodeJS.Timeout | null>(null);

    const controlsTimeout = useRef<any>(null);

    useEffect(() => {
        // Set loading to false for YouTube immediately
        if (isUsingYouTube) {
            // YouTube will set loading to false in onYouTubeReady
        } else {
            setIsLoading(false);
        }

        return () => {
            if (controlsTimeout.current) {
                clearTimeout(controlsTimeout.current);
            }
            if (progressUpdateInterval.current) {
                clearInterval(progressUpdateInterval.current);
            }
            // Cleanup video on unmount
            if (!isUsingYouTube && videoRef.current) {
                videoRef.current.stopAsync().catch(() => { });
                videoRef.current.unloadAsync().catch(() => { });
            }
            // Cleanup for YouTube - pause when component unmounts
            if (isUsingYouTube && youtubePlayerRef.current) {
                youtubePlayerRef.current.pauseVideo?.().catch(() => { });
            }
        };
    }, [isUsingYouTube]);

    // Stop video when navigating away from this screen
    useFocusEffect(
        useCallback(() => {
            // Screen is focused - video can play
            return () => {
                // Screen is unfocused (user navigated away) - pause video and update progress
                if (isUsingYouTube) {
                    setIsPlaying(false);
                    youtubePlayingRef.current = false;

                    if (youtubePlayerRef.current) {
                        Promise.all([
                            youtubePlayerRef.current.getCurrentTime(),
                            youtubePlayerRef.current.getDuration()
                        ]).then(([currentTime, totalDuration]) => {
                            if (currentTime && totalDuration && lessonId) {
                                const progress = (currentTime / totalDuration) * 100;
                                lessonService.updateProgress(lessonId, progress).catch(() => { });
                            }
                        }).catch(() => { });
                    }
                } else if (videoRef.current) {
                    videoRef.current.getStatusAsync().then(status => {
                        if (status.isLoaded && status.durationMillis && lessonId) {
                            const progress = (status.positionMillis / status.durationMillis) * 100;
                            lessonService.updateProgress(lessonId, progress).catch(() => { });
                        }
                    });
                    videoRef.current.pauseAsync().catch(() => { });
                }
            };
        }, [isUsingYouTube, lessonId])
    );

    useEffect(() => {
        if (showControls && isPlaying) {
            resetControlsTimeout();
        }
    }, [showControls, isPlaying]);

    const resetControlsTimeout = () => {
        if (controlsTimeout.current) {
            clearTimeout(controlsTimeout.current);
        }
        controlsTimeout.current = setTimeout(() => {
            setShowControls(false);
        }, 3000);
    };

    const updateProgress = async (currentPosition: number, totalDuration: number) => {
        if (!lessonId || !totalDuration || totalDuration === 0) return;
        const progress = (currentPosition / totalDuration) * 100;

        try {
            await lessonService.updateProgress(lessonId, progress);
            lastProgressUpdate.current = progress;
        } catch (error) {

        }
    };

    // YouTube handlers
    const onYouTubeReady = useCallback(async () => {

        setYoutubeReady(true);
        setIsLoading(false);

        // Auto-play YouTube video after ready
        youtubePlayingRef.current = true;
        setIsPlaying(true);

        // Fetch initial duration when player is ready
        if (youtubePlayerRef.current) {
            try {
                await new Promise(resolve => setTimeout(resolve, 100));
                await youtubePlayerRef.current.seekTo(0, true);

            } catch (error) {
                // Silent fail
            }

            const fetchDuration = async (retries = 3) => {
                for (let i = 0; i < retries; i++) {
                    try {
                        await new Promise(resolve => setTimeout(resolve, i * 300));
                        const totalDuration = await youtubePlayerRef.current.getDuration();
                        if (totalDuration && totalDuration > 0) {
                            setDuration(totalDuration * 1000);
                            durationFetchedRef.current = true;
                            return;
                        }
                    } catch (error) {
                        // Silent fail
                    }
                }
            };
            fetchDuration();
        }
    }, []);

    const onYouTubeStateChange = useCallback((state: string) => {

        if (state === 'playing') {
            if (!youtubePlayingRef.current) {
                youtubePlayingRef.current = true;
                setIsPlaying(true);
            }
        } else if (state === 'paused') {
            if (youtubePlayingRef.current) {
                youtubePlayingRef.current = false;
                setIsPlaying(false);
            }
        } else if (state === 'ended') {
            youtubePlayingRef.current = false;
            setIsPlaying(false);
        }
    }, []);

    const onYouTubeProgress = useCallback((data: { currentTime: number; duration: number }) => {
        const newPosition = data.currentTime * 1000;
        const newDuration = data.duration * 1000;

        setPosition(newPosition);
        if (newDuration > 0 && !durationFetchedRef.current) {
            setDuration(newDuration);
            durationFetchedRef.current = true;
        }
    }, []);

    // Polling for YouTube progress - Removed to prevent lag on redundant updates
    // onProgress callback works sufficiently well now

    const onPlaybackStatusUpdate = (playbackStatus: AVPlaybackStatus) => {
        setStatus(playbackStatus);
        if (playbackStatus.isLoaded) {
            setPosition(playbackStatus.positionMillis);
            setDuration(playbackStatus.durationMillis || 0);
            setIsPlaying(playbackStatus.isPlaying);

            if (playbackStatus.didJustFinish) {
                setIsPlaying(false);
                videoRef.current?.setPositionAsync(0);
                if (lessonId) {
                    lessonService.updateProgress(lessonId, 100);
                    lastProgressUpdate.current = 100;
                }
                setShowControls(true);
            }
        }
    };

    const togglePlayPause = async () => {
        if (isUsingYouTube) {
            if (!youtubeReady) {
                return;
            }

            const newPlayingState = !isPlaying;
            youtubePlayingRef.current = newPlayingState;
            setIsPlaying(newPlayingState);
        } else {
            if (!videoRef.current) return;

            if (isPlaying) {
                await videoRef.current.pauseAsync();
                if (duration > 0) {
                    updateProgress(position, duration);
                }
            } else {
                await videoRef.current.playAsync();
            }
        }
        setShowControls(true);
        resetControlsTimeout();
    };

    const skipForward = async () => {
        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                const currentTime = await youtubePlayerRef.current.getCurrentTime();
                const newTime = Math.min((currentTime || 0) + 10, duration / 1000);
                await youtubePlayerRef.current.seekTo(newTime, true);
            } catch (error) {
                // Silent fail
            }
        } else {
            if (!videoRef.current) return;
            const newPosition = Math.min(position + 10000, duration);
            await videoRef.current.setPositionAsync(newPosition);
        }
        setShowControls(true);
        resetControlsTimeout();
    };

    const skipBackward = async () => {
        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                const currentTime = await youtubePlayerRef.current.getCurrentTime();
                const newTime = Math.max((currentTime || 0) - 10, 0);
                await youtubePlayerRef.current.seekTo(newTime, true);
            } catch (error) {
                // Silent fail
            }
        } else {
            if (!videoRef.current) return;
            const newPosition = Math.max(position - 10000, 0);
            await videoRef.current.setPositionAsync(newPosition);
        }
        setShowControls(true);
        resetControlsTimeout();
    };

    const changeSpeed = async (speed: number) => {
        setPlaybackSpeed(speed);

        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                await youtubePlayerRef.current.setPlaybackRate(speed);
            } catch (error) {
                // Silent fail
            }
        } else {
            if (!videoRef.current) return;
            await videoRef.current.setRateAsync(speed, true);
        }
        setShowControls(true);
        resetControlsTimeout();
    };

    const handleProgressPress = async (event: any) => {
        const { locationX } = event.nativeEvent;
        const progressBarWidth = width - 64;

        if (typeof locationX !== 'number' || !duration) return;

        const percentage = locationX / progressBarWidth;
        const newPosition = Math.max(0, Math.min(duration, percentage * duration));

        if (isUsingYouTube) {
            youtubePlayerRef.current?.seekTo(newPosition / 1000, true);
        } else {
            if (!videoRef.current || !Number.isFinite(newPosition)) return;
            await videoRef.current.setPositionAsync(newPosition);
        }
    };

    const formatTime = (millis: number) => {
        const totalSeconds = Math.floor(millis / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    };

    const handleBack = async () => {
        // Update progress before leaving
        if (lessonId && duration > 0) {
            try {
                // Force update on exit
                const progress = (position / duration) * 100;
                await lessonService.updateProgress(lessonId, progress);
            } catch (e) { }
        }

        // Stop video before navigating back
        if (videoRef.current) {
            await videoRef.current.stopAsync().catch(() => { });
            await videoRef.current.unloadAsync().catch(() => { });
        }

        if (onBack) {
            onBack();
        } else {
            router.back();
        }
    };

    const toggleControls = () => {
        setShowControls(!showControls);
        if (!showControls && isPlaying) {
            resetControlsTimeout();
        }
    };

    // Calculate optimal 16:9 dimensions for "Contain" mode
    const aspectRatio = 16 / 9;
    let videoWidth = width;
    let videoHeight = height;

    if (width / height > aspectRatio) {
        // Limited by height (screen is wider than video)
        videoHeight = height;
        videoWidth = height * aspectRatio;
    } else {
        // Limited by width (screen is taller than video)
        videoWidth = width;
        videoHeight = width / aspectRatio;
    }

    // Memoize player params to prevent re-renders
    const initialPlayerParams = useMemo(() => ({
        preventFullScreen: true,
        controls: false,
        modestbranding: true,
        rel: false,
        iv_load_policy: 3,
        fs: 0,
        disablekb: 1,
        showinfo: 0,
        start: 0,
    }), []);

    const webViewProps = useMemo(() => ({
        ref: youtubeWebViewRef,
        androidLayerType: 'hardware' as const,
        renderToHardwareTextureAndroid: true,
    }), []);

    // Memoize container style
    const youtubeContainerStyle = useMemo(() => ({
        width: videoWidth,
        height: videoHeight,
        backgroundColor: 'black',
        transform: [{ scale: 1.15 }]  // Scale up to hide "Paid Promotion" text
    }), [videoWidth, videoHeight]);

    return (
        <View style={styles.container}>
            <StatusBar hidden />

            {/* Video Container - Conditional for YouTube or Standard Video */}
            <TouchableOpacity
                style={[styles.videoContainer, { overflow: 'hidden' }]}
                activeOpacity={1}
                onPress={toggleControls}
            >
                {isUsingYouTube ? (
                    <View
                        style={youtubeContainerStyle}
                        pointerEvents="none"
                    >
                        <YoutubePlayer
                            ref={youtubePlayerRef}
                            height={videoHeight}
                            width={videoWidth}
                            videoId={youtubeVideoId!}
                            play={isPlaying}
                            onReady={onYouTubeReady}
                            onChangeState={onYouTubeStateChange}
                            onProgress={onYouTubeProgress}
                            volume={100}
                            playbackRate={playbackSpeed}
                            initialPlayerParams={initialPlayerParams}
                            webViewProps={webViewProps}
                        />
                    </View>
                ) : (
                    <Video
                        ref={videoRef}
                        source={{ uri: videoUrl }}
                        style={styles.video}
                        resizeMode={ResizeMode.CONTAIN}
                        shouldPlay={false}
                        onPlaybackStatusUpdate={onPlaybackStatusUpdate}
                        useNativeControls={false}
                    />
                )}
            </TouchableOpacity>

            {/* Controls Overlay */}
            {showControls && (
                <View style={styles.controlsOverlay}>
                    {/* Top Bar */}
                    <View style={styles.topBar}>
                        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
                            <Ionicons name="arrow-back" size={24} color="white" />
                        </TouchableOpacity>
                        <View style={styles.titleContainer}>
                            <Text style={styles.videoTitle} numberOfLines={1}>
                                {title}
                            </Text>
                            {subtitle && (
                                <Text style={styles.videoSubtitle} numberOfLines={1}>
                                    {subtitle}
                                </Text>
                            )}
                        </View>
                        <TouchableOpacity
                            style={styles.menuButton}
                            onPress={() => setShowSpeedMenu(!showSpeedMenu)}
                        >
                            <Ionicons name="ellipsis-vertical" size={24} color="white" />
                        </TouchableOpacity>
                    </View>

                    {/* Center Play Button */}
                    <View style={styles.centerControls}>
                        <TouchableOpacity
                            style={styles.centerPlayButton}
                            onPress={togglePlayPause}
                        >
                            {isLoading ? (
                                <Ionicons name="hourglass" size={60} color="white" />
                            ) : (
                                <Ionicons
                                    name={isPlaying ? 'pause' : 'play'}
                                    size={60}
                                    color="white"
                                />
                            )}
                        </TouchableOpacity>
                    </View>

                    {/* Bottom Controls */}
                    <View style={styles.bottomControls}>
                        {/* Progress Bar */}
                        <View style={styles.progressContainer}>
                            <Text style={styles.timeText}>{formatTime(position)}</Text>
                            <TouchableOpacity
                                style={styles.progressBar}
                                onPress={handleProgressPress}
                                activeOpacity={1}
                            >
                                <View style={styles.progressTrack}>
                                    <View
                                        style={[
                                            styles.progressFill,
                                            {
                                                width: duration
                                                    ? `${(position / duration) * 100}%`
                                                    : '0%',
                                            },
                                        ]}
                                    />
                                </View>
                            </TouchableOpacity>
                            <Text style={styles.timeText}>{formatTime(duration)}</Text>
                        </View>

                        {/* Playback Controls */}
                        <View style={styles.playbackControls}>
                            <TouchableOpacity
                                style={styles.controlButton}
                                onPress={skipBackward}
                            >
                                <Ionicons name="play-back" size={28} color="white" />
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.playButton}
                                onPress={togglePlayPause}
                            >
                                <Ionicons
                                    name={isPlaying ? 'pause' : 'play'}
                                    size={32}
                                    color="white"
                                />
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.controlButton}
                                onPress={skipForward}
                            >
                                <Ionicons name="play-forward" size={28} color="white" />
                            </TouchableOpacity>

                            {/* Speed Control Removed from here */}
                        </View>
                    </View>
                </View>
            )}
            {/* Speed Menu Overlay */}
            {showSpeedMenu && (
                <TouchableOpacity
                    style={styles.menuOverlay}
                    activeOpacity={1}
                    onPress={() => setShowSpeedMenu(false)}
                >
                    <View style={[
                        styles.speedMenu,
                        { top: insets.top + (responsiveDimensions.hasNotch ? 50 : 30) }
                    ]}>
                        <Text style={styles.menuHeader}>Playback Speed</Text>
                        {[0.5, 1.0, 1.5, 2.0].map((speed) => (
                            <TouchableOpacity
                                key={speed}
                                style={[
                                    styles.menuItem,
                                    playbackSpeed === speed && styles.menuItemActive,
                                ]}
                                onPress={() => {
                                    changeSpeed(speed);
                                    setShowSpeedMenu(false);
                                }}
                            >
                                <Text
                                    style={[
                                        styles.menuItemText,
                                        playbackSpeed === speed && styles.menuItemTextActive,
                                    ]}
                                >
                                    {speed}x
                                </Text>
                                {playbackSpeed === speed && (
                                    <Ionicons name="checkmark" size={16} color="white" />
                                )}
                            </TouchableOpacity>
                        ))}
                    </View>
                </TouchableOpacity>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#000',
    },
    videoContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    video: {
        width: '100%',
        height: '100%',
    },
    controlsOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.4)',
        justifyContent: 'space-between',
    },
    topBar: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: responsiveDimensions.hasNotch
            ? (Platform.OS === 'ios' ? 50 : 40)
            : (Platform.OS === 'ios' ? 20 : 16),
        paddingHorizontal: spacing.lg,
        paddingBottom: spacing.sm,
    },
    backButton: {
        width: getMinTouchTarget(),
        height: getMinTouchTarget(),
        borderRadius: getMinTouchTarget() / 2,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    titleContainer: {
        flex: 1,
        marginHorizontal: spacing.md,
    },
    videoTitle: {
        fontSize: typography.body,
        fontWeight: '700',
        color: 'white',
    },
    videoSubtitle: {
        fontSize: typography.bodySmall,
        color: 'rgba(255, 255, 255, 0.8)',
        marginTop: 2,
    },
    menuButton: {
        width: getMinTouchTarget(),
        height: getMinTouchTarget(),
        justifyContent: 'center',
        alignItems: 'center',
    },
    centerControls: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    centerPlayButton: {
        width: responsiveDimensions.isSmallDevice ? 70 : 80,
        height: responsiveDimensions.isSmallDevice ? 70 : 80,
        borderRadius: responsiveDimensions.isSmallDevice ? 35 : 40,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
    },
    bottomControls: {
        paddingHorizontal: spacing.lg,
        paddingBottom: responsiveDimensions.hasNotch
            ? (Platform.OS === 'ios' ? 40 : 24)
            : (Platform.OS === 'ios' ? 20 : 16),
    },
    progressContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: spacing.lg,
        gap: spacing.md,
    },
    timeText: {
        fontSize: typography.caption,
        color: 'white',
        fontWeight: '500',
        minWidth: responsiveDimensions.isSmallDevice ? 35 : 40,
    },
    progressBar: {
        flex: 1,
        height: responsiveDimensions.isSmallDevice ? 5 : 6,
    },
    progressTrack: {
        width: '100%',
        height: responsiveDimensions.isSmallDevice ? 5 : 6,
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        borderRadius: 3,
        overflow: 'hidden',
    },
    progressFill: {
        height: '100%',
        backgroundColor: Colors.dark.primary,
        borderRadius: 3,
    },
    playbackControls: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: responsiveDimensions.isSmallDevice ? spacing.lg : spacing.xl,
    },
    controlButton: {
        width: getMinTouchTarget(),
        height: getMinTouchTarget(),
        borderRadius: getMinTouchTarget() / 2,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
    },
    playButton: {
        width: responsiveDimensions.isSmallDevice ? 56 : 64,
        height: responsiveDimensions.isSmallDevice ? 56 : 64,
        borderRadius: responsiveDimensions.isSmallDevice ? 28 : 32,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center',
    },
    speedControls: {
        flexDirection: 'row',
        gap: 6,
        marginLeft: spacing.md,
    },
    speedButton: {
        paddingHorizontal: spacing.sm,
        paddingVertical: 6,
        borderRadius: borderRadius.md,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
    },
    speedButtonActive: {
        backgroundColor: Colors.dark.primary,
    },
    speedButtonText: {
        fontSize: typography.tiny,
        fontWeight: '600',
        color: 'white',
    },
    speedButtonTextActive: {
        color: 'white',
    },
    menuOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 100,
    },
    speedMenu: {
        position: 'absolute',
        right: spacing.lg,
        backgroundColor: '#1E1E1E',
        borderRadius: borderRadius.md,
        padding: spacing.sm,
        minWidth: responsiveDimensions.isSmallDevice ? 130 : 150,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.1)',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: 0.30,
        shadowRadius: 4.65,
        elevation: 8,
        ...Platform.select({
            web: {
                boxShadow: '0px 4px 5px rgba(0, 0, 0, 0.3)',
            },
        }),
    },
    menuHeader: {
        fontSize: typography.caption,
        color: 'rgba(255, 255, 255, 0.5)',
        paddingHorizontal: spacing.md,
        paddingVertical: spacing.sm,
        fontWeight: '600',
        textTransform: 'uppercase',
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.md,
        borderRadius: borderRadius.sm,
        minHeight: getMinTouchTarget(),
    },
    menuItemActive: {
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
    },
    menuItemText: {
        fontSize: typography.bodySmall,
        color: 'rgba(255, 255, 255, 0.9)',
        fontWeight: '500',
    },
    menuItemTextActive: {
        color: 'white',
        fontWeight: '700',
    },
});

export default VideoPlayer;
