/**
 * Category Section Component
 * Category header with horizontal course list
 */

import React from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import { Course, Category } from '@/types';
import CourseCard from './CourseCard';
import { typography, spacing } from '@/utils/responsive';

interface CategorySectionProps {
    title: string;
    subtitle?: string;
    icon?: keyof typeof Ionicons.glyphMap;
    iconColor?: string;
    courses: Course[];
    onCoursePress: (course: Course) => void;
    onViewAll?: () => void;
    variant?: 'default' | 'thumbnail';
    size?: 'small' | 'medium' | 'large';
}

export function CategorySection({
    title,
    subtitle,
    icon,
    iconColor = Colors.dark.primary,
    courses,
    onCoursePress,
    onViewAll,
    variant = 'default',
    size = 'medium'
}: CategorySectionProps) {
    if (courses.length === 0) return null;

    return (
        <View style={styles.container}>
            {/* Category Header */}
            <View style={styles.header}>
                <View style={styles.headerLeft}>
                    {icon && (
                        <View style={styles.iconContainer}>
                            <Ionicons name={icon} size={24} color={iconColor} />
                        </View>
                    )}
                    <View>
                        <Text style={styles.title}>{title}</Text>
                        {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
                    </View>
                </View>
                {onViewAll && (
                    <TouchableOpacity onPress={onViewAll} style={styles.viewAllButton}>
                        <Ionicons name="chevron-forward" size={18} color={Colors.dark.text} />
                    </TouchableOpacity>
                )}
            </View>

            {/* Horizontal Course List */}
            <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.courseList}
            >
                {courses.map((course) => (
                    <CourseCard
                        key={course.id}
                        course={course}
                        onPress={onCoursePress}
                        size={size}
                        variant={variant}
                    />
                ))}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        marginBottom: spacing.xl,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: spacing.lg,
        marginBottom: spacing.lg,
    },
    headerLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.md,
        flex: 1,
    },
    iconContainer: {
        // Removed background container style
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: typography.h4,
        fontWeight: '600',
        color: Colors.dark.text,
        letterSpacing: 0.5,
    },
    subtitle: {
        fontSize: typography.bodySmall,
        color: Colors.dark.textMuted,
        marginTop: 2,
    },
    viewAllButton: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: 'rgba(255, 255, 255, 0.15)', // Glass effect
        justifyContent: 'center',
        alignItems: 'center',
        // Optional border for better contrast
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.1)',
    },
    courseList: {
        paddingHorizontal: spacing.lg,
        gap: spacing.lg,
    },
});

export default CategorySection;
