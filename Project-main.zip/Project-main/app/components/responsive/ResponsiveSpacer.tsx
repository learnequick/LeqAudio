/**
 * ResponsiveSpacer Component
 * A spacing component that adapts based on breakpoints
 */

import React, { memo, useMemo } from 'react';
import { View, ViewStyle, StyleProp } from 'react-native';
import { useResponsive, ResponsiveValue } from '@/hooks/useResponsive';

type SpacerSize = 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'xxxl';

interface ResponsiveSpacerProps {
    // Size from spacing scale
    size?: SpacerSize | ResponsiveValue<SpacerSize>;

    // Or explicit size in pixels
    height?: ResponsiveValue<number> | number;
    width?: ResponsiveValue<number> | number;

    // Direction (vertical = height, horizontal = width)
    direction?: 'vertical' | 'horizontal';

    // Flex spacer (takes remaining space)
    flex?: number;

    style?: StyleProp<ViewStyle>;
}

export const ResponsiveSpacer = memo(function ResponsiveSpacer({
    size,
    height,
    width,
    direction = 'vertical',
    flex,
    style,
}: ResponsiveSpacerProps) {
    const { spacing, resolve } = useResponsive();

    const spacerStyle = useMemo((): ViewStyle => {
        // If flex spacer
        if (flex !== undefined) {
            return { flex };
        }

        // If explicit height/width provided
        if (height !== undefined) {
            return { height: resolve(height as ResponsiveValue<number>) };
        }
        if (width !== undefined) {
            return { width: resolve(width as ResponsiveValue<number>) };
        }

        // If using spacing scale size
        if (size !== undefined) {
            const resolvedSize = typeof size === 'string'
                ? size
                : resolve(size as ResponsiveValue<SpacerSize>);

            const spacingValue = spacing[resolvedSize as SpacerSize] ?? 0;

            if (direction === 'horizontal') {
                return { width: spacingValue };
            }
            return { height: spacingValue };
        }

        // Default to medium spacing
        if (direction === 'horizontal') {
            return { width: spacing.md };
        }
        return { height: spacing.md };
    }, [size, height, width, direction, flex, spacing, resolve]);

    return <View style={[spacerStyle, style]} />;
});

// ==================== Section Divider ====================

interface SectionDividerProps {
    // Color
    color?: string;

    // Thickness
    thickness?: number;

    // Spacing above and below
    spacing?: ResponsiveValue<number> | number;

    // Horizontal margin
    marginHorizontal?: ResponsiveValue<number> | number;

    style?: StyleProp<ViewStyle>;
}

export const SectionDivider = memo(function SectionDivider({
    color = 'rgba(255, 255, 255, 0.1)',
    thickness = 1,
    spacing: spacingProp,
    marginHorizontal,
    style,
}: SectionDividerProps) {
    const { spacing: spacingScale, resolve } = useResponsive();

    const resolvedSpacing = spacingProp !== undefined
        ? resolve(spacingProp as ResponsiveValue<number>)
        : spacingScale.lg;
    const resolvedMargin = marginHorizontal !== undefined
        ? resolve(marginHorizontal as ResponsiveValue<number>)
        : 0;

    const dividerStyle = useMemo((): ViewStyle => ({
        height: thickness,
        backgroundColor: color,
        marginVertical: resolvedSpacing,
        marginHorizontal: resolvedMargin,
    }), [thickness, color, resolvedSpacing, resolvedMargin]);

    return <View style={[dividerStyle, style]} />;
});

// ==================== Flex Spacer (Push content apart) ====================

interface FlexSpacerProps {
    // Minimum size even as flex spacer
    minHeight?: number;
    minWidth?: number;
}

export const FlexSpacer = memo(function FlexSpacer({
    minHeight,
    minWidth,
}: FlexSpacerProps) {
    return (
        <View
            style={{
                flex: 1,
                minHeight,
                minWidth,
            }}
        />
    );
});
