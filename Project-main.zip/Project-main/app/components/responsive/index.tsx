/**
 * Responsive Components - Export all responsive components
 */

export { ResponsiveView } from './ResponsiveView';
export { ResponsiveText } from './ResponsiveText';
export { ResponsiveGrid, ResponsiveGridList } from './ResponsiveGrid';
export { ResponsiveTouchable, ResponsiveButton } from './ResponsiveTouchable';
export { ResponsiveLayout, SplitPane, ResponsiveContainer } from './ResponsiveLayout';
export { ResponsiveImage, ResponsiveBackgroundImage, AspectRatioContainer } from './ResponsiveImage';
export { ResponsiveSafeArea, ScreenWrapper, InsetAwareView } from './ResponsiveSafeArea';
export { ResponsiveSpacer, SectionDivider, FlexSpacer } from './ResponsiveSpacer';

// Re-export the hook for convenience
export { useResponsive, BREAKPOINTS } from '@/hooks/useResponsive';
export type {
    Breakpoint,
    ResponsiveValue,
    UseResponsiveReturn,
    SpacingScale,
    TypographyScale,
    IconScale,
    GridConfig,
    AccessibilityConfig,
    LayoutInfo,
} from '@/hooks/useResponsive';
