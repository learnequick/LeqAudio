/**
 * ResponsiveImage Component
 * Image component that maintains aspect ratio and adapts to screen size
 * Supports lazy loading and proper resize modes
 */

import React, { memo, useMemo, useState, useCallback } from 'react';
import {
    Image,
    ImageProps,
    ImageStyle,
    StyleProp,
    View,
    ViewStyle,
    ActivityIndicator,
    ImageSourcePropType,
    StyleSheet,
} from 'react-native';
import { useResponsive, ResponsiveValue } from '@/hooks/useResponsive';
import { Colors } from '@/constants/Colors';

interface ResponsiveImageProps {
    source: ImageSourcePropType;
    style?: StyleProp<ViewStyle>;
    imageStyle?: StyleProp<ImageStyle>;

    // Sizing options - one of these should be specified
    width?: ResponsiveValue<number | string> | number | string;
    height?: ResponsiveValue<number | string> | number | string;

    // Aspect ratio (width / height) - used with either width or height
    aspectRatio?: number;

    // Fill container (uses flex: 1)
    fill?: boolean;

    // Resize mode
    resizeMode?: ImageProps['resizeMode'];

    // Background color while loading
    backgroundColor?: string;

    // Show loading indicator
    showLoading?: boolean;
    loadingColor?: string;

    // Border radius
    borderRadius?: ResponsiveValue<number> | number;

    // Lazy loading (deferred loading)
    lazyLoad?: boolean;

    // Fallback content when image fails to load
    fallback?: React.ReactNode;

    // Accessibility
    accessibilityLabel: string; // Required for accessibility

    // Image event handlers
    onLoad?: ImageProps['onLoad'];
    onError?: ImageProps['onError'];

    testID?: string;
}

export const ResponsiveImage = memo(function ResponsiveImage({
    source,
    style,
    imageStyle,
    width,
    height,
    aspectRatio,
    fill = false,
    resizeMode = 'cover',
    backgroundColor = Colors.dark.card,
    showLoading = true,
    loadingColor = Colors.dark.primary,
    borderRadius,
    lazyLoad = false,
    fallback,
    accessibilityLabel,
    testID,
    onLoad,
    onError,
}: ResponsiveImageProps) {
    const { resolve, borderRadius: borderRadiusScale } = useResponsive();

    const [isLoading, setIsLoading] = useState(true);
    const [hasError, setHasError] = useState(false);
    const [shouldLoad, setShouldLoad] = useState(!lazyLoad);

    const resolvedWidth = width !== undefined ? resolve(width as ResponsiveValue<number | string>) : undefined;
    const resolvedHeight = height !== undefined ? resolve(height as ResponsiveValue<number | string>) : undefined;
    const resolvedBorderRadius = borderRadius !== undefined
        ? resolve(borderRadius as ResponsiveValue<number>)
        : 0;

    // Handle load complete
    const handleLoad = useCallback((e: any) => {
        setIsLoading(false);
        onLoad?.(e);
    }, [onLoad]);

    // Handle error
    const handleError = useCallback((e: any) => {
        setIsLoading(false);
        setHasError(true);
        onError?.(e);
    }, [onError]);

    // Container style
    const containerStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {
            overflow: 'hidden',
            backgroundColor: isLoading ? backgroundColor : 'transparent',
            borderRadius: resolvedBorderRadius,
        };

        if (fill) {
            result.flex = 1;
        } else {
            if (resolvedWidth !== undefined) {
                result.width = resolvedWidth as ViewStyle['width'];
            }
            if (resolvedHeight !== undefined) {
                result.height = resolvedHeight as ViewStyle['height'];
            }
            if (aspectRatio !== undefined) {
                result.aspectRatio = aspectRatio;
            }
        }

        return result;
    }, [fill, resolvedWidth, resolvedHeight, aspectRatio, resolvedBorderRadius, isLoading, backgroundColor]);

    // Image style
    const computedImageStyle = useMemo((): ImageStyle => ({
        width: '100%',
        height: '100%',
        borderRadius: resolvedBorderRadius,
    }), [resolvedBorderRadius]);

    // If errored and has fallback, show fallback
    if (hasError && fallback) {
        return (
            <View style={[containerStyle, style]} testID={testID}>
                {fallback}
            </View>
        );
    }

    // If lazy loading and not triggered yet
    if (!shouldLoad) {
        return (
            <View
                style={[containerStyle, style]}
                testID={testID}
                onLayout={() => setShouldLoad(true)} // Load when in viewport
            >
                {showLoading && (
                    <View style={styles.loadingContainer}>
                        <ActivityIndicator color={loadingColor} />
                    </View>
                )}
            </View>
        );
    }

    return (
        <View style={[containerStyle, style]} testID={testID}>
            <Image
                source={source}
                style={[computedImageStyle, imageStyle]}
                resizeMode={resizeMode}
                onLoad={handleLoad}
                onError={handleError}
                accessible
                accessibilityLabel={accessibilityLabel}
                accessibilityRole="image"
            />

            {/* Loading overlay */}
            {isLoading && showLoading && (
                <View style={styles.loadingOverlay}>
                    <ActivityIndicator color={loadingColor} />
                </View>
            )}
        </View>
    );
});

const styles = StyleSheet.create({
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingOverlay: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'center',
        alignItems: 'center',
    },
});

// ==================== Responsive Background Image ====================

interface ResponsiveBackgroundImageProps extends Omit<ResponsiveImageProps, 'fill'> {
    children?: React.ReactNode;
    overlayColor?: string;
    overlayOpacity?: number;
}

export const ResponsiveBackgroundImage = memo(function ResponsiveBackgroundImage({
    children,
    overlayColor = '#000',
    overlayOpacity = 0.3,
    style,
    ...imageProps
}: ResponsiveBackgroundImageProps) {
    return (
        <View style={[{ flex: 1, position: 'relative' }, style]}>
            <ResponsiveImage
                {...imageProps}
                fill
                style={StyleSheet.absoluteFill}
                showLoading={false}
            />

            {/* Overlay */}
            {overlayOpacity > 0 && (
                <View
                    style={[
                        StyleSheet.absoluteFill,
                        { backgroundColor: overlayColor, opacity: overlayOpacity },
                    ]}
                />
            )}

            {/* Content */}
            <View style={{ flex: 1, position: 'relative' }}>
                {children}
            </View>
        </View>
    );
});

// ==================== Aspect Ratio Container ====================

interface AspectRatioContainerProps {
    children: React.ReactNode;
    ratio: number; // width / height (e.g., 16/9 for 16:9)
    width?: number | string;
    style?: StyleProp<ViewStyle>;
}

export const AspectRatioContainer = memo(function AspectRatioContainer({
    children,
    ratio,
    width = '100%',
    style,
}: AspectRatioContainerProps) {
    return (
        <View style={[{ width: width as ViewStyle['width'], aspectRatio: ratio }, style]}>
            {children}
        </View>
    );
});
