/**
 * ResponsiveLayout Component
 * A layout component that switches between single-column, stacked, and multi-column
 * layouts based on device size and orientation
 */

import React, { memo, useMemo, ReactNode } from 'react';
import { View, ViewStyle, StyleProp, StyleSheet, ScrollView } from 'react-native';
import { useResponsive, ResponsiveValue } from '@/hooks/useResponsive';

type LayoutVariant = 'single' | 'stacked' | 'splitPane' | 'sidebar';

interface ResponsiveLayoutProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Layout variant per breakpoint (mobile-first)
    variant?: ResponsiveValue<LayoutVariant> | LayoutVariant;

    // Gap between sections
    gap?: ResponsiveValue<number> | number;

    // Container padding
    padding?: ResponsiveValue<number> | number;

    // Max content width (for tablets/desktop)
    maxWidth?: number;

    // Whether to center content when constrained
    centerContent?: boolean;

    // Split pane specific: ratio between primary and secondary
    splitRatio?: [number, number]; // e.g., [2, 1] for 2:1 ratio

    // Sidebar specific: sidebar width
    sidebarWidth?: ResponsiveValue<number> | number;

    // Reverse order on smaller screens
    reverseOnMobile?: boolean;

    testID?: string;
}

export const ResponsiveLayout = memo(function ResponsiveLayout({
    children,
    style,
    variant = { xs: 'single', sm: 'single', md: 'stacked', lg: 'splitPane', xl: 'splitPane', default: 'single' },
    gap,
    padding,
    maxWidth = 1200,
    centerContent = true,
    splitRatio = [1, 1],
    sidebarWidth = { xs: 250, sm: 280, md: 300, lg: 320, xl: 360, default: 280 },
    reverseOnMobile = false,
    testID,
}: ResponsiveLayoutProps) {
    const {
        resolve,
        spacing,
        width,
        isLandscape,
        isTablet,
        isPhone,
        breakpoint,
    } = useResponsive();

    const resolvedVariant = resolve(variant as ResponsiveValue<LayoutVariant>);
    const resolvedGap = gap !== undefined ? resolve(gap as ResponsiveValue<number>) : spacing.lg;
    const resolvedPadding = padding !== undefined ? resolve(padding as ResponsiveValue<number>) : spacing.lg;
    const resolvedSidebarWidth = resolve(sidebarWidth as ResponsiveValue<number>);

    // Convert children to array
    const childrenArray = React.Children.toArray(children);
    const primaryChild = childrenArray[0];
    const secondaryChild = childrenArray[1];

    const containerStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {
            flex: 1,
            padding: resolvedPadding,
        };

        // Max width constraint
        if (width > maxWidth && centerContent) {
            result.maxWidth = maxWidth;
            result.alignSelf = 'center';
            result.width = '100%';
        }

        return result;
    }, [resolvedPadding, width, maxWidth, centerContent]);

    const contentStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {
            flex: 1,
        };

        switch (resolvedVariant) {
            case 'single':
                // Single column - stack vertically
                result.flexDirection = 'column';
                result.gap = resolvedGap;
                break;

            case 'stacked':
                // Stacked sections - vertical with more spacing
                result.flexDirection = 'column';
                result.gap = resolvedGap * 1.5;
                break;

            case 'splitPane':
                // Side-by-side columns
                result.flexDirection = 'row';
                result.gap = resolvedGap * 2;
                break;

            case 'sidebar':
                // Sidebar + content
                result.flexDirection = 'row';
                result.gap = resolvedGap;
                break;
        }

        return result;
    }, [resolvedVariant, resolvedGap]);

    // Render based on variant
    const renderContent = () => {
        switch (resolvedVariant) {
            case 'single':
            case 'stacked':
                // Vertically stacked layout
                const orderedChildren = reverseOnMobile && (isPhone && !isLandscape)
                    ? [...childrenArray].reverse()
                    : childrenArray;

                return (
                    <View style={contentStyle}>
                        {orderedChildren.map((child, index) => (
                            <View key={index} style={{ width: '100%' }}>
                                {child}
                            </View>
                        ))}
                    </View>
                );

            case 'splitPane':
                // Two columns with ratio
                const [primaryRatio, secondaryRatio] = splitRatio;
                const totalRatio = primaryRatio + secondaryRatio;

                return (
                    <View style={contentStyle}>
                        <View style={{ flex: primaryRatio / totalRatio }}>
                            {primaryChild}
                        </View>
                        {secondaryChild && (
                            <View style={{ flex: secondaryRatio / totalRatio }}>
                                {secondaryChild}
                            </View>
                        )}
                    </View>
                );

            case 'sidebar':
                // Fixed sidebar + flexible content
                return (
                    <View style={contentStyle}>
                        <View style={{ width: resolvedSidebarWidth, flexShrink: 0 }}>
                            {primaryChild}
                        </View>
                        <View style={{ flex: 1 }}>
                            {secondaryChild}
                        </View>
                    </View>
                );

            default:
                return children;
        }
    };

    return (
        <View style={[containerStyle, style]} testID={testID}>
            {renderContent()}
        </View>
    );
});

// ==================== Split Pane Specific Component ====================

interface SplitPaneProps {
    primary: React.ReactNode;
    secondary: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Ratio between primary and secondary panes
    ratio?: [number, number];

    // Gap between panes
    gap?: number;

    // Divider options
    showDivider?: boolean;
    dividerColor?: string;

    // Direction override
    direction?: 'horizontal' | 'vertical';

    // Collapse secondary on smaller screens
    collapseSecondary?: boolean;
}

export const SplitPane = memo(function SplitPane({
    primary,
    secondary,
    style,
    ratio = [1, 1],
    gap = 16,
    showDivider = false,
    dividerColor = '#2A2A2A',
    direction,
    collapseSecondary = true,
}: SplitPaneProps) {
    const { isTablet, isLandscape, isDesktop, spacing } = useResponsive();

    // Determine if we should show split pane or collapse
    const showSplit = isTablet || isDesktop || (isLandscape && !collapseSecondary);
    const resolvedDirection = direction ?? (showSplit ? 'horizontal' : 'vertical');

    const [primaryRatio, secondaryRatio] = ratio;
    const totalRatio = primaryRatio + secondaryRatio;

    const containerStyle = useMemo((): ViewStyle => ({
        flex: 1,
        flexDirection: resolvedDirection === 'horizontal' ? 'row' : 'column',
        gap,
    }), [resolvedDirection, gap]);

    // If collapsed, only show primary
    if (!showSplit && collapseSecondary) {
        return (
            <View style={[{ flex: 1 }, style]}>
                {primary}
            </View>
        );
    }

    return (
        <View style={[containerStyle, style]}>
            <View style={{ flex: primaryRatio / totalRatio }}>
                {primary}
            </View>

            {showDivider && (
                <View
                    style={{
                        width: resolvedDirection === 'horizontal' ? 1 : '100%',
                        height: resolvedDirection === 'vertical' ? 1 : '100%',
                        backgroundColor: dividerColor,
                    }}
                />
            )}

            <View style={{ flex: secondaryRatio / totalRatio }}>
                {secondary}
            </View>
        </View>
    );
});

// ==================== Responsive Container with Max Width ====================

interface ResponsiveContainerProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;
    maxWidth?: number;
    padding?: number;
    centered?: boolean;
}

export const ResponsiveContainer = memo(function ResponsiveContainer({
    children,
    style,
    maxWidth = 1200,
    padding,
    centered = true,
}: ResponsiveContainerProps) {
    const { width, spacing, safeAreas } = useResponsive();

    const resolvedPadding = padding ?? spacing.lg;
    const shouldConstrain = width > maxWidth;

    const containerStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {
            width: '100%',
            paddingHorizontal: resolvedPadding,
        };

        if (shouldConstrain) {
            result.maxWidth = maxWidth;
            if (centered) {
                result.alignSelf = 'center';
            }
        }

        return result;
    }, [shouldConstrain, maxWidth, centered, resolvedPadding]);

    return (
        <View style={[containerStyle, style]}>
            {children}
        </View>
    );
});
