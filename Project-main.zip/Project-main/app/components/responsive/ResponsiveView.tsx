/**
 * ResponsiveView Component
 * A View wrapper that applies responsive styles based on breakpoints
 */

import React, { memo, useMemo } from 'react';
import { View, ViewStyle, StyleProp, StyleSheet } from 'react-native';
import { useResponsive, ResponsiveValue, Breakpoint } from '@/hooks/useResponsive';

interface ResponsiveViewProps {
    children?: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Responsive style overrides per breakpoint
    breakpointStyles?: {
        xs?: ViewStyle;
        sm?: ViewStyle;
        md?: ViewStyle;
        lg?: ViewStyle;
        xl?: ViewStyle;
    };

    // Quick responsive helpers
    flex?: ResponsiveValue<number> | number;
    flexDirection?: ResponsiveValue<ViewStyle['flexDirection']> | ViewStyle['flexDirection'];
    gap?: ResponsiveValue<number> | number;
    padding?: ResponsiveValue<number> | number;
    paddingHorizontal?: ResponsiveValue<number> | number;
    paddingVertical?: ResponsiveValue<number> | number;
    margin?: ResponsiveValue<number> | number;
    marginHorizontal?: ResponsiveValue<number> | number;
    marginVertical?: ResponsiveValue<number> | number;

    // Layout containers
    maxWidth?: number | '100%';
    centered?: boolean;

    // Accessibility
    accessibilityLabel?: string;
    accessibilityRole?: 'none' | 'button' | 'link' | 'header' | 'menu' | 'menuitem';
    testID?: string;
}

export const ResponsiveView = memo(function ResponsiveView({
    children,
    style,
    breakpointStyles,
    flex,
    flexDirection,
    gap,
    padding,
    paddingHorizontal,
    paddingVertical,
    margin,
    marginHorizontal,
    marginVertical,
    maxWidth,
    centered,
    accessibilityLabel,
    accessibilityRole,
    testID,
}: ResponsiveViewProps) {
    const { breakpoint, resolve, spacing, width } = useResponsive();

    const computedStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {};

        // Apply breakpoint-specific styles
        if (breakpointStyles) {
            const bpStyle = breakpointStyles[breakpoint];
            if (bpStyle) {
                Object.assign(result, bpStyle);
            }
        }

        // Apply responsive props
        if (flex !== undefined) {
            result.flex = resolve(flex as ResponsiveValue<number>);
        }

        if (flexDirection !== undefined) {
            result.flexDirection = resolve(flexDirection as ResponsiveValue<ViewStyle['flexDirection']>);
        }

        if (gap !== undefined) {
            result.gap = resolve(gap as ResponsiveValue<number>);
        }

        if (padding !== undefined) {
            result.padding = resolve(padding as ResponsiveValue<number>);
        }

        if (paddingHorizontal !== undefined) {
            result.paddingHorizontal = resolve(paddingHorizontal as ResponsiveValue<number>);
        }

        if (paddingVertical !== undefined) {
            result.paddingVertical = resolve(paddingVertical as ResponsiveValue<number>);
        }

        if (margin !== undefined) {
            result.margin = resolve(margin as ResponsiveValue<number>);
        }

        if (marginHorizontal !== undefined) {
            result.marginHorizontal = resolve(marginHorizontal as ResponsiveValue<number>);
        }

        if (marginVertical !== undefined) {
            result.marginVertical = resolve(marginVertical as ResponsiveValue<number>);
        }

        // Max width constraint
        if (maxWidth !== undefined) {
            if (typeof maxWidth === 'number') {
                result.maxWidth = maxWidth;
                if (width > maxWidth) {
                    result.alignSelf = 'center';
                    result.width = '100%';
                }
            }
        }

        // Centered content
        if (centered) {
            result.alignItems = 'center';
            result.justifyContent = 'center';
        }

        return result;
    }, [
        breakpoint,
        breakpointStyles,
        flex,
        flexDirection,
        gap,
        padding,
        paddingHorizontal,
        paddingVertical,
        margin,
        marginHorizontal,
        marginVertical,
        maxWidth,
        centered,
        width,
        resolve,
    ]);

    return (
        <View
            style={[computedStyle, style]}
            accessibilityLabel={accessibilityLabel}
            accessibilityRole={accessibilityRole}
            testID={testID}
        >
            {children}
        </View>
    );
});
