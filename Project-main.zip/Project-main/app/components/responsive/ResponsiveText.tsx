/**
 * ResponsiveText Component
 * Typography component that scales responsively and respects system font settings
 */

import React, { memo, useMemo } from 'react';
import { Text, TextStyle, StyleProp, TextProps, AccessibilityRole } from 'react-native';
import { useResponsive, ResponsiveValue } from '@/hooks/useResponsive';
import { Colors } from '@/constants/Colors';

// Typography variants matching design system
type TypographyVariant =
    | 'display'
    | 'h1'
    | 'h2'
    | 'h3'
    | 'h4'
    | 'h5'
    | 'h6'
    | 'body'
    | 'bodySmall'
    | 'caption'
    | 'overline'
    | 'tiny';

interface ResponsiveTextProps extends Omit<TextProps, 'style'> {
    children: React.ReactNode;
    style?: StyleProp<TextStyle>;

    // Typography variant
    variant?: TypographyVariant;

    // Color options
    color?: keyof typeof Colors.dark | string;
    muted?: boolean;

    // Font weight shortcuts
    weight?: 'normal' | 'medium' | 'semibold' | 'bold';

    // Text alignment
    align?: 'left' | 'center' | 'right' | 'justify';

    // Responsive font size override
    size?: ResponsiveValue<number> | number;

    // Line height multiplier (relative to font size)
    lineHeightMultiplier?: number;

    // Max width for readable line length (especially on tablets)
    maxWidth?: number;

    // Accessibility
    accessibilityRole?: AccessibilityRole;
    accessibilityLabel?: string;

    // Performance
    selectable?: boolean;
    numberOfLines?: number;
}

// Variant to accessibility role mapping
const VARIANT_ROLES: Record<TypographyVariant, AccessibilityRole | undefined> = {
    display: 'header',
    h1: 'header',
    h2: 'header',
    h3: 'header',
    h4: 'header',
    h5: 'header',
    h6: 'header',
    body: undefined,
    bodySmall: undefined,
    caption: undefined,
    overline: undefined,
    tiny: undefined,
};

// Weight mappings
const WEIGHT_MAP: Record<NonNullable<ResponsiveTextProps['weight']>, TextStyle['fontWeight']> = {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
};

// Default line height multipliers per variant
const LINE_HEIGHT_MULTIPLIERS: Record<TypographyVariant, number> = {
    display: 1.2,
    h1: 1.25,
    h2: 1.3,
    h3: 1.3,
    h4: 1.35,
    h5: 1.4,
    h6: 1.4,
    body: 1.5,
    bodySmall: 1.5,
    caption: 1.4,
    overline: 1.4,
    tiny: 1.3,
};

export const ResponsiveText = memo(function ResponsiveText({
    children,
    style,
    variant = 'body',
    color = 'text',
    muted = false,
    weight,
    align,
    size,
    lineHeightMultiplier,
    maxWidth,
    accessibilityRole,
    accessibilityLabel,
    selectable = false,
    numberOfLines,
    ...textProps
}: ResponsiveTextProps) {
    const { typography, resolve, isDarkMode } = useResponsive();

    const computedStyle = useMemo((): TextStyle => {
        // Get base font size from typography scale or custom size
        let fontSize: number;
        if (size !== undefined) {
            fontSize = resolve(size as ResponsiveValue<number>);
        } else {
            fontSize = typography[variant];
        }

        // Calculate line height
        const multiplier = lineHeightMultiplier ?? LINE_HEIGHT_MULTIPLIERS[variant];
        const lineHeight = Math.round(fontSize * multiplier);

        // Resolve color
        let textColor: string;
        if (muted) {
            textColor = Colors.dark.textMuted;
        } else if (color in Colors.dark) {
            textColor = Colors.dark[color as keyof typeof Colors.dark];
        } else {
            textColor = color;
        }

        // Determine font weight from variant or explicit prop
        let fontWeight: TextStyle['fontWeight'];
        if (weight) {
            fontWeight = WEIGHT_MAP[weight];
        } else {
            // Default weights for heading variants
            switch (variant) {
                case 'display':
                case 'h1':
                    fontWeight = '700';
                    break;
                case 'h2':
                case 'h3':
                    fontWeight = '600';
                    break;
                case 'h4':
                case 'h5':
                case 'h6':
                    fontWeight = '600';
                    break;
                case 'overline':
                    fontWeight = '600';
                    break;
                default:
                    fontWeight = '400';
            }
        }

        const result: TextStyle = {
            fontSize,
            lineHeight,
            color: textColor,
            fontWeight,
        };

        if (align) {
            result.textAlign = align;
        }

        // Overline specific styling
        if (variant === 'overline') {
            result.textTransform = 'uppercase';
            result.letterSpacing = 1;
        }

        // Max width for readability (optimal line length ~75 characters)
        if (maxWidth) {
            result.maxWidth = maxWidth;
        }

        return result;
    }, [variant, size, lineHeightMultiplier, color, muted, weight, align, maxWidth, typography, resolve, isDarkMode]);

    // Determine accessibility role
    const role = accessibilityRole ?? VARIANT_ROLES[variant];

    return (
        <Text
            style={[computedStyle, style]}
            accessibilityRole={role}
            accessibilityLabel={accessibilityLabel}
            selectable={selectable}
            numberOfLines={numberOfLines}
            {...textProps}
        >
            {children}
        </Text>
    );
});
