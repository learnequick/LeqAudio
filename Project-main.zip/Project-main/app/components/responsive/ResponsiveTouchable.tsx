/**
 * ResponsiveTouchable Component
 * An accessible touchable component that enforces minimum touch targets
 * and provides consistent feedback across platforms
 */

import React, { memo, useMemo, useCallback } from 'react';
import {
    TouchableOpacity,
    TouchableHighlight,
    Pressable,
    ViewStyle,
    StyleProp,
    TouchableOpacityProps,
    Platform,
    View,
    GestureResponderEvent,
} from 'react-native';
import { useResponsive } from '@/hooks/useResponsive';
import { Colors } from '@/constants/Colors';

type TouchableVariant = 'opacity' | 'highlight' | 'scale' | 'none';

interface ResponsiveTouchableProps extends Omit<TouchableOpacityProps, 'style'> {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Touch feedback variant
    variant?: TouchableVariant;

    // Whether to enforce minimum touch target size (default: true)
    enforceMinSize?: boolean;

    // Custom minimum size (overrides platform defaults)
    minSize?: number;

    // Highlight color for 'highlight' variant
    highlightColor?: string;

    // Scale amount for 'scale' variant
    scaleAmount?: number;

    // Hit slop for accessibility
    hitSlopAll?: number;

    // Accessibility
    accessibilityLabel: string; // Required for accessibility
    accessibilityHint?: string;
    accessibilityRole?: 'button' | 'link' | 'menuitem' | 'tab';

    // Disabled state
    disabled?: boolean;
    disabledOpacity?: number;

    testID?: string;
}

// Get minimum touch target based on platform
const getMinTouchTarget = (): number => {
    return Platform.OS === 'ios' ? 44 : 48;
};

export const ResponsiveTouchable = memo(function ResponsiveTouchable({
    children,
    style,
    variant = 'opacity',
    enforceMinSize = true,
    minSize,
    highlightColor = Colors.dark.cardHover,
    scaleAmount = 0.97,
    hitSlopAll,
    accessibilityLabel,
    accessibilityHint,
    accessibilityRole = 'button',
    disabled = false,
    disabledOpacity = 0.5,
    onPress,
    testID,
    ...touchableProps
}: ResponsiveTouchableProps) {
    const { borderRadius } = useResponsive();

    // Calculate minimum size
    const minimumSize = minSize ?? getMinTouchTarget();

    // Build hit slop
    const hitSlop = useMemo(() => {
        if (hitSlopAll) {
            return {
                top: hitSlopAll,
                bottom: hitSlopAll,
                left: hitSlopAll,
                right: hitSlopAll,
            };
        }
        return undefined;
    }, [hitSlopAll]);

    // Compute container style with minimum size enforcement
    const containerStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {};

        if (enforceMinSize) {
            result.minWidth = minimumSize;
            result.minHeight = minimumSize;
        }

        if (disabled) {
            result.opacity = disabledOpacity;
        }

        return result;
    }, [enforceMinSize, minimumSize, disabled, disabledOpacity]);

    // Handle press with disabled check
    const handlePress = useCallback((event: GestureResponderEvent) => {
        if (!disabled && onPress) {
            onPress(event);
        }
    }, [disabled, onPress]);

    // Common props for all variants
    const commonProps = {
        accessibilityLabel,
        accessibilityHint,
        accessibilityRole,
        accessibilityState: { disabled },
        disabled,
        onPress: handlePress,
        hitSlop,
        testID,
        ...touchableProps,
    };

    // Render based on variant
    switch (variant) {
        case 'highlight':
            return (
                <TouchableHighlight
                    style={[containerStyle, style]}
                    underlayColor={highlightColor}
                    activeOpacity={0.9}
                    {...commonProps}
                >
                    <>{children}</>
                </TouchableHighlight>
            );

        case 'scale':
            return (
                <Pressable
                    style={({ pressed }) => [
                        containerStyle,
                        style,
                        pressed && { transform: [{ scale: scaleAmount }] },
                    ]}
                    {...commonProps}
                >
                    {children}
                </Pressable>
            );

        case 'none':
            return (
                <Pressable
                    style={[containerStyle, style]}
                    {...commonProps}
                >
                    {children}
                </Pressable>
            );

        case 'opacity':
        default:
            return (
                <TouchableOpacity
                    style={[containerStyle, style]}
                    activeOpacity={0.7}
                    {...commonProps}
                >
                    {children}
                </TouchableOpacity>
            );
    }
});

// ==================== Preset Button Styles ====================

interface ResponsiveButtonProps extends Omit<ResponsiveTouchableProps, 'variant'> {
    // Button size
    size?: 'sm' | 'md' | 'lg';

    // Button appearance
    appearance?: 'filled' | 'outlined' | 'ghost';

    // Color scheme
    colorScheme?: 'primary' | 'secondary' | 'danger' | 'success';

    // Full width
    fullWidth?: boolean;
}

export const ResponsiveButton = memo(function ResponsiveButton({
    children,
    style,
    size = 'md',
    appearance = 'filled',
    colorScheme = 'primary',
    fullWidth = false,
    ...props
}: ResponsiveButtonProps) {
    const { spacing, borderRadius, typography } = useResponsive();

    const buttonStyle = useMemo((): ViewStyle => {
        // Size variants
        const sizeStyles: Record<typeof size, ViewStyle> = {
            sm: {
                paddingVertical: spacing.sm,
                paddingHorizontal: spacing.md,
                borderRadius: borderRadius.sm,
            },
            md: {
                paddingVertical: spacing.md,
                paddingHorizontal: spacing.lg,
                borderRadius: borderRadius.md,
            },
            lg: {
                paddingVertical: spacing.lg,
                paddingHorizontal: spacing.xl,
                borderRadius: borderRadius.lg,
            },
        };

        // Color schemes
        const colors: Record<typeof colorScheme, string> = {
            primary: Colors.dark.primary,
            secondary: Colors.dark.secondary,
            danger: Colors.dark.danger,
            success: Colors.dark.success,
        };

        const result: ViewStyle = {
            ...sizeStyles[size],
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'row',
        };

        // Appearance
        switch (appearance) {
            case 'filled':
                result.backgroundColor = colors[colorScheme];
                break;
            case 'outlined':
                result.borderWidth = 1.5;
                result.borderColor = colors[colorScheme];
                result.backgroundColor = 'transparent';
                break;
            case 'ghost':
                result.backgroundColor = 'transparent';
                break;
        }

        if (fullWidth) {
            result.width = '100%';
        }

        return result;
    }, [size, appearance, colorScheme, fullWidth, spacing, borderRadius]);

    return (
        <ResponsiveTouchable
            style={[buttonStyle, style]}
            variant="scale"
            {...props}
        >
            {children}
        </ResponsiveTouchable>
    );
});
