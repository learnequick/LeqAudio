/**
 * ResponsiveGrid Component
 * A responsive grid layout that adapts columns based on device size
 * Uses Flexbox for layout, not FlatList, for simple use cases
 */

import React, { memo, useMemo, ReactNode, ReactElement, Children, isValidElement } from 'react';
import { View, ViewStyle, StyleProp, StyleSheet, FlatList, FlatListProps } from 'react-native';
import { useResponsive, ResponsiveValue } from '@/hooks/useResponsive';

interface ResponsiveGridProps {
    children?: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Number of columns per breakpoint
    columns?: ResponsiveValue<number> | number;

    // Gap between items
    gap?: ResponsiveValue<number> | number;
    rowGap?: ResponsiveValue<number> | number;
    columnGap?: ResponsiveValue<number> | number;

    // Container padding
    padding?: ResponsiveValue<number> | number;

    // Alignment
    alignItems?: ViewStyle['alignItems'];
    justifyContent?: ViewStyle['justifyContent'];

    // Test ID
    testID?: string;
}

export const ResponsiveGrid = memo(function ResponsiveGrid({
    children,
    style,
    columns = { xs: 1, sm: 2, md: 2, lg: 3, xl: 4, default: 2 },
    gap,
    rowGap,
    columnGap,
    padding,
    alignItems = 'stretch',
    justifyContent = 'flex-start',
    testID,
}: ResponsiveGridProps) {
    const { resolve, spacing, grid } = useResponsive();

    const numColumns = resolve(columns as ResponsiveValue<number>);
    const resolvedGap = gap !== undefined ? resolve(gap as ResponsiveValue<number>) : grid.gutter;
    const resolvedRowGap = rowGap !== undefined ? resolve(rowGap as ResponsiveValue<number>) : resolvedGap;
    const resolvedColumnGap = columnGap !== undefined ? resolve(columnGap as ResponsiveValue<number>) : resolvedGap;
    const resolvedPadding = padding !== undefined ? resolve(padding as ResponsiveValue<number>) : 0;

    const containerStyle = useMemo((): ViewStyle => ({
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems,
        justifyContent,
        padding: resolvedPadding,
        marginHorizontal: -(resolvedColumnGap / 2),
        marginVertical: -(resolvedRowGap / 2),
    }), [alignItems, justifyContent, resolvedPadding, resolvedColumnGap, resolvedRowGap]);

    const itemStyle = useMemo((): ViewStyle => ({
        width: `${100 / numColumns}%`,
        paddingHorizontal: resolvedColumnGap / 2,
        paddingVertical: resolvedRowGap / 2,
    }), [numColumns, resolvedColumnGap, resolvedRowGap]);

    // Wrap each child in a grid cell
    const wrappedChildren = useMemo(() => {
        return Children.map(children, (child, index) => {
            if (!isValidElement(child)) return null;

            return (
                <View
                    key={child.key ?? index}
                    style={itemStyle}
                    accessibilityRole="none"
                >
                    {child}
                </View>
            );
        });
    }, [children, itemStyle]);

    return (
        <View style={[containerStyle, style]} testID={testID}>
            {wrappedChildren}
        </View>
    );
});

// ==================== FlatList-based Grid for large lists ====================

interface ResponsiveGridListProps<T> extends Omit<FlatListProps<T>, 'numColumns' | 'columnWrapperStyle'> {
    // Number of columns per breakpoint
    columns?: ResponsiveValue<number> | number;

    // Gap between items
    gap?: ResponsiveValue<number> | number;

    // Container padding
    containerPadding?: ResponsiveValue<number> | number;
}

export function ResponsiveGridList<T>({
    columns = { xs: 1, sm: 2, md: 2, lg: 3, xl: 4, default: 2 },
    gap,
    containerPadding,
    contentContainerStyle,
    renderItem,
    ...flatListProps
}: ResponsiveGridListProps<T>) {
    const { resolve, grid, getGridItemWidth } = useResponsive();

    const numColumns = resolve(columns as ResponsiveValue<number>);
    const resolvedGap = gap !== undefined ? resolve(gap as ResponsiveValue<number>) : grid.gutter;
    const resolvedPadding = containerPadding !== undefined
        ? resolve(containerPadding as ResponsiveValue<number>)
        : grid.margin;

    const itemWidth = getGridItemWidth(numColumns, resolvedGap, resolvedPadding);

    const columnWrapperStyle = useMemo((): ViewStyle | null => {
        if (numColumns === 1) return null;
        return {
            gap: resolvedGap,
        };
    }, [numColumns, resolvedGap]);

    const containerStyle = useMemo((): ViewStyle => ({
        paddingHorizontal: resolvedPadding,
        paddingTop: resolvedGap,
        paddingBottom: resolvedGap,
    }), [resolvedPadding, resolvedGap]);

    // Wrap renderItem to apply item width
    const wrappedRenderItem = useMemo(() => {
        if (!renderItem) return undefined;

        return (info: any) => {
            const element = renderItem(info);
            if (!isValidElement(element)) return element;

            return (
                <View style={{ width: itemWidth }}>
                    {element}
                </View>
            );
        };
    }, [renderItem, itemWidth]);

    // Key needs to change when numColumns changes to force re-render
    const key = `grid-${numColumns}`;

    return (
        <FlatList
            key={key}
            numColumns={numColumns}
            columnWrapperStyle={numColumns > 1 ? columnWrapperStyle : undefined}
            contentContainerStyle={[containerStyle, contentContainerStyle]}
            renderItem={wrappedRenderItem}
            ItemSeparatorComponent={() => <View style={{ height: resolvedGap }} />}
            {...flatListProps}
        />
    );
}
