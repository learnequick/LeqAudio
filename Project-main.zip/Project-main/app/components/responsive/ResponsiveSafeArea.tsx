/**
 * ResponsiveSafeArea Component
 * A SafeAreaView wrapper that handles notches, rounded corners, and system bars
 * across all device types
 */

import React, { memo, useMemo } from 'react';
import { View, ViewStyle, StyleProp, StatusBar, Platform } from 'react-native';
import { SafeAreaView, Edge, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useResponsive } from '@/hooks/useResponsive';
import { Colors } from '@/constants/Colors';

type SafeAreaMode = 'full' | 'top' | 'bottom' | 'horizontal' | 'none';

interface ResponsiveSafeAreaProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Which edges to apply safe area padding
    mode?: SafeAreaMode;
    edges?: Edge[];

    // Background color
    backgroundColor?: string;

    // Additional padding beyond safe areas
    additionalPadding?: {
        top?: number;
        bottom?: number;
        left?: number;
        right?: number;
    };

    // Status bar style
    statusBarStyle?: 'light-content' | 'dark-content' | 'default';
    statusBarHidden?: boolean;
    statusBarTranslucent?: boolean;

    testID?: string;
}

// Convert mode to edges array
const modeToEdges = (mode: SafeAreaMode): Edge[] => {
    switch (mode) {
        case 'full':
            return ['top', 'bottom', 'left', 'right'];
        case 'top':
            return ['top', 'left', 'right'];
        case 'bottom':
            return ['bottom', 'left', 'right'];
        case 'horizontal':
            return ['left', 'right'];
        case 'none':
            return [];
        default:
            return ['top', 'bottom', 'left', 'right'];
    }
};

export const ResponsiveSafeArea = memo(function ResponsiveSafeArea({
    children,
    style,
    mode = 'full',
    edges,
    backgroundColor = Colors.dark.background,
    additionalPadding,
    statusBarStyle = 'light-content',
    statusBarHidden = false,
    statusBarTranslucent = true,
    testID,
}: ResponsiveSafeAreaProps) {
    const insets = useSafeAreaInsets();
    const { safeAreas } = useResponsive();

    // Determine edges to use
    const safeEdges = edges ?? modeToEdges(mode);

    // Calculate additional padding style
    const additionalPaddingStyle = useMemo((): ViewStyle => {
        const result: ViewStyle = {};

        if (additionalPadding) {
            if (additionalPadding.top) result.paddingTop = additionalPadding.top;
            if (additionalPadding.bottom) result.paddingBottom = additionalPadding.bottom;
            if (additionalPadding.left) result.paddingLeft = additionalPadding.left;
            if (additionalPadding.right) result.paddingRight = additionalPadding.right;
        }

        return result;
    }, [additionalPadding]);

    return (
        <>
            <StatusBar
                barStyle={statusBarStyle}
                hidden={statusBarHidden}
                translucent={statusBarTranslucent}
                backgroundColor="transparent"
            />

            <SafeAreaView
                style={[
                    { flex: 1, backgroundColor },
                    additionalPaddingStyle,
                    style,
                ]}
                edges={safeEdges}
                testID={testID}
            >
                {children}
            </SafeAreaView>
        </>
    );
});

// ==================== Screen Wrapper with Safe Area ====================

interface ScreenWrapperProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;
    contentStyle?: StyleProp<ViewStyle>;

    // Background
    backgroundColor?: string;

    // Safe area mode
    safeAreaMode?: SafeAreaMode;

    // Scroll behavior
    scrollable?: boolean;

    // Content max width (for tablets)
    maxContentWidth?: number;
    centerContent?: boolean;

    // Keyboard avoiding
    avoidKeyboard?: boolean;

    testID?: string;
}

export const ScreenWrapper = memo(function ScreenWrapper({
    children,
    style,
    contentStyle,
    backgroundColor = Colors.dark.background,
    safeAreaMode = 'full',
    scrollable = false,
    maxContentWidth = 1200,
    centerContent = true,
    avoidKeyboard = false,
    testID,
}: ScreenWrapperProps) {
    const { width, spacing } = useResponsive();

    const shouldConstrain = width > maxContentWidth && centerContent;

    const containerStyle = useMemo((): ViewStyle => ({
        width: '100%',
        maxWidth: shouldConstrain ? maxContentWidth : undefined,
        alignSelf: shouldConstrain ? 'center' : undefined,
    }), [shouldConstrain, maxContentWidth]);

    const ContentWrapper = scrollable
        ? require('react-native').ScrollView
        : View;

    const contentWrapperProps = scrollable
        ? {
            style: [{ flex: 1 }, contentStyle],
            contentContainerStyle: [containerStyle, { flexGrow: 1 }],
            showsVerticalScrollIndicator: false,
            keyboardShouldPersistTaps: 'handled' as const,
        }
        : {
            style: [{ flex: 1 }, containerStyle, contentStyle],
        };

    let content = (
        <ContentWrapper {...contentWrapperProps}>
            {children}
        </ContentWrapper>
    );

    // Wrap with keyboard avoiding if needed
    if (avoidKeyboard) {
        const KeyboardAvoidingView = require('react-native').KeyboardAvoidingView;
        content = (
            <KeyboardAvoidingView
                style={{ flex: 1 }}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
            >
                {content}
            </KeyboardAvoidingView>
        );
    }

    return (
        <ResponsiveSafeArea
            style={style}
            mode={safeAreaMode}
            backgroundColor={backgroundColor}
            testID={testID}
        >
            {content}
        </ResponsiveSafeArea>
    );
});

// ==================== Inset Aware View ====================

interface InsetAwareViewProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;

    // Which insets to apply
    applyTop?: boolean;
    applyBottom?: boolean;
    applyLeft?: boolean;
    applyRight?: boolean;

    // Additional offset
    topOffset?: number;
    bottomOffset?: number;
}

export const InsetAwareView = memo(function InsetAwareView({
    children,
    style,
    applyTop = false,
    applyBottom = false,
    applyLeft = false,
    applyRight = false,
    topOffset = 0,
    bottomOffset = 0,
}: InsetAwareViewProps) {
    const insets = useSafeAreaInsets();

    const insetStyle = useMemo((): ViewStyle => ({
        paddingTop: applyTop ? insets.top + topOffset : topOffset,
        paddingBottom: applyBottom ? insets.bottom + bottomOffset : bottomOffset,
        paddingLeft: applyLeft ? insets.left : 0,
        paddingRight: applyRight ? insets.right : 0,
    }), [insets, applyTop, applyBottom, applyLeft, applyRight, topOffset, bottomOffset]);

    return (
        <View style={[insetStyle, style]}>
            {children}
        </View>
    );
});
