/**
 * Course Card Component
 * Matches LEQ web app course card design
 * Fully responsive across all device sizes
 */

import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions, Platform, StyleProp, ViewStyle, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import { Course } from '@/types';
import { useAuthStore } from '@/context/authStore';
import { spacing, typography, borderRadius, iconSizes, responsiveDimensions, useResponsiveLayout } from '@/utils/responsive';

interface CourseCardProps {
    course: Course;
    onPress: (course: Course) => void;
    size?: 'small' | 'medium' | 'large';
    variant?: 'default' | 'thumbnail';
    style?: StyleProp<ViewStyle>;
}

export function CourseCard({ course, onPress, size = 'medium', variant = 'default', style }: CourseCardProps) {
    const { user } = useAuthStore();
    const { width } = useWindowDimensions();
    const { isTablet, isSmallDevice } = useResponsiveLayout();

    // Calculate widths dynamically based on current window width
    // We want to show partial cards to encourage horizontal scrolling
    const spacing_h = spacing.lg * 2;
    const gap = spacing.md;

    let defaultWidth;

    if (size === 'small') {
        // Small cards (horizontal lists)
        if (isTablet) {
            // Approx 4.2 cards visible
            defaultWidth = (width - spacing_h) / 4.2;
        } else {
            // Ensure 3 items are visible on mobile screens
            defaultWidth = (width - spacing.md * 2) / (isSmallDevice ? 2.8 : 3.2);
        }
    } else if (size === 'large') {
        // Large cards
        const baseWidth = (width - spacing_h - gap) / 2;
        defaultWidth = isTablet ? baseWidth : width - spacing_h;
    } else {
        // Medium cards (default)
        if (isTablet) {
            defaultWidth = (width - spacing_h - gap * 2) / 3.2;
        } else {
            defaultWidth = (width - spacing_h) / 1.5;
        }
    }

    const formatPrice = (price: number) => {
        return `₹${price.toLocaleString('en-IN')}`;
    };

    const getDiscountPercentage = () => {
        if (course.discount_price && course.price > 0) {
            return Math.round(((course.price - course.discount_price) / course.price) * 100);
        }
        return 0;
    };

    return (
        <TouchableOpacity
            style={[styles.container, { width: defaultWidth }, style]}
            onPress={() => onPress(course)}
            activeOpacity={0.8}
        >
            {/* Thumbnail */}
            <View style={[styles.imageContainer, { aspectRatio: 1 }]}>
                {course.thumbnail_url ? (
                    <Image
                        source={{ uri: course.thumbnail_url }}
                        style={styles.thumbnail}
                        resizeMode="cover"
                    />
                ) : (
                    <View style={styles.placeholderContainer}>
                        <Ionicons name="musical-notes" size={40} color={Colors.dark.primary} />
                    </View>
                )}

                {/* Badge */}
                {course.is_free || user?.is_free_user ? (
                    <View style={[styles.badge, styles.freeBadge]}>
                        <Ionicons name="gift" size={10} color="#fff" />
                        <Text style={styles.badgeText}>Free</Text>
                    </View>
                ) : getDiscountPercentage() > 0 ? (
                    <View style={[styles.badge, styles.discountBadge]}>
                        <Text style={styles.badgeText}>{getDiscountPercentage()}% OFF</Text>
                    </View>
                ) : null}
            </View>

            {/* Course Info */}
            {variant === 'default' && (
                <View style={styles.infoContainer}>
                    <Text style={styles.title} numberOfLines={2}>{course.title}</Text>

                    {course.teacher && (
                        <Text style={styles.instructor} numberOfLines={1}>
                            {course.teacher.full_name}
                        </Text>
                    )}

                    {/* Rating */}
                    {course.average_rating > 0 && (
                        <View style={styles.ratingContainer}>
                            <Ionicons name="star" size={12} color="#FDB022" />
                            <Text style={styles.rating}>{Number(course.average_rating).toFixed(1)}</Text>
                            <Text style={styles.reviews}>({course.total_reviews})</Text>
                        </View>
                    )}

                    {/* Price */}
                    <View style={styles.priceContainer}>
                        {course.is_free || user?.is_free_user ? (
                            <Text style={styles.freePrice}>Free</Text>
                        ) : course.discount_price ? (
                            <>
                                <Text style={styles.currentPrice}>{formatPrice(course.discount_price)}</Text>
                                <Text style={styles.originalPrice}>{formatPrice(course.price)}</Text>
                            </>
                        ) : (
                            <Text style={styles.currentPrice}>{formatPrice(course.price)}</Text>
                        )}
                    </View>
                </View>
            )}
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: Colors.dark.card,
        borderRadius: borderRadius.md,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
        elevation: 3,
        marginBottom: 4,
        ...Platform.select({
            web: {
                boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.2)',
            },
        }),
    },
    imageContainer: {
        position: 'relative',
        backgroundColor: Colors.dark.backgroundSecondary,
    },
    thumbnail: {
        width: '100%',
        height: '100%',
    },
    placeholderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.dark.backgroundSecondary,
    },
    badge: {
        position: 'absolute',
        top: spacing.sm,
        right: spacing.sm,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: spacing.sm,
        paddingVertical: 4,
        borderRadius: borderRadius.sm,
        gap: 4,
        zIndex: 10,
    },
    freeBadge: {
        backgroundColor: 'rgba(16, 185, 129, 0.95)',
    },
    discountBadge: {
        backgroundColor: 'rgba(239, 68, 68, 0.95)',
    },
    badgeText: {
        color: '#fff',
        fontSize: typography.tiny,
        fontWeight: '700',
    },
    infoContainer: {
        padding: spacing.md,
    },
    title: {
        fontSize: typography.bodySmall,
        fontWeight: '700',
        color: Colors.dark.text,
        lineHeight: 20,
        marginBottom: 4,
        minHeight: responsiveDimensions.isSmallDevice ? 36 : 40,
    },
    instructor: {
        fontSize: typography.tiny,
        color: Colors.dark.textMuted,
        marginBottom: spacing.sm,
    },
    ratingContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginBottom: spacing.sm,
    },
    rating: {
        fontSize: typography.caption,
        fontWeight: '700',
        color: Colors.dark.text,
    },
    reviews: {
        fontSize: typography.tiny,
        color: Colors.dark.textMuted,
    },
    priceContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        marginTop: 4,
    },
    currentPrice: {
        fontSize: typography.body,
        fontWeight: '700',
        color: Colors.dark.primary,
    },
    originalPrice: {
        fontSize: typography.caption,
        color: Colors.dark.textMuted,
        textDecorationLine: 'line-through',
    },
    freePrice: {
        fontSize: typography.body,
        fontWeight: '700',
        color: Colors.dark.success,
    },
});

export default CourseCard;
