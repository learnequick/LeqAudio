/**
 * Error State Component
 * Displays error message with retry button
 */

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';

interface ErrorStateProps {
    message?: string;
    onRetry?: () => void;
    fullScreen?: boolean;
}

export function ErrorState({
    message = 'Something went wrong',
    onRetry,
    fullScreen = true
}: ErrorStateProps) {
    return (
        <View style={[styles.container, fullScreen && styles.fullScreen]}>
            <View style={styles.iconContainer}>
                <Ionicons name="alert-circle-outline" size={48} color={Colors.dark.danger} />
            </View>
            <Text style={styles.message}>{message}</Text>
            {onRetry && (
                <TouchableOpacity style={styles.retryButton} onPress={onRetry}>
                    <Ionicons name="refresh" size={18} color="#fff" />
                    <Text style={styles.retryText}>Try Again</Text>
                </TouchableOpacity>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    fullScreen: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    iconContainer: {
        marginBottom: 16,
    },
    message: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        marginBottom: 20,
        paddingHorizontal: 20,
    },
    retryButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 24,
        gap: 8,
    },
    retryText: {
        color: '#fff',
        fontSize: 14,
        fontWeight: '600',
    },
});

export default ErrorState;
