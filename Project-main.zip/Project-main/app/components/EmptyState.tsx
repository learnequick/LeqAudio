/**
 * Empty State Component
 * Displays empty state with icon and message
 */

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';

interface EmptyStateProps {
    icon?: keyof typeof Ionicons.glyphMap;
    title?: string;
    message?: string;
    actionLabel?: string;
    onAction?: () => void;
    fullScreen?: boolean;
}

export function EmptyState({
    icon = 'folder-open-outline',
    title = 'Nothing here yet',
    message,
    actionLabel,
    onAction,
    fullScreen = true
}: EmptyStateProps) {
    return (
        <View style={[styles.container, fullScreen && styles.fullScreen]}>
            <View style={styles.iconContainer}>
                <Ionicons name={icon} size={64} color={Colors.dark.textMuted} />
            </View>
            <Text style={styles.title}>{title}</Text>
            {message && <Text style={styles.message}>{message}</Text>}
            {actionLabel && onAction && (
                <TouchableOpacity style={styles.actionButton} onPress={onAction}>
                    <Text style={styles.actionText}>{actionLabel}</Text>
                </TouchableOpacity>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    fullScreen: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    iconContainer: {
        marginBottom: 16,
        opacity: 0.6,
    },
    title: {
        fontSize: 18,
        fontWeight: '600',
        color: Colors.dark.text,
        textAlign: 'center',
        marginBottom: 8,
    },
    message: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        paddingHorizontal: 40,
        marginBottom: 20,
    },
    actionButton: {
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 24,
    },
    actionText: {
        color: '#fff',
        fontSize: 14,
        fontWeight: '600',
    },
});

export default EmptyState;
