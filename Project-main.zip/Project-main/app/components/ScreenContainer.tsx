import React from 'react';
import { View, StyleProp, ViewStyle, StyleSheet } from 'react-native';
import { useResponsiveLayout } from '@/utils/responsive';

interface ScreenContainerProps {
    children: React.ReactNode;
    style?: StyleProp<ViewStyle>;
    maxWidth?: number;
    centered?: boolean;
}

/**
 * A container component that constrains content width on larger screens (tablets/desktops)
 * and centers it. Essential for responsive design on large displays.
 */
export function ScreenContainer({
    children,
    style,
    maxWidth = 1200,
    centered = true
}: ScreenContainerProps) {
    const { width } = useResponsiveLayout();

    // Check if constraint is needed
    const shouldConstrain = width > maxWidth;

    return (
        <View style={[
            styles.container,
            shouldConstrain && { maxWidth, alignSelf: 'center', width: '100%' },
            centered && shouldConstrain && styles.centered,
            style
        ]}>
            {children}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
    },
    centered: {
        alignItems: 'stretch', // Keep stretch alignment for children
    }
});
