/**
 * Loading State Component
 * Displays a centered loading spinner
 */

import React from 'react';
import { View, ActivityIndicator, StyleSheet, Text } from 'react-native';
import { Colors } from '@/constants/Colors';

interface LoadingStateProps {
    message?: string;
    size?: 'small' | 'large';
    fullScreen?: boolean;
}

export function LoadingState({
    message,
    size = 'large',
    fullScreen = true
}: LoadingStateProps) {
    return (
        <View style={[styles.container, fullScreen && styles.fullScreen]}>
            <ActivityIndicator size={size} color={Colors.dark.primary} />
            {message && <Text style={styles.message}>{message}</Text>}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    fullScreen: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    message: {
        marginTop: 16,
        fontSize: 14,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
    },
});

export default LoadingState;
