/**
 * Audio Player Component
 * Vinyl record UI matching LEQ web app design with YouTube support
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    Image,
    Platform,
    useWindowDimensions,
    Animated,
    Modal,
} from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, useNavigation } from 'expo-router';
import Svg, { Path, Defs, Circle, Rect } from 'react-native-svg';
import YoutubePlayer from 'react-native-youtube-iframe';

import { lessonService } from '@/services';

const { width } = Dimensions.get('window');

interface AudioPlayerProps {
    audioUrl: string;
    title: string;
    subtitle?: string;
    thumbnailUrl?: string;
    lessonId?: number;
    onBack?: () => void;
}

// Extract YouTube video ID from URL
function extractYouTubeId(url: string): string | null {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
        /^([a-zA-Z0-9_-]{11})$/
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
            return match[1];
        }
    }

    return null;
}

export function AudioPlayer({
    audioUrl,
    title,
    subtitle,
    thumbnailUrl,
    lessonId,
    onBack,
}: AudioPlayerProps) {
    const { width } = useWindowDimensions();
    const router = useRouter();
    const navigation = useNavigation();

    // Determine if using YouTube
    const youtubeVideoId = extractYouTubeId(audioUrl);
    const isUsingYouTube = !!youtubeVideoId;

    // Audio state
    const [sound, setSound] = useState<Audio.Sound | null>(null);
    const [isPlaying, setIsPlaying] = useState(false); // Start with false, will be set to true after loading
    const [position, setPosition] = useState(0);
    const [duration, setDuration] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
    const [showSpeedMenu, setShowSpeedMenu] = useState(false);
    const [youtubeReady, setYoutubeReady] = useState(false);

    // Progress tracking
    const lastProgressUpdate = useRef<number>(0);
    const soundRef = useRef<Audio.Sound | null>(null);

    // YouTube player ref
    const youtubePlayerRef = useRef<any>(null);
    const youtubeWebViewRef = useRef<any>(null);
    const durationFetchedRef = useRef<boolean>(false);
    const youtubePlayingRef = useRef<boolean>(false); // Start with false, will be set to true after ready

    // Vinyl animation refs
    const spinValue = useRef(new Animated.Value(0)).current;
    const toneArmRotation = useRef(new Animated.Value(0)).current;

    // Vinyl rotation animation
    useEffect(() => {
        let animation: Animated.CompositeAnimation;

        if (isPlaying) {
            // Rotate vinyl continuously
            spinValue.setValue(0);
            animation = Animated.loop(
                Animated.timing(spinValue, {
                    toValue: 1,
                    duration: 8000,
                    useNativeDriver: true,
                })
            );
            animation.start();

            // Move tone arm onto record
            Animated.timing(toneArmRotation, {
                toValue: 1,
                duration: 800,
                useNativeDriver: true,
            }).start();
        } else {
            // Move tone arm off record
            Animated.timing(toneArmRotation, {
                toValue: 0,
                duration: 800,
                useNativeDriver: true,
            }).start();
        }

        return () => {
            if (animation) animation.stop();
        };
    }, [isPlaying, spinValue, toneArmRotation]);

    const spin = spinValue.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '360deg'],
    });

    const toneArmAngle = toneArmRotation.interpolate({
        inputRange: [0, 1],
        outputRange: ['-30deg', '10deg'],
    });

    // Load audio (non-YouTube)
    useEffect(() => {
        if (!isUsingYouTube) {
            loadAudio();
        } else {
            setIsLoading(false);
        }

        return () => {
            // Cleanup for regular audio
            if (soundRef.current) {
                soundRef.current.stopAsync().catch(() => { });
                soundRef.current.unloadAsync().catch(() => { });
            }
            // Cleanup for YouTube - pause when component unmounts
            if (isUsingYouTube && youtubePlayerRef.current) {
                youtubePlayerRef.current.pauseVideo?.().catch(() => { });
            }
        };
    }, [audioUrl, isUsingYouTube]);

    const loadAudio = async () => {
        try {
            setIsLoading(true);
            await Audio.setAudioModeAsync({
                allowsRecordingIOS: false,
                playsInSilentModeIOS: true,
                staysActiveInBackground: false,
            });

            const { sound: newSound } = await Audio.Sound.createAsync(
                { uri: audioUrl },
                { shouldPlay: true, rate: playbackSpeed, volume: 1.0 },
                onPlaybackStatusUpdate
            );

            soundRef.current = newSound;
            setSound(newSound);
            setIsLoading(false);
            // Set playing to true after successfully loading and starting playback
            setIsPlaying(true);
        } catch (error) {

            setIsLoading(false);
            setIsPlaying(false);
        }
    };

    const onPlaybackStatusUpdate = (status: any) => {
        if (status.isLoaded) {
            setPosition(status.positionMillis);
            setDuration(status.durationMillis || 0);
            setIsPlaying(status.isPlaying);

            if (status.didJustFinish) {
                setIsPlaying(false);
                // Only reset position if sound is still loaded
                if (soundRef.current) {
                    soundRef.current.setPositionAsync(0).catch(() => { });
                }
                if (lessonId) {
                    lessonService.updateProgress(lessonId, 100).catch(() => { });
                    lastProgressUpdate.current = 100;
                }
            }
        }
    };

    // YouTube handlers
    const onYouTubeReady = useCallback(async () => {

        setYoutubeReady(true);
        setIsLoading(false);

        // Auto-play YouTube video after ready
        youtubePlayingRef.current = true;
        setIsPlaying(true);

        // Fetch initial duration when player is ready - retry with delay if needed
        if (youtubePlayerRef.current) {
            // Explicitly start playback using seekTo which triggers play
            try {
                // Small delay to ensure player is fully initialized
                await new Promise(resolve => setTimeout(resolve, 100));
                await youtubePlayerRef.current.seekTo(0, true);

            } catch (error) {
                // Silent fail
            }

            const fetchDuration = async (retries = 3) => {
                for (let i = 0; i < retries; i++) {
                    try {
                        await new Promise(resolve => setTimeout(resolve, i * 300)); // Progressive delay
                        const totalDuration = await youtubePlayerRef.current.getDuration();
                        if (totalDuration && totalDuration > 0) {
                            setDuration(totalDuration * 1000);
                            durationFetchedRef.current = true;
                            return;
                        }
                    } catch (error) {
                        // Silent fail
                    }
                }
            };
            fetchDuration();
        }
    }, []);

    const onYouTubeStateChange = useCallback((state: string) => {

        // Sync our state with YouTube player state
        // This is necessary for the play prop to work correctly
        if (state === 'playing') {
            if (!youtubePlayingRef.current) {
                youtubePlayingRef.current = true;
                setIsPlaying(true);
            }
        } else if (state === 'paused') {
            if (youtubePlayingRef.current) {
                youtubePlayingRef.current = false;
                setIsPlaying(false);
            }
        } else if (state === 'ended') {
            youtubePlayingRef.current = false;
            setIsPlaying(false);
        }
    }, []);

    // YouTube progress callback - optimized for performance
    const onYouTubeProgress = useCallback((data: { currentTime: number; duration: number }) => {
        // Batch state updates to reduce re-renders
        const newPosition = data.currentTime * 1000;
        const newDuration = data.duration * 1000;

        setPosition(newPosition);
        // Only update duration once when it becomes available
        if (newDuration > 0 && !durationFetchedRef.current) {
            setDuration(newDuration);
            durationFetchedRef.current = true;
        }
    }, []);

    // Polling for YouTube progress (fallback for version 2.3.0 which may not fire onProgress reliably)
    useEffect(() => {
        if (!isUsingYouTube || !youtubeReady || !youtubePlayerRef.current) return;

        const interval = setInterval(async () => {
            if (isPlaying && youtubePlayerRef.current) {
                try {
                    const currentTime = await youtubePlayerRef.current.getCurrentTime();
                    if (currentTime !== undefined) {
                        setPosition(currentTime * 1000);
                    }

                    // Also get duration if not fetched yet
                    if (!durationFetchedRef.current) {
                        const totalDuration = await youtubePlayerRef.current.getDuration();
                        if (totalDuration > 0) {
                            setDuration(totalDuration * 1000);
                            durationFetchedRef.current = true;
                        }
                    }
                } catch (error) {
                    // Silent fail - player might not be ready
                }
            }
        }, 1000); // Update every second

        return () => clearInterval(interval);
    }, [isUsingYouTube, youtubeReady, isPlaying]);

    // Removed legacy polling - now using onProgress callback for better performance

    const updateProgress = async (currentPosition: number, totalDuration: number) => {
        if (!lessonId || !totalDuration || totalDuration === 0) return;
        const progress = (currentPosition / totalDuration) * 100;

        // Only update if progress changed by more than 5% to reduce API calls
        if (Math.abs(progress - lastProgressUpdate.current) < 5) return;

        try {
            await lessonService.updateProgress(lessonId, progress);
            lastProgressUpdate.current = progress;
        } catch (error) {
        }
    }

    const togglePlayPause = async () => {
        if (isUsingYouTube) {
            if (!youtubeReady) {
                return;
            }

            // Toggle state - the play prop will control the player
            // onChangeState will sync the state back if needed
            const newPlayingState = !isPlaying;
            youtubePlayingRef.current = newPlayingState;
            setIsPlaying(newPlayingState);
        } else {
            if (!sound) return;

            if (isPlaying) {
                await sound.pauseAsync();
                if (duration > 0) {
                    updateProgress(position, duration);
                }
            } else {
                await sound.playAsync();
            }
        }
    };

    const skipForward = async () => {
        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                const currentTime = await youtubePlayerRef.current.getCurrentTime();
                const newTime = Math.min((currentTime || 0) + 10, duration / 1000);
                await youtubePlayerRef.current.seekTo(newTime, true);
            } catch (error) {
                // Silent fail - ref methods may not be available
            }
        } else {
            if (!sound) return;
            const newPosition = Math.min(position + 10000, duration);
            await sound.setPositionAsync(newPosition);
        }
    };

    const skipBackward = async () => {
        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                const currentTime = await youtubePlayerRef.current.getCurrentTime();
                const newTime = Math.max((currentTime || 0) - 10, 0);
                await youtubePlayerRef.current.seekTo(newTime, true);
            } catch (error) {
                // Silent fail - ref methods may not be available
            }
        } else {
            if (!sound) return;
            const newPosition = Math.max(position - 10000, 0);
            await sound.setPositionAsync(newPosition);
        }
    };

    const changeSpeed = async (speed: number) => {
        setPlaybackSpeed(speed);

        if (isUsingYouTube) {
            if (!youtubePlayerRef.current) return;
            try {
                await youtubePlayerRef.current.setPlaybackRate(speed);
            } catch (error) {
                // Silent fail - ref methods may not be available
            }
        } else {
            if (!sound) return;
            await sound.setRateAsync(speed, true);
        }
    };

    const handleProgressPress = async (event: any) => {
        const { locationX } = event.nativeEvent;
        const progressBarWidth = width - 40; // Account for padding

        if (typeof locationX !== 'number' || !duration) return;

        const percentage = locationX / progressBarWidth;
        const newPosition = Math.max(0, Math.min(duration, percentage * duration));

        if (isUsingYouTube) {
            youtubePlayerRef.current?.seekTo(newPosition / 1000, true);
        } else {
            if (!sound || !Number.isFinite(newPosition)) return;
            await sound.setPositionAsync(newPosition);
        }
    };

    const formatTime = (millis: number) => {
        const totalSeconds = Math.floor(millis / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    };

    const handleBack = async () => {
        if (lessonId && duration > 0) {
            try {
                const progress = (position / duration) * 100;
                await lessonService.updateProgress(lessonId, progress);
            } catch (e) { }
        }

        if (sound) {
            await sound.stopAsync().catch(() => { });
            await sound.unloadAsync().catch(() => { });
        }

        if (onBack) {
            onBack();
        } else if (navigation.canGoBack()) {
            router.back();
        } else {
            router.replace('/');
        }
    };

    const vinylSize = Math.min(300, width * 0.7);
    const progressPercent = duration > 0 ? (position / duration) * 100 : 0;

    return (
        <View style={styles.container}>
            {/* Background Bloom */}
            <LinearGradient
                colors={['#2a2a2a', '#121212']}
                style={styles.bgBloom}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
            />

            <View style={styles.content}>
                {/* Header */}
                <View style={styles.header}>
                    <TouchableOpacity style={styles.iconBtn} onPress={handleBack}>
                        <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.iconBtn}
                        onPress={() => setShowSpeedMenu(!showSpeedMenu)}
                    >
                        <Ionicons name="ellipsis-horizontal" size={24} color="#FFFFFF" />
                    </TouchableOpacity>
                </View>

                {/* Vinyl Section */}
                <View style={styles.vinylWrapper}>
                    <View style={[styles.vinylGroup, { width: vinylSize, height: vinylSize }]}>
                        {/* Vinyl Record */}
                        <Animated.View
                            style={[
                                styles.vinylRecord,
                                { transform: [{ rotate: spin }] }
                            ]}
                        >
                            {/* Vinyl grooves background */}
                            <View style={styles.vinylGrooves} />

                            {/* Album Art */}
                            <View style={styles.albumArt}>
                                {thumbnailUrl ? (
                                    <Image
                                        source={{ uri: thumbnailUrl }}
                                        style={styles.albumImage}
                                    />
                                ) : (
                                    <Ionicons name="musical-notes" size={60} color="#666" />
                                )}
                            </View>

                            {/* Shine effect */}
                            <View style={styles.vinylShine} />
                        </Animated.View>

                        {/* Tone Arm */}
                        <Animated.View
                            style={[
                                styles.toneArm,
                                { transform: [{ rotate: toneArmAngle }] }
                            ]}
                        >
                            <Svg width="100%" height="100%" viewBox="0 0 100 240">
                                <Path
                                    d="M50 10 C 50 10, 50 0, 60 0 L 80 0 C 90 0, 90 10, 90 10 L 90 40 C 90 50, 80 50, 80 50 L 60 50 C 50 50, 50 40, 50 40 Z"
                                    fill="#4b5563"
                                />
                                <Rect x="65" y="50" width="10" height="100" fill="#6b7280" />
                                <Rect x="60" y="150" width="20" height="40" rx="4" fill="#374151" />
                                <Path d="M70 190 L 40 220 L 50 230 L 80 200 Z" fill="#9ca3af" />
                                <Circle cx="45" cy="225" r="3" fill="#ef4444" />
                            </Svg>
                        </Animated.View>
                    </View>
                </View>

                {/* Track Info */}
                <View style={styles.trackInfo}>
                    <Text style={styles.trackTitle} numberOfLines={2}>
                        {title}
                    </Text>
                    {subtitle && (
                        <Text style={styles.trackSubtitle} numberOfLines={1}>
                            {subtitle}
                        </Text>
                    )}
                </View>

                {/* Arc Progress Bar */}
                <View style={styles.progressContainer}>
                    <Text style={styles.timeLabel}>{formatTime(position)}</Text>

                    <TouchableOpacity
                        style={styles.progressSvgContainer}
                        onPress={handleProgressPress}
                        activeOpacity={1}
                    >
                        <Svg width="100%" height="70" viewBox="0 0 300 60" preserveAspectRatio="none">
                            {/* Background arc */}
                            <Path
                                d="M 20,20 Q 150,70 280,20"
                                stroke="#333333"
                                strokeWidth="4"
                                strokeLinecap="round"
                                fill="none"
                            />
                            {/* Active progress arc */}
                            <Path
                                d="M 20,20 Q 150,70 280,20"
                                stroke="#A855F7"
                                strokeWidth="4"
                                strokeLinecap="round"
                                fill="none"
                                strokeDasharray="260"
                                strokeDashoffset={260 - (260 * progressPercent / 100)}
                            />
                        </Svg>
                    </TouchableOpacity>

                    <Text style={[styles.timeLabel, styles.timeLabelRight]}>{formatTime(duration)}</Text>
                </View>

                {/* Controls */}
                <View style={styles.controls}>
                    <TouchableOpacity
                        style={styles.ctrlBtn}
                        onPress={skipBackward}
                        disabled={isLoading}
                    >
                        <Ionicons name="play-skip-back" size={32} color="#FFFFFF" />
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.playBtn}
                        onPress={togglePlayPause}
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <Ionicons name="hourglass" size={32} color="#FFFFFF" />
                        ) : (
                            <Ionicons
                                name={isPlaying ? 'pause' : 'play'}
                                size={32}
                                color="#FFFFFF"
                            />
                        )}
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.ctrlBtn}
                        onPress={skipForward}
                        disabled={isLoading}
                    >
                        <Ionicons name="play-skip-forward" size={32} color="#FFFFFF" />
                    </TouchableOpacity>
                </View>
            </View>

            {/* Speed Menu Modal */}
            <Modal
                visible={showSpeedMenu}
                transparent
                animationType="slide"
                onRequestClose={() => setShowSpeedMenu(false)}
            >
                <TouchableOpacity
                    style={styles.menuOverlay}
                    activeOpacity={1}
                    onPress={() => setShowSpeedMenu(false)}
                >
                    <View style={styles.menuModal}>
                        {[1.0, 1.25, 1.5, 2.0].map((speed) => (
                            <TouchableOpacity
                                key={speed}
                                style={styles.menuOption}
                                onPress={() => {
                                    changeSpeed(speed);
                                    setShowSpeedMenu(false);
                                }}
                            >
                                <Text style={styles.menuOptionText}>
                                    {speed === 1.0 ? 'Normal Speed (1.0x)' : `Speed ${speed}x`}
                                </Text>
                                {playbackSpeed === speed && (
                                    <Ionicons name="checkmark" size={20} color="#A855F7" />
                                )}
                            </TouchableOpacity>
                        ))}
                    </View>
                </TouchableOpacity>
            </Modal>

            {/* Hidden YouTube Player */}
            {isUsingYouTube && youtubeVideoId && (
                <View style={styles.hiddenYouTube}>
                    <YoutubePlayer
                        ref={youtubePlayerRef}
                        height={1}
                        width={1}
                        videoId={youtubeVideoId}
                        play={isPlaying}
                        onReady={onYouTubeReady}
                        onChangeState={onYouTubeStateChange}
                        onProgress={onYouTubeProgress}
                        volume={100}
                        playbackRate={playbackSpeed}
                        initialPlayerParams={{
                            preventFullScreen: true,
                            controls: false,
                            modestbranding: true,
                            start: 0,
                        }}
                        webViewProps={{
                            ref: youtubeWebViewRef,
                            androidLayerType: 'hardware',
                        }}
                    />
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121212',
    },
    bgBloom: {
        position: 'absolute',
        width: '100%',
        height: '100%',
    },
    content: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 50,
        justifyContent: 'space-between',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 10,
    },
    iconBtn: {
        width: 44,
        height: 44,
        borderRadius: 12,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    vinylWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 20,
    },
    vinylGroup: {
        position: 'relative',
    },
    vinylRecord: {
        width: '100%',
        height: '100%',
        borderRadius: 1000,
        backgroundColor: '#111',
        justifyContent: 'center',
        alignItems: 'center',
        ...Platform.select({
            ios: {
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 10 },
                shadowOpacity: 0.6,
                shadowRadius: 40,
            },
            android: {
                elevation: 20,
            },
        }),
    },
    vinylGrooves: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        borderRadius: 1000,
        borderWidth: 5,
        borderColor: '#333',
    },
    albumArt: {
        width: '45%',
        height: '45%',
        borderRadius: 1000,
        backgroundColor: '#333',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        borderWidth: 4,
        borderColor: '#1a1a1a',
        zIndex: 2,
    },
    albumImage: {
        width: '100%',
        height: '100%',
    },
    vinylShine: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        borderRadius: 1000,
        backgroundColor: 'transparent',
        opacity: 0.1,
    },
    toneArm: {
        position: 'absolute',
        top: '-10%',
        right: '-10%',
        width: '35%',
        height: '50%',
        transformOrigin: 'top right',
        zIndex: 5,
        ...Platform.select({
            ios: {
                shadowColor: '#000',
                shadowOffset: { width: 4, height: 4 },
                shadowOpacity: 0.5,
                shadowRadius: 8,
            },
            android: {
                elevation: 8,
            },
        }),
    },
    trackInfo: {
        alignItems: 'center',
        marginBottom: 10,
        paddingHorizontal: 20,
    },
    trackTitle: {
        fontSize: 22,
        fontWeight: '700',
        color: '#FFFFFF',
        textAlign: 'center',
        marginBottom: 6,
    },
    trackSubtitle: {
        fontSize: 14,
        color: '#A0A0A0',
        fontWeight: '500',
        textAlign: 'center',
    },
    progressContainer: {
        height: 70,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
        position: 'relative',
    },
    progressSvgContainer: {
        width: '100%',
        height: 70,
    },
    timeLabel: {
        position: 'absolute',
        fontSize: 12,
        color: '#A0A0A0',
        fontWeight: '500',
        left: 20,
        bottom: 30,
    },
    timeLabelRight: {
        left: 'auto',
        right: 20,
    },
    controls: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 40,
        marginBottom: 40,
    },
    ctrlBtn: {
        backgroundColor: 'transparent',
        padding: 10,
    },
    playBtn: {
        width: 72,
        height: 72,
        borderRadius: 36,
        backgroundColor: '#A855F7',
        justifyContent: 'center',
        alignItems: 'center',
        ...Platform.select({
            ios: {
                shadowColor: 'rgba(168, 85, 247, 0.4)',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 1,
                shadowRadius: 20,
            },
            android: {
                elevation: 8,
            },
        }),
    },
    menuOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'flex-end',
    },
    menuModal: {
        backgroundColor: '#222',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        padding: 24,
    },
    menuOption: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#333',
    },
    menuOptionText: {
        color: '#fff',
        fontSize: 16,
    },
    hiddenYouTube: {
        position: 'absolute',
        left: -9999,
        width: 1,
        height: 1,
        opacity: 0,
    },
});

export default AudioPlayer;
