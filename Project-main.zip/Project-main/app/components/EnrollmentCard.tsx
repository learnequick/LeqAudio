/**
 * Enrollment Card Component - Horizontal Udemy-style Layout
 * Displays enrolled course with progress
 */

import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import { Enrollment } from '@/types';

interface EnrollmentCardProps {
    enrollment: Enrollment;
    onPress: (enrollment: Enrollment) => void;
}

export function EnrollmentCard({ enrollment, onPress }: EnrollmentCardProps) {
    const { progress_percentage, completed_lessons, total_lessons } = enrollment;

    // Normalize course data whether it comes as nested object or flat fields
    const courseData = (typeof enrollment.course === 'object' && enrollment.course !== null)
        ? enrollment.course
        : {
            id: enrollment.course_id || (enrollment.course as number),
            title: enrollment.course_title || 'Untitled Course',
            thumbnail_url: enrollment.course_thumbnail,
            teacher: { full_name: enrollment.teacher_name || '' }
        };

    return (
        <TouchableOpacity
            style={styles.container}
            onPress={() => onPress(enrollment)}
            activeOpacity={0.7}
        >
            {/* Left: Thumbnail */}
            <View style={styles.thumbnailContainer}>
                {(courseData.thumbnail_url || (courseData as any).thumbnail) ? (
                    <Image
                        source={{ uri: courseData.thumbnail_url || (courseData as any).thumbnail }}
                        style={styles.thumbnail}
                        resizeMode="cover"
                    />
                ) : (
                    <View style={styles.placeholderContainer}>
                        <Ionicons name="musical-notes" size={28} color={Colors.dark.primary} />
                    </View>
                )}
            </View>

            {/* Right: Course Info */}
            <View style={styles.contentContainer}>
                {/* Title and Instructor */}
                <View style={styles.headerSection}>
                    <Text style={styles.title} numberOfLines={2}>
                        {courseData.title}
                    </Text>
                    <Text style={styles.instructor} numberOfLines={1}>
                        {(courseData.teacher as any)?.full_name || enrollment.teacher_name || 'LeQ Instructor'}
                    </Text>
                </View>

                {/* Progress Bar */}
                <View style={styles.progressSection}>
                    <View style={styles.progressBar}>
                        <View
                            style={[styles.progressFill, { width: `${progress_percentage}%` }]}
                        />
                    </View>
                    <View style={styles.progressInfo}>
                        <Text style={styles.progressText}>
                            {Math.round(progress_percentage)}% complete
                        </Text>
                        <Text style={styles.lessonsText}>
                            {completed_lessons || 0}/{total_lessons || 0} lessons
                        </Text>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        overflow: 'hidden',
        marginBottom: 12,
        borderWidth: 1,
        borderColor: Colors.dark.border,
        // Shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15,
        shadowRadius: 4,
        elevation: 3,
    },
    thumbnailContainer: {
        width: 80,
        height: 80,
        backgroundColor: Colors.dark.backgroundSecondary,
    },
    thumbnail: {
        width: '100%',
        height: '100%',
    },
    placeholderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(124, 58, 237, 0.1)',
    },
    contentContainer: {
        flex: 1,
        padding: 12,
        justifyContent: 'space-between',
    },
    headerSection: {
        marginBottom: 8,
    },
    title: {
        fontSize: 15,
        fontWeight: '700',
        color: Colors.dark.text,
        lineHeight: 20,
        marginBottom: 4,
    },
    instructor: {
        fontSize: 12,
        color: Colors.dark.textMuted,
        marginTop: 2,
    },
    progressSection: {
        gap: 6,
    },
    progressBar: {
        height: 4,
        backgroundColor: '#2A2A2A',
        borderRadius: 2,
        overflow: 'hidden',
    },
    progressFill: {
        height: '100%',
        backgroundColor: Colors.dark.primary,
        borderRadius: 2,
    },
    progressInfo: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    progressText: {
        fontSize: 11,
        color: Colors.dark.primary,
        fontWeight: '600',
    },
    lessonsText: {
        fontSize: 11,
        color: Colors.dark.textSecondary,
        fontWeight: '500',
    },
});

export default EnrollmentCard;
